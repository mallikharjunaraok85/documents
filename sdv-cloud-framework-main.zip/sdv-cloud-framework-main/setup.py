import os

from setuptools import find_packages, setup

setup(
    name="sdvcf",
    version=f"0.0.{os.getenv('CI_PIPELINE_ID', '3')}",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "croniter~=2.0.5",
        "setuptools~=70.0.0",
        "argcomplete~=3.3.0",
        "pyyaml~=6.0.1",
        "prompt_toolkit~=3.0.47",
        "rich~=13.7.1",
        "cerberus~=1.3.5",
        "boto3~=1.34.137",
        "botocore~=1.34.137",
        "azure-mgmt-subscription~=3.1.1",
        "azure-mgmt-resource~=23.1.1",
        "azure-mgmt-storage~=21.2.1",
        "azure-mgmt-compute~=31.0.0",
        "azure-identity~=1.17.1",
        "cdktf~=0.20.10",
        "cdktf-tf-module-stack~=5.0.37",
        "cdktf-cdktf-provider-aws~=19.41.0",
        "cdktf-cdktf-provider-azuread~=13.0.0",
        "cdktf-cdktf-provider-azurerm~=13.9.0",
        "cdktf-cdktf-provider-tls~=10.0.1",
        "cdktf-cdktf-provider-random~=11.0.3",
        "cdktf-cdktf-provider-github~=14.3.1",
        "cdktf-cdktf-provider-kubernetes~=11.8.0",
        "cdktf-cdktf-provider-helm~=10.4.1",
        "cdktf-cdktf-provider-archive~=10.2.0",
        "cdktf-cdktf-provider-time~=10.2.1",
    ],
    entry_points={"console_scripts": ["sdvcf-cli = sdvcf.cli.cli:cli"]},
    command_options={
        "nuitka": {},
    },
)
