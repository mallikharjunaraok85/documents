#!/usr/bin/env bash

source /etc/os-release

set -x
set -u
set -e

apt update && apt install -y wget

if [[ ! $(dpkg -l | grep packages-microsoft-prod) ]]; then
    wget https://packages.microsoft.com/config/ubuntu/${VERSION_ID}/packages-microsoft-prod.deb \
        -O packages-microsoft-prod.deb
    dpkg -i packages-microsoft-prod.deb && rm -f packages-microsoft-prod.deb
fi

apt update

update-alternatives --install /usr/bin/python python /usr/bin/python2.7 0
