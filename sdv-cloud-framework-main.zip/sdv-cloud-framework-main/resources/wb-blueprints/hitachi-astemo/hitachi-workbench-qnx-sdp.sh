#!/bin/bash

export DEBIAN_FRONTEND=noninteractive
apt-get update && apt-get upgrade -yq \
    && apt-get install -yq \
        unzip   \
        lsb

sudo -u ${user} -i <<'EOF'

# Install QNX Software Center
QNX_SWC_HD="$HOME/qnx"
QNX_SWC_CLI="$QNX_SWC_HD/qnxsoftwarecenter/qnxsoftwarecenter_clt"
if ! test -f "$QNX_SWC_CLI"; then
    mkdir -p $HOME/.qnx

    aws s3 cp --region ${region} ${qnx_software_center_path} /tmp/qnx-setup-linux.run
    chmod a+x /tmp/qnx-setup-linux.run
    /tmp/qnx-setup-linux.run force-override disable-auto-start agree-to-license-terms "$QNX_SWC_HD"

    rm -rf /tmp/qnx-setup-linux.run
fi

QNX_SDP_BASELINE="qnx710"
QNX_SDP_HD="$HOME/$QNX_SDP_BASELINE"
if ! test -f "$QNX_SDP_HD/qnxsdp-env.sh"; then
    mkdir -p $QNX_SDP_HD

    aws s3 cp --region ${region} ${qnx_sdp_path} /tmp/qnx_sdp.zip
    unzip -qo /tmp/qnx_sdp.zip -d $QNX_SDP_HD
    chmod a+x $QNX_SDP_HD/qnxsdp-env.sh

    rm -rf /tmp/qnx_sdp.zip
fi

EOF
