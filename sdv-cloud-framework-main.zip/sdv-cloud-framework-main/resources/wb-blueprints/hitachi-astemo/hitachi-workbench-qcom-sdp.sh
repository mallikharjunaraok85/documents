#!/bin/bash

export DEBIAN_FRONTEND=noninteractive
apt-get update && apt-get upgrade -yq                       \
    && apt-get --install-suggests install --fix-broken -y   \
        libgtkmm-3.0                                        \
        xterm

qpm-cli --version
if [ $? -ne 0 ]; then
    aws s3 cp --region ${region} ${qpm} /tmp/qpm.deb
    dpkg -i /tmp/qpm.deb
fi

qcom_install_script="/home/${user}/setup_qcom_env.sh"
if [ ! -f $qcom_install_script ]; then
    sudo -u ${user} bash -c "cat <<EOF >> $qcom_install_script
#!/bin/bash

qpm-cli --login

qpm-cli --license-activate qud
qpm-cli --license-activate quts
qpm-cli --license-activate pcat

yes | qpm-cli --install qud
yes | qpm-cli --install quts
yes | qpm-cli --install pcat
"

    chmod a+x $qcom_install_script
fi
