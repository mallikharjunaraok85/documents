#!/usr/bin/env bash

# To run the main components of the SDV EDGE stack on a Linux distribution (e.g. Debian, Ubuntu, Raspberry Pi OS).
# The Eclipse SDV stack requires the following packages to be present on the target system.

## Storage for Self Update Bundles
mkdir -p "/data/selfupdates"

## Device Certificates Folder (Required by Cloud Connector)
mkdir -p "/data/var/certificates/"
touch "/data/var/certificates/device.crt"
touch "/data/var/certificates/device.key"

## Mosquitto, D-Bus and RAUC configuration:
apt-get update && apt-get -y install \
    apt-utils       \
    ca-certificates \
    wget            \
    mosquitto       \
    dbus            \
    rauc

MOSQUITTO_CONFIG="/etc/mosquitto/conf.d/public.conf"
if [[ ! -f "${MOSQUITTO_CONFIG}" ]]; then
    ### Mosquitto must be configured to allow anonymous access and listen on
    ### the network interface available to the containers.
    tee "${MOSQUITTO_CONFIG}" > /dev/null <<EOT
listener 1883 0.0.0.0
allow_anonymous true
EOT
fi

BSD_CPU_ARCH=$(dpkg --print-architecture)
if [ "${BSD_CPU_ARCH}" = "amd64" ]; then
    CPU_ARCH="x86_64"
else
    CPU_ARCH=$BSD_CPU_ARCH
fi

TMP_DIR_PATH="/tmp/eclipse-leda-installation-`date +%s`"
mkdir -p ${TMP_DIR_PATH}
cd ${TMP_DIR_PATH}

# Install [Eclipse Kanto](https://github.com/eclipse-kanto/kanto/releases)
wget "https://github.com/eclipse-kanto/kanto/releases/download/v0.1.0-M3/kanto_0.1.0-M3_linux_${CPU_ARCH}.deb"
apt-get install -y ./kanto_0.1.0-M3_linux_${CPU_ARCH}.deb

# Install [Eclipse Leda Utilities](https://github.com/eclipse-leda/leda-utils/releases)
wget "https://github.com/eclipse-leda/leda-utils/releases/download/v0.0.3/eclipse-leda-utils_0.0.3.0.861_all.deb"
apt-get install -y ./eclipse-leda-utils_0.0.3.0.861_all.deb

wget "https://github.com/eclipse-leda/leda-utils/releases/download/v0.0.3/eclipse-leda-kantui_0.0.3.0.861_${BSD_CPU_ARCH}.deb"
apt-get install -y ./eclipse-leda-kantui_0.0.3.0.861_${BSD_CPU_ARCH}.deb

wget "https://github.com/eclipse-leda/leda-utils/releases/download/v0.0.3/eclipse-leda-kanto-auto-deployer_0.0.3.0.861_${BSD_CPU_ARCH}.deb"
apt-get install -y ./eclipse-leda-kanto-auto-deployer_0.0.3.0.861_${BSD_CPU_ARCH}.deb

# Install [Eclipse Meta-Leda](https://github.com/eclipse-leda/meta-leda/releases)
wget "https://github.com/eclipse-leda/meta-leda/releases/download/0.1.0-M3/eclipse-leda-containers_0.1.0.3.0.3721_all.deb"
apt-get install -y ./eclipse-leda-containers_0.1.0.3.0.3721_all.deb

# Run the kanto-auto-deployer to deploy the core components
kanto-auto-deployer /var/containers/manifests

# Install the example containers
kanto-auto-deployer /var/containers/manifests/examples
