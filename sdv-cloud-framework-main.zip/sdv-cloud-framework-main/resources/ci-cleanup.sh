#!/usr/bin/env sh
set -e

echoerr() { echo "$@" 1>&2; }

if [ -z "$1" ]; then
    echoerr "Usage: $0 [--skip-destroy] <CI-PROJECT-ID-1> ... <CI-PROJECT-ID-N>";
    exit 1;
fi

SKIP_DESTROY=false;
if [[ "$1" == "--skip-destroy" ]]; then
    SKIP_DESTROY=true;
    shift;
else
    if [ -z "$ARM_CLIENT_ID" ]; then
        echoerr "Error: Required 'ARM_CLIENT_ID' Environment Variable was not found.";
        exit 2;
    elif [ -z "$ARM_CLIENT_SECRET" ]; then
        echoerr "Error: Required 'ARM_CLIENT_SECRET' Environment Variable was not found.";
        exit 2;
    elif [ -z "$ARM_TENANT_ID" ]; then
        echoerr "Error: Required 'ARM_TENANT_ID' Environment Variable was not found.";
        exit 2;
    elif [ -z "$ARM_SUBSCRIPTION_ID" ]; then
        echoerr "Error: Required 'ARM_SUBSCRIPTION_ID' Environment Variable was not found.";
        exit 2;
    fi

    GIT_ROOT=`git rev-parse --show-toplevel 2>/dev/null`;
    if [ -z "$GIT_ROOT" ]; then
        echoerr "Error: You should be in the SDV Cloud Framework repository.";
        exit 3;
    fi

    cd $GIT_ROOT;
    pip install --upgrade --editable . >/dev/null;
    cd deployments/ci;
fi

for pipeline_id in "$@"
do
    if ! $SKIP_DESTROY; then
        sed "s/__ID__/$pipeline_id/g" variables.yaml.tmpl > variables.yaml;
        cdktf destroy --auto-approve '*';
    fi

    STATE_BUCKET_TMPL="aws-ci-$pipeline_id-sdvcf-";
    STATE_BUCKET=$(aws s3api list-buckets --output text --query "Buckets[?starts_with(Name, '${STATE_BUCKET_TMPL}')].Name | [0]");
    if [ ! -z "$STATE_BUCKET" ] && [ "$STATE_BUCKET" != "None" ]; then
        OBJECTS=$(aws s3api list-object-versions --bucket $STATE_BUCKET --output=json --query="{Objects: *[].{Key:Key,VersionId:VersionId}}")
        aws s3api delete-objects --bucket $STATE_BUCKET --delete "$OBJECTS" >/dev/null || echo "AWS S3 State Bucket \`$STATE_BUCKET\` seems to be empty."
        aws s3 rb s3://$STATE_BUCKET >/dev/null;
        echo "AWS S3 State Bucket \`$STATE_BUCKET\` has been deleted.";
    else
        echo "Info. No S3 State bucket was found for CI-$pipeline_id.";
    fi

    STATE_RESOURCE_GROUP="azure-ci-$pipeline_id-service-rg";
    if az group delete -y --name $STATE_RESOURCE_GROUP 2>/dev/null; then
        echo "Azure Resource Group \`$STATE_RESOURCE_GROUP\` has been deleted.";
    else
        echo "Info. No Service State Azure RG was found for CI-$pipeline_id.";
    fi
done
