#!/bin/sh
set -xu
[ -d ".git/hooks" ] && HOOK_DIR=".git/hooks"

COMMIT_MSG_HOOK="$HOOK_DIR/commit-msg"

ln -fs `pwd`/git_hooks/commit-msg $COMMIT_MSG_HOOK
chmod +x $COMMIT_MSG_HOOK

pip3 install -U black || pip install -U black
pip3 install -U flake8 || pip install -U flake8
pip3 install -U isort || pip install -U isort
pip3 install -U pyright || pip install -U pyright
