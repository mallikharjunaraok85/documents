# SDV Cloud Framework: Flexible & Straightforward Cloud Infrastructure

## Architecture
![SDV CF Classes](./sdvcf/doc/SDV-CF-TF-CDK-Architecture.drawio.png)

## Synthesizing and Deploying the Infrastructure
To Synthesize and deploy SDV Cloud Framework, follow the steps below:
1. Open Terminal and navigate to the root directory of the repository.
2. Download git submodules:
```git submodule update --init --recursive```
3. Ensure CDKTF CLI is installed.
https://developer.hashicorp.com/terraform/tutorials/cdktf/cdktf-install 
4. Run the pip3 command to install the synthesizer:
```sh
$> pip3 install --editable .
$> python setup.py develop
```
5. After the successful installation, run the SDV CF CLI in the desired deployment folder:
```sh
$> cd ./deployments/sdv-poc
$> sdvcf-cli project --config variables.yaml
```

## CI/CD Docker Images
### Deploy Image
To create or(and) update the deploy image for SDV CF CI, follow the steps below:
1. Login to AWS ECR:
```sh
$> aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws/h1a2u8s4
```
2. Run the Docker buildx command to generate a multi-architecture image:
```sh
$> docker buildx build --push --platform linux/arm64/v8,linux/amd64 --tag public.ecr.aws/h1a2u8s4/gl/alpine/sdvcf-deploy:latest -f resources/deploy.Dockerfile .
```
