import os
from typing import Any, Dict, List, Optional, Tuple, TypedDict, Union

from cdktf import (
    Fn,
    ITerraformDependable,
    LocalBackend,
    TerraformBackend,
    TerraformResourceLifecycle,
    Token,
)
from cdktf_cdktf_provider_aws.autoscaling_group_tag import (
    AutoscalingGroupTagA,
    AutoscalingGroupTagTag,
)
from cdktf_cdktf_provider_aws.data_aws_eks_cluster_auth import DataAwsEksClusterAuth
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementCondition,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.eks_addon import EksAddon
from cdktf_cdktf_provider_aws.eks_cluster import EksCluster, EksClusterVpcConfig
from cdktf_cdktf_provider_aws.eks_node_group import (
    EksNodeGroup,
    EksNodeGroupScalingConfig,
)
from cdktf_cdktf_provider_aws.iam_openid_connect_provider import (
    IamOpenidConnectProvider,
)
from cdktf_cdktf_provider_aws.iam_policy import IamPolicy
from cdktf_cdktf_provider_aws.iam_role import IamRole
from cdktf_cdktf_provider_aws.iam_role_policy_attachment import IamRolePolicyAttachment
from cdktf_cdktf_provider_aws.provider import AwsProvider as CdktfAwsProvider
from cdktf_cdktf_provider_helm.provider import HelmProvider
from cdktf_cdktf_provider_helm.release import Release
from cdktf_cdktf_provider_tls.data_tls_certificate import DataTlsCertificate
from cdktf_cdktf_provider_tls.provider import TlsProvider

from sdvcf.interface import (
    IPrivateCloud,
    IProvider,
    IRepository,
    IStageRunner,
    StageRunnerComputeSize,
    StageRunnerCPUArch,
    StageRunnerOS,
    StageRunnerProps,
)
from sdvcf.tags import Tags

from .enums import SubnetType
from .notifications import AWSRunnerNotifications
from .provider import AWSProvider
from .utils import AwsUtils
from .vpc import AWSVpc

__all__ = [
    "AwsEksRunnerProps",
    "EksHelmProvider",
    "AwsEksRunner",
]


class AwsEksRunnerProps(StageRunnerProps):
    """
    AwsEksRunnerProps is a configuration class that extends StageRunnerProps, adding AWS-specific properties.

    Attributes:
        cluster_version (str):
            Specifies the version of the EKS cluster.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        scaling_desired (int):
            Specifies the desired count of nodes for autoscaling purposes.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        scaling_max (int):
            Specifies the maximum count of nodes the cluster can scale out to.
            This can be either specified directly or
            inferred from an environment variable with a default value (None).
        node_disk_size (int):
            Specifies the disk size for the nodes in the cluster.
            This can be either specified directly or
            inferred from an environment variable with a default value (None).
    """

    cluster_version: str
    scaling_desired: int
    scaling_max: int
    node_disk_size: int

    def __init__(
        self,
        cluster_version: Optional[str] = None,
        scaling_desired: Optional[int] = None,
        scaling_max: Optional[int] = None,
        node_disk_size: Optional[int] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self.cluster_version = (
            cluster_version if cluster_version is not None else os.getenv("AWS_EKS_CLUSTER_VERSION", "1.31")
        )
        self.scaling_desired = scaling_desired or int(os.getenv("AWS_EKS_CLUSTER_SCALING_DESIRED", 0))
        self.scaling_max = scaling_max or int(os.getenv("AWS_EKS_CLUSTER_SCALING_MAX", 5))
        self.node_disk_size = node_disk_size or int(os.getenv("AWS_EKS_CLUSTER_NODE_DISK_SIZE", 250))


class EksHelmProvider(IProvider):
    """
    This class provides the creation and setup of EKS Helm.

    Inherits from IProvider.

    Private Attributes:
        _openid_provider (`IamOpenidConnectProvider`):
            Lazily initialized IamOpenidConnectProvider.
            None until accessed.
        _helm_provider (`HelmProvider`):
            Lazily initialized HelmProvider.
            None until accessed.
        _cert_manager (`Release`):
            Lazily initialized Release.
            None until accessed.
        _cluster_autoscaler (`Release`):
            Lazily initialized Release.
            None until accessed.
        _cluster_autoscaler_policy (`IamPolicy`):
            Lazily initialized IamPolicy.
            None until accessed.
        _cluster_autoscaler_role (`IamRole`):
            Lazily initialized IamRole.
            None until accessed.
        _actions_runner_controller (`Release`):
            Lazily initialized Release.
            None until accessed.

    Properties:
        openid_provider:
            Returns the IamOpenidConnectProvider instance, initializing it if it has not been already
        helm_provider:
            Returns the HelmProvider instance, initializing it if it has not been already
        cert_manager:
            Returns the Release instance, initializing it if it has not been already
        cluster_autoscaler_policy:
            Returns the IamPolicy instance, initializing it if it has not been already
        cluster_autoscaler_iam_role:
            Returns the IamRole instance, initializing it if it has not been already
        cluster_autoscaler:
            Returns the Release instance, initializing it if it has not been already
        actions_runner_controller:
            Returns the Release instance, initializing it if it has not been already

    Methods:
        CommitDashboard:
            Empty method.
        _SetupBackend:
            Internal method to set up the Terraform backend.
    """

    # Private class attributes
    _openid_provider: Optional[IamOpenidConnectProvider]
    _helm_provider: Optional[HelmProvider]
    _cert_manager: Optional[Release]
    _cluster_autoscaler: Optional[Release]
    _cluster_autoscaler_policy: Optional[IamPolicy]
    _cluster_autoscaler_role: Optional[IamRole]
    _actions_runner_controller: Optional[Release]

    def __init__(self, runner: "AwsEksRunner", ns: str, **_: Any):
        super().__init__(runner.provider, ns)

        self.runner = runner

        self._openid_provider = None
        self._helm_provider = None
        self._cert_manager = None
        self._cluster_autoscaler = None
        self._cluster_autoscaler_policy = None
        self._cluster_autoscaler_role = None
        self._actions_runner_controller = None

        CdktfAwsProvider(self, f"aws-{ns}", region=self.runner.provider.region)
        TlsProvider(self, f"tls-{ns}")

    @property
    def openid_provider(self) -> IamOpenidConnectProvider:
        """
        A property that creates and configures an IAM OpendID Connect Provider.

        Returns:
            IamOpenidConnectProvider:
                An object representing IAM OpendID Connect Provider.
        """
        if self._openid_provider is None:
            oidc_issuer = Fn.lookup_nested(self.runner.eks.identity, ["0", "oidc", "0", "issuer"])
            oidc_thumbprint = DataTlsCertificate(
                self,
                f"{self.name}-oidc_thumbprint",
                url=oidc_issuer,
            )

            self._openid_provider = IamOpenidConnectProvider(
                self,
                f"{self.name}-openid",
                client_id_list=["sts.amazonaws.com"],
                thumbprint_list=[Fn.lookup_nested(oidc_thumbprint.certificates, ["0", "sha1_fingerprint"])],
                url=oidc_issuer,
            )
        return self._openid_provider

    @property
    def helm_provider(self) -> HelmProvider:
        """
        A property that creates and configures a Helm Provider.

        Returns:
            HelmProvider:
                An object representing Helm Provider.
        """
        if self._helm_provider is None:
            auth_data = DataAwsEksClusterAuth(self, f"{self.name}-eks-auth-data", name=self.runner.eks.name)
            self._helm_provider = HelmProvider(
                self,
                f"{self.name}-helm-provider",
                kubernetes={
                    "host": self.runner.eks.endpoint,
                    "cluster_ca_certificate": Fn.base64decode(
                        Fn.lookup_nested(self.runner.eks.certificate_authority, ["0", "data"])
                    ),
                    "token": auth_data.token,
                },
            )
        return self._helm_provider

    @property
    def cert_manager(self) -> Release:
        """
        A property that creates and configures a cert manager.

        Returns:
            Release:
                An object representing cert manager.
        """
        if self._cert_manager is None:
            # Ensure helm provider was setup
            self.helm_provider

            # Ensure runner service node node was created
            self.runner.service_node

            self._cert_manager = Release(
                self,
                f"{self.name}-install-cert-manager",
                repository="https://charts.jetstack.io",
                chart="cert-manager",
                name="cert-manager",
                create_namespace=True,
                namespace="actions-runner",
                set=[{"name": "installCRDs", "value": "true"}],
            )
        return self._cert_manager

    @property
    def cluster_autoscaler_policy(self) -> IamPolicy:
        """
        A property that creates and configures an IAM Role Policy.

        Returns:
            IamPolicy:
                An object representing IAM Role Policy.
        """
        if self._cluster_autoscaler_policy is None:
            document = DataAwsIamPolicyDocument(
                self,
                f"{self.name}-cluster-autoscaler-role-policy-doc",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=[
                            "autoscaling:DescribeAutoScalingGroups",
                            "autoscaling:DescribeAutoScalingInstances",
                            "autoscaling:DescribeLaunchConfigurations",
                            "autoscaling:DescribeScalingActivities",
                            "autoscaling:DescribeTags",
                            "ec2:DescribeInstanceTypes",
                            "ec2:DescribeLaunchTemplateVersions",
                            "autoscaling:SetDesiredCapacity",
                            "autoscaling:TerminateInstanceInAutoScalingGroup",
                            "ec2:DescribeImages",
                            "ec2:GetInstanceTypesFromInstanceRequirements",
                            "eks:DescribeNodegroup",
                        ],
                        effect="Allow",
                        resources=["*"],
                    )
                ],
            )

            self._cluster_autoscaler_policy = IamPolicy(
                self, f"{self.name}-cluster-autoscaler-role-policy", policy=Token.as_string(document.json)
            )
        return self._cluster_autoscaler_policy

    @property
    def cluster_autoscaler_iam_role(self) -> IamRole:
        """
        A property that creates and configures an IAM Role.

        Returns:
            IamRole:
                An object representing IAM Role.
        """
        if self._cluster_autoscaler_role is None:
            assume_role = DataAwsIamPolicyDocument(
                self,
                f"{self.name}-assume-cluster-autoscaler-role-policy",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=["sts:AssumeRoleWithWebIdentity"],
                        effect="Allow",
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                identifiers=[self.openid_provider.arn],
                                type="Federated",
                            )
                        ],
                        condition=[
                            DataAwsIamPolicyDocumentStatementCondition(
                                test="StringEquals",
                                variable=f"{self.openid_provider.url}:sub",
                                values=["system:serviceaccount:kube-system:cluster-autoscaler"],
                            )
                        ],
                    )
                ],
            )

            iam_role_rid = f"{self.name}-cluster-autoscaler-role"
            iam_role_name = AwsUtils.iamRoleName(iam_role_rid)
            self._cluster_autoscaler_role = IamRole(
                self,
                iam_role_rid,
                name=iam_role_name,
                assume_role_policy=Token.as_string(assume_role.json),
            )

            IamRolePolicyAttachment(
                self,
                f"{self.name}-cluster-autoscaler-role-policy-attachment",
                role=self._cluster_autoscaler_role.name,
                policy_arn=self.cluster_autoscaler_policy.arn,
            )
        return self._cluster_autoscaler_role

    @property
    def cluster_autoscaler(self) -> Release:
        """
        A property that creates and configures a cluster autoscaler.

        Returns:
            Release:
                An object representing cluster autoscaler.
        """
        if self._cluster_autoscaler is None:
            # Ensure help provider was setup
            self.helm_provider

            self._cluster_autoscaler = Release(
                self,
                f"{self.name}-install-cluster-autoscaler",
                repository="https://kubernetes.github.io/autoscaler",
                chart="cluster-autoscaler",
                name="cluster-autoscaler",
                create_namespace=True,
                namespace="kube-system",
                set=[
                    {"name": "autoDiscovery.clusterName", "value": self.runner.eks.name},
                    {"name": "rbac.serviceAccount.name", "value": "cluster-autoscaler"},
                    {"name": "awsRegion", "value": self.runner.provider.region},
                    {
                        "name": "rbac.serviceAccount.annotations.eks\\.amazonaws\\.com/role-arn",
                        "value": self.cluster_autoscaler_iam_role.arn,
                    },
                ],
                depends_on=[self.cert_manager],
            )
        return self._cluster_autoscaler

    @property
    def actions_runner_controller(self) -> Release:
        """
        A property that creates and configures an actions runner controller.

        Returns:
            Release:
                An object representing actions runner controller.
        """
        if self._actions_runner_controller is None:
            self._actions_runner_controller = Release(
                self,
                f"{self.name}-install-ARC",
                repository="https://actions-runner-controller.github.io/actions-runner-controller",
                chart="actions-runner-controller",
                name="actions-runner-controller",
                atomic=True,
                create_namespace=True,
                namespace="actions-runner",
                set=[{"name": "authSecret.create", "value": "true"}],
                set_sensitive=[
                    {"name": "authSecret.github_token", "value": os.getenv("GITHUB_TOKEN", "GITHUB_TOKEN_NOT_SET")}
                ],
                depends_on=[self.cluster_autoscaler],
            )
        return self._actions_runner_controller

    def _SetupBackend(self, provider: Optional[IProvider] = None) -> TerraformBackend:
        """
        Sets up the Terraform backend configuration.

        Parameters:
            provider (`IProvider`):
                The provider where the backend is to be set up.
                If no provider is specified (`None`), the backend is set up within the local context.

        Returns:
            TerraformBackend: The configured Terraform backend instance.
        """
        return LocalBackend(
            provider or self,
            path="helm.terraform.tfstate",
            workspace_dir=provider.name if provider else self.name,
        )

    def CommitDashboard(self) -> None:
        """
        Empty method.

        Parameters:
            None: This method does not have any parameters.

        Returns:
            None: This method does not return any value.
        """
        pass


class AwsEksRunner(IStageRunner):
    """
    Class that contains resources for AWS EKS Runner.

    This class provides the creation and setup of a EKS Runner in AWS.

    Inherits from IStageRunner.

    Attributes:
        provider (`AWSProvider`):
            The instance of the AWSProvider associated with this EKS Runner.
        props (`AwsEksRunnerProps`):
            The instance of the AwsEksRunnerProps associated with this EKS Runner.
        cloud (`AWSVpc`):
            The instance of the AWSVpc associated with this EKS Runner.
        user (`IRepository`):
            The instance of the IRepository associated with this EKS Runner.

    Private Static Attributes:
        _iam_role (`IamRole`):
            Lazily initialized AWS IAM Role representation.
            None until accessed.
        _eks (`EksCluster`):
            Lazily initialized EKS Cluster representation.
            None until accessed.
        _vpc_cni_addon (`EksAddon`):
            Lazily initialized EKS Addon representation.
            None until accessed.
        __node_group_role (`IamRole`):
            Lazily initialized AWS IAM Role representation.
            None until accessed.
        _service_node (`EksNodeGroup`):
            Lazily initialized EKS Node Group representation.
            None until accessed.
        _eks_helm (`EksHelmProvider`):
            Lazily initialized EKS Helm Provider representation.
            None until accessed.
        _node_groups (`Dict[Tuple[str, str], EksNodeGroup]`):
            A dictionary mapping of node group string to the EksNodeGroup object.
        _registry_policy (`IamPolicy`):
            Lazily initialized AWS IAM Policy representation for registries.
            None until accessed.


    Private Attributes:
        _instance_types_mapping (`Dict[StageRunnerCPUArch, Dict[StageRunnerComputeSize, str]]`):
            A dictionary mapping of Stage Runner CPU Arch enum to it's Compute Size.
        _ami_types_mapping (`Dict[StageRunnerOS, Dict[StageRunnerCPUArch, str]]`):
            A dictionary mapping of Stage Runner OS enum to its CPU Arch.

    Public static class constants
        SERVICE_INSTANCE_TYPE (`str`):
            A string that contains the type of the service instance

    Public class constants
        NAME_PREFIX (`str`):
            A string that contains the prefix for the names of all created resources.

    Methods:
        _ObtainNodeGroup:
            Internal method to create and configure EKS Node Group.

    Properties:
        iam_role:
            Returns the IamRole instance, initializing it if it has not been already.
        vpc_cni_addon:
            Returns the EksAddon instance, initializing it if it has not been already.
        eks:
            Returns the EksNodeGroup instance, initializing it if it has not been already.
        service_node:
            Returns the IamRole instance, initializing it if it has not been already.
        node_group:
            Returns the EksNodeGroup instance, initializing it if it has not been already.
        eks_helm:
            Returns the EksHelmProvider instance, initializing it if it has not been already.
        static_tag:
            Returns the static tag.
        tag:
            Returns the tag.
        labels:
            Returns the list of labels.
        _node_group_role:
            Returns the IamRole instance, initializing it if it has not been already.
        registry_policy:
            Returns the IamPolicy instance, initializing it if it has not been already.
    """

    # Public static class constants
    SERVICE_INSTANCE_TYPE = "t3.small"

    # Public class constants
    NAME_PREFIX: str

    # Public class attributes
    provider: AWSProvider
    props: AwsEksRunnerProps
    cloud: AWSVpc
    repo: IRepository
    instance_resources_mapping: Dict[StageRunnerCPUArch, Dict[StageRunnerComputeSize, Dict[str, str]]]

    # Private static class attributes
    _iam_role: Optional[IamRole] = None
    _eks: Optional[EksCluster] = None
    _vpc_cni_addon: Optional[EksAddon] = None
    __node_group_role: Optional[IamRole] = None
    _service_node: Optional[EksNodeGroup] = None
    _node_groups: Dict[Tuple[str, str], EksNodeGroup] = {}
    _eks_helm: Optional[EksHelmProvider] = None
    _registry_policy: Optional[IamPolicy] = None

    # Private class attributes
    _instance_types_mapping: Dict[StageRunnerCPUArch, Dict[StageRunnerComputeSize, str]]
    _ami_types_mapping: Dict[StageRunnerOS, Dict[StageRunnerCPUArch, str]]

    def __init__(self, cloud: IPrivateCloud, ns: str, repo: IRepository, props: AwsEksRunnerProps):
        super().__init__(cloud.provider, ns, props)

        self.NAME_PREFIX = f"{self.provider.name}-eks-psr"

        assert isinstance(cloud, AWSVpc)
        self.cloud = cloud
        self.repo = repo

        self._instance_types_mapping = {
            StageRunnerCPUArch.Arm64: {
                StageRunnerComputeSize.Small: "t4g.medium",
                StageRunnerComputeSize.Medium: "t4g.xlarge",
                StageRunnerComputeSize.Large: "t4g.2xlarge",
            },
            StageRunnerCPUArch.x86_64: {
                StageRunnerComputeSize.Small: "c5.large",
                StageRunnerComputeSize.Medium: "c5.2xlarge",
                StageRunnerComputeSize.Large: "c5.4xlarge",
            },
        }

        self.instance_resources_mapping = {
            StageRunnerCPUArch.Arm64: {
                StageRunnerComputeSize.Small: {"cpu": "1", "memory": "3092M"},
                StageRunnerComputeSize.Medium: {"cpu": "3", "memory": "14870M"},
                StageRunnerComputeSize.Large: {"cpu": "7", "memory": "27288M"},
            },
            StageRunnerCPUArch.x86_64: {
                StageRunnerComputeSize.Small: {"cpu": "1", "memory": "3092M"},
                StageRunnerComputeSize.Medium: {"cpu": "7", "memory": "14870M"},
                StageRunnerComputeSize.Large: {"cpu": "15", "memory": "27288M"},
            },
        }

        self._ami_types_mapping = {
            StageRunnerOS.Linux: {StageRunnerCPUArch.x86_64: "AL2_x86_64", StageRunnerCPUArch.Arm64: "AL2_ARM_64"},
            StageRunnerOS.Windows: {StageRunnerCPUArch.x86_64: "WINDOWS_CORE_2019_x86_64"},
        }

    @property
    def iam_role(self) -> IamRole:
        """
        Creates and configures a AWS IAM Role.

        Returns:
            IamRole:
                An object representing the configured AWS IAM Role.
        """
        if self.__class__._iam_role is None:
            assume_role = DataAwsIamPolicyDocument(
                self.cloud,
                f"{self.NAME_PREFIX}-assume-role-policy",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=["sts:AssumeRole"],
                        effect="Allow",
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                identifiers=["eks.amazonaws.com"], type="Service"
                            )
                        ],
                    )
                ],
            )

            iam_role_rid = f"{self.NAME_PREFIX}-role"
            iam_role_name = AwsUtils.iamRoleName(iam_role_rid)
            self.__class__._iam_role = IamRole(
                self.cloud,
                iam_role_rid,
                name=iam_role_name,
                assume_role_policy=Token.as_string(assume_role.json),
            )

            IamRolePolicyAttachment(
                self.cloud,
                f"{self.NAME_PREFIX}-AmazonEKSClusterPolicy",
                policy_arn="arn:aws:iam::aws:policy/AmazonEKSClusterPolicy",
                role=self.iam_role.name,
            )

            IamRolePolicyAttachment(
                self.cloud,
                f"{self.NAME_PREFIX}-AmazonEKSVPCResourceController",
                policy_arn="arn:aws:iam::aws:policy/AmazonEKSVPCResourceController",
                role=self.iam_role.name,
            )
        return self.__class__._iam_role

    @property
    def vpc_cni_addon(self) -> EksAddon:
        """
        Creates and configures a EKS Addon.

        Returns:
            EksAddon:
                An object representing the configured EKS Addon.
        """
        if self.__class__._vpc_cni_addon is None:
            name = f"{self.NAME_PREFIX}-vpc-cni-addon"
            self.__class__._vpc_cni_addon = EksAddon(
                self.cloud,
                name,
                addon_name="vpc-cni",
                preserve=False,
                cluster_name=self.eks.name,
                tags=Tags(self.cloud, name).to_dict,
            )
        return self.__class__._vpc_cni_addon

    @property
    def eks(self) -> EksCluster:
        """
        Creates and configures a EKS Cluster.

        Returns:
            EksCluster:
                An object representing the configured EKS Cluster.
        """
        if self.__class__._eks is None:
            cluster_rid = f"{self.NAME_PREFIX}-cluster"
            cluster_name = AwsUtils.eksClusterName(cluster_rid)
            self.__class__._eks = EksCluster(
                self.cloud,
                cluster_rid,
                name=cluster_name,
                role_arn=self.iam_role.arn,
                vpc_config=EksClusterVpcConfig(
                    subnet_ids=[
                        self.cloud.subnets[SubnetType.EksPrimary].id,
                        self.cloud.subnets[SubnetType.EksSecondary].id,
                    ],
                    endpoint_private_access=True,
                    endpoint_public_access=True,
                ),
                version=self.props.cluster_version,
                tags=Tags(self.cloud, cluster_name).to_dict,
                depends_on=self.cloud.internet_connection,
            )

            kube_proxy_addon_name = f"{self.NAME_PREFIX}-kube-proxy-addon"
            EksAddon(
                self.cloud,
                kube_proxy_addon_name,
                addon_name="kube-proxy",
                preserve=False,
                cluster_name=self.__class__._eks.name,
                tags=Tags(self.cloud, kube_proxy_addon_name).to_dict,
                depends_on=[self.vpc_cni_addon],
            )
        return self.__class__._eks

    @property
    def service_node(self) -> EksNodeGroup:
        """
        Creates and configures a service EKS Node Group.

        Returns:
            EksNodeGroup:
                An object representing the configured service EKS Node Group.
        """
        if self.__class__._service_node is None:
            self.__class__._service_node = self._ObtainNodeGroup(
                self._ami_types_mapping[StageRunnerOS.Linux][StageRunnerCPUArch.x86_64],
                self.SERVICE_INSTANCE_TYPE,
                desired_size=1,
                max_size=1,
                depends_on=[
                    # Service node group should be deleted before VPC-CNI to prevent NetworkInterface in-use lock
                    # https://github.com/hashicorp/terraform-provider-aws/issues/9495#issuecomment-563265999
                    self.vpc_cni_addon
                ],
            )
        return self.__class__._service_node

    @property
    def node_group(self) -> EksNodeGroup:
        """
        Creates and configures an EKS Node Group.

        Returns:
            EksNodeGroup:
                An object representing the configured EKS Node Group.
        """
        return self._ObtainNodeGroup(
            self._ami_types_mapping[self.props.os][self.props.arch],
            self._instance_types_mapping[self.props.arch][self.props.compute_size],
            labels={
                # https://github.com/kubernetes/autoscaler/blob/master/cluster-autoscaler/cloudprovider/aws/README.md#auto-discovery-setup
                "runnergroup": {"value": self.static_tag, "prefix": "k8s.io/cluster-autoscaler/node-template/label/"},
            },
        )

    @property
    def eks_helm(self) -> EksHelmProvider:
        """
        Creates and configures an EKS Helm Provider.

        Returns:
            EksHelmProvider:
                An object representing the configured EKS Helm Provider.
        """
        if self.__class__._eks_helm is None:
            self.__class__._eks_helm = EksHelmProvider(self, f"{self.NAME_PREFIX}-helm")
        return self.__class__._eks_helm

    @property
    def static_tag(self) -> str:
        """
        Creates a static tag for all EKS Node Group.

        Returns:
            str:
                A string containing a static tag for EKS Node Group.
        """
        return f"{self.props.os.value}-{self.props.arch.value}-{self.props.compute_size.value}"

    @property
    def tag(self) -> str:
        """
        Creates a tag for EKS Node Group.

        Returns:
            str:
                A string containing a tag for EKS Node Group.
        """
        # Dependency hack, embedding token to self tag to build correct dependecies on the node group
        return f"{self.static_tag}{Fn.replace(self.node_group.arn, '/.*/', '')}"

    @property
    def labels(self) -> List[str]:
        """
        Creates labels for EKS Node Group.

        Returns:
            List(str):
                A list containing labels for EKS Node Group.
        """
        return [
            "self-hosted",
            "k8s-api",
            self.tag,
        ]

    @property
    def _node_group_role(self) -> IamRole:
        """
        Creates and configures an IAM role for a node group.

        Returns:
            IamRole:
                An object representing the configured AWS IAM Role.
        """
        if self.__class__.__node_group_role is None:
            assume_role = DataAwsIamPolicyDocument(
                self.cloud,
                f"{self.NAME_PREFIX}-assume-node-role-policy",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=["sts:AssumeRole"],
                        effect="Allow",
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                identifiers=["ec2.amazonaws.com"], type="Service"
                            )
                        ],
                    )
                ],
            )

            iam_role_rid = f"{self.provider.name}-{self.NAME_PREFIX}-node-group-role"
            iam_role_name = AwsUtils.iamRoleName(iam_role_rid)
            self.__class__.__node_group_role = IamRole(
                self.cloud,
                iam_role_rid,
                name=iam_role_name,
                assume_role_policy=Token.as_string(assume_role.json),
            )

            ami_policy_document = DataAwsIamPolicyDocument(
                self,
                f"{iam_role_rid}-ami-policy-document",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=[
                            "ec2:DescribeImages",
                            "ec2:DeregisterImage",
                            "ec2:RegisterImage",
                            "ec2:ImportSnapshot",
                            "ec2:DescribeSnapshots",
                            "ec2:DescribeImportSnapshotTasks",
                        ],
                        resources=["*"],
                    ),
                ],
            )

            ami_policy_name = AwsUtils.iamPolicyName(f"{iam_role_rid}-ami-policy")
            ami_policy = IamPolicy(
                self,
                f"{iam_role_rid}-ami-policy",
                name=ami_policy_name,
                policy=ami_policy_document.json,
                tags=Tags(self, ami_policy_name).to_dict,
            )

            IamRolePolicyAttachment(
                self.cloud,
                f"{iam_role_rid}-ami-policy-attachment",
                policy_arn=ami_policy.arn,
                role=self.__class__.__node_group_role.name,
            )

            IamRolePolicyAttachment(
                self.cloud,
                f"{self.NAME_PREFIX}-AmazonEKSWorkerNodePolicy",
                policy_arn="arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy",
                role=self.__class__.__node_group_role.name,
            )

            IamRolePolicyAttachment(
                self.cloud,
                f"{self.NAME_PREFIX}-AmazonEKS_CNI_Policy",
                policy_arn="arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy",
                role=self.__class__.__node_group_role.name,
            )

            IamRolePolicyAttachment(
                self.cloud,
                f"{self.NAME_PREFIX}-AmazonEC2ContainerRegistryReadOnly",
                policy_arn="arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly",
                role=self.__class__.__node_group_role.name,
            )

            IamRolePolicyAttachment(
                self.cloud,
                f"{self.NAME_PREFIX}-registries",
                policy_arn=self.registry_policy.arn,
                role=self.__class__.__node_group_role.name,
            )

            IamRolePolicyAttachment(
                self.cloud,
                f"{self.NAME_PREFIX}-provider-misc-bucket",
                policy_arn=self.provider.misc_s3_bucket_ro_policy.arn,
                role=self.__class__.__node_group_role.name,
            )
        return self.__class__.__node_group_role

    @property
    def registry_policy(self) -> IamPolicy:
        """
        Creates and configures an AWS IAM Policy for registries.

        This function ensures that the IAM Policy is created with a valid name and
        that the policy document specifies fine-grained permissions for designated actions and
        may include conditional statements to enforce specific requirements for those actions.
        Additionally, it applies the appropriate tags to the IAM Policy.

        Returns:
            IamPolicy:
                An object representing the AWS IAM Policy.
        """
        if self._registry_policy is None:
            rid = f"{self.NAME_PREFIX}-registry-policy"
            reg_name = AwsUtils.iamPolicyName(rid)
            statements = [
                DataAwsIamPolicyDocumentStatement(**registry_statements)
                for registry_info in self.props.registry_policy_info
                for registry_statements in registry_info["info"]
            ]
            self._registry_policy = IamPolicy(
                self,
                rid,
                name=reg_name,
                policy=DataAwsIamPolicyDocument(
                    self,
                    f"{rid}-doc",
                    statement=statements,
                ).json,
                tags=Tags(self, reg_name).to_dict,
            )
        return self._registry_policy

    class EksNodeGroupLabel(TypedDict):
        """
        A TypedDict representing the labels applied to an EKS node group.

        Attributes:
            value (`str`):
                The value of the label.
            prefix (`str`):
                The prefix used for the label.
        """

        value: str
        prefix: str

    def _ObtainNodeGroup(
        self,
        ami_type: str,
        instance_type: str,
        desired_size: Optional[int] = None,
        max_size: Optional[int] = None,
        labels: Dict[str, Union[str, EksNodeGroupLabel]] = {},
        depends_on: List[ITerraformDependable] = [],
    ) -> EksNodeGroup:
        """
        Creates and configures EKS Node Group.

        Parameters:
            ami_type (`str`):
                A string that contains the type of the AMI.
            instance_type (`str`):
                A string that contains the type of the instance.
            desired_size (`int`):
                An integer that contains the desired amount of nodes in the group.
            max_size (`int`):
                An integer that contains the maximum amount of nodes in the group.
            depends_on (`List[ITerraformDependable]`):
                A list of Terraform dependencies that the EKS Node Group depends on.
            labels (`Dict[str, Union[str, EksNodeGroupLabel]]`):
                A dictionary where each key-value pair represents the label key and
                its corresponding value for the EKS Node Group labels.
                The value can be a string or an instance of EksNodeGroupLabel.

        Returns:
            EksNodeGroup:
                An object representing the configured EKS Node Group.
        """
        node_key = (ami_type, instance_type)
        if node_key not in self.__class__._node_groups:
            rid = f"{self.provider.name}-{ami_type}-{instance_type}-node-group"
            name = AwsUtils.eksNodeGroupName(rid)

            tags = Tags(self.cloud, name).to_dict
            self.__class__._node_groups[node_key] = EksNodeGroup(
                self.cloud,
                rid,
                cluster_name=self.eks.name,
                node_group_name=name,
                node_role_arn=self._node_group_role.arn,
                subnet_ids=[
                    self.cloud.subnets[SubnetType.EksPrimary].id,
                    self.cloud.subnets[SubnetType.EksSecondary].id,
                ],
                scaling_config=EksNodeGroupScalingConfig(
                    desired_size=desired_size or self.props.scaling_desired,
                    max_size=max_size or self.props.scaling_max,
                    min_size=0,
                ),
                ami_type=ami_type,
                capacity_type="ON_DEMAND",
                disk_size=self.props.node_disk_size,
                instance_types=[instance_type],
                labels={key: label if isinstance(label, str) else label["value"] for key, label in labels.items()},
                tags=tags,
                lifecycle=TerraformResourceLifecycle(ignore_changes=["scaling_config[0].desired_size"]),
                depends_on=[
                    # https://github.com/hashicorp/terraform-provider-aws/issues/9495#issuecomment-563265999
                    self._node_group_role,
                ]
                + depends_on,
            )
            node_group = self.__class__._node_groups[node_key]
            AWSRunnerNotifications.SetupAlarms(self)
            labels.update(tags)
            for key, label in labels.items():
                AutoscalingGroupTagA(
                    self.cloud,
                    f"{rid}-{key}-asg-tag",
                    autoscaling_group_name=node_group.resources.get(0).autoscaling_groups.get(0).name,
                    tag=AutoscalingGroupTagTag(
                        key=key if isinstance(label, str) else f'{label["prefix"]}{key}',
                        value=label if isinstance(label, str) else label["value"],
                        propagate_at_launch=True,
                    ),
                )
        return self.__class__._node_groups[node_key]
