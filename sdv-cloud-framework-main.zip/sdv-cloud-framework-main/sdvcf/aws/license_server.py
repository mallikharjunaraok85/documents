import os
import re
from enum import Enum, auto
from importlib.resources import as_file, files
from typing import Any, Dict, List, Optional

from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.secretsmanager_secret import SecretsmanagerSecret
from cdktf_cdktf_provider_aws.secretsmanager_secret_policy import (
    SecretsmanagerSecretPolicy,
)
from cdktf_cdktf_provider_aws.secretsmanager_secret_version import (
    SecretsmanagerSecretVersion,
)

from sdvcf.interface import IPrivateCloud
from sdvcf.output import Output
from sdvcf.tags import Tags

from .enums import SubnetType
from .provider import AWSProvider
from .service_machine import AWSServiceMachine, AWSServiceMachineProps
from .vpc import AWSVpc


class Secrets(str, Enum):
    """
    An enumeration of secret identifiers.

    Attributes:
        UserEmail:
            An identifier for a user's email secret.
        UserPassword:
            An identifier for a user's password secret.
        License:
            An identifier for a license secret.
    """

    UserEmail = "user_email"
    UserPassword = "user_password"
    License = "license"


class ACLTypes(Enum):
    """
    Enumeration of Access Control List (ACL) types.

    Attributes:
        subnet:
            Represents an ACL type for a subnet.
    """

    subnet = auto()


class AwsQNXLicenseServerProps:
    """
    AwsQNXLicenseServerProps is a configuration class that extends AWSServiceMachineProps,
    adding QNX-specific properties.

    Attributes:
        user_email (str):
            User's email.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        user_password (str):
            User's password.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        license (str):
            License key or string.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        lmgrd_port (int):
            Port number on which the license manager daemon (lmgrd) will run.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        qnxlm_port (int):
            Port number on which the QNX license manager will run.
            This can be either specified directly or
            inferred from an environment variable with a default value.
    """

    user_email: str
    user_password: str
    license: str
    lmgrd_port: int
    qnxlm_port: int

    def __init__(
        self,
        user_email: str = "",
        user_password: str = "",
        license: str = "",
        lmgrd_port: Optional[int] = None,
        qnxlm_port: Optional[int] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self.user_email = user_email or os.getenv("QNX_LICENCE_SERVER_USER_EMAIL", "")
        self.user_password = user_password or os.getenv("QNX_LICENCE_SERVER_USER_PASSWORD", "")
        self.license = re.sub(r"[-]", "", license or os.getenv("QNX_LICENCE_SERVER_LICENSE", ""))
        self.lmgrd_port = lmgrd_port or int(os.getenv("QNX_LMGRD_LICENCE_SERVER_PORT", 27000))
        self.qnxlm_port = qnxlm_port or int(os.getenv("QNX_QNXLM_LICENCE_SERVER_PORT", 51885))


class AwsQNXLicenseServer(AWSServiceMachine):
    """
    Class that contains resources for QNX License Server.

    This class provides the creation and setup of the QNX License Server using AWS resources.

    Inherits from ILicenseServer.

    Attributes:
        provider (AWSProvider):
            The instance of the AWS Provider.
        cloud (AWSVpc):
            The instance of the AWS VPC.
        license_server_props (AwsQNXLicenseServerProps):
            The instance of the QNX License Server properties.
        props (AWSServiceMachineProps):
            The instance of Service Machine props.

    Private Attributes:
        _user_email_secret (SecretsmanagerSecret):
            Lazily initialized SecretsmanagerSecret representation for user's email.
            None until accessed.
        _user_password_secret (SecretsmanagerSecret):
            Lazily initialized SecretsmanagerSecret representation for user's password.
            None until accessed.
        _license_secret (SecretsmanagerSecret):
            Lazily initialized SecretsmanagerSecret representation for user's license.
            None until accessed.

    Public static class constants
        OS (str):
            Specified Service Machine OS.
        INSTANCE_TYPE (str):
            A string that contains the default instance type.
        MISC_BUCKET_PREFIX (str):
            A string that contains the default misc bucket prefix.

    Public class constants
        NAME_PREFIX (str):
            A string that contains the prefix for the names of all created resources.

    Methods:
        GetAclCidrBlocks:
            Retrieves the CIDR blocks from ACL items.

    Properties:
        secrets:
            Returns the dictionary containing user's secrets,
            initializing it if it has not been already.
        type:
            Returns "LicenseServer" string - framework component type.
        posix_username:
            Returns user name of Service Machine OS user.
        exposed_ports:
            Returns list of Service Machine exposed ports.
    """

    cloud: AWSVpc
    provider: AWSProvider

    OS: str = "Ubuntu22.04"
    INSTANCE_TYPE: str = "t3.medium"
    MISC_BUCKET_PREFIX: str = "LicenseServer/QNX"

    NAME_PREFIX: str

    props: AWSServiceMachineProps
    license_server_props: AwsQNXLicenseServerProps
    acl: List[Dict[str, str]]

    _user_email_secret: Optional[SecretsmanagerSecret]
    _user_password_secret: Optional[SecretsmanagerSecret]
    _license_secret: Optional[SecretsmanagerSecret]

    def __init__(
        self, cloud: IPrivateCloud, ns: str, license_server_props: AwsQNXLicenseServerProps, acl: List[Dict[str, str]]
    ):
        self.license_server_props = license_server_props
        self.acl = acl
        self.props = AWSServiceMachineProps(
            disk_size=20,
            ingress_cidr_blocks=self.GetAclCidrBlocks(cloud),
            itype=self.INSTANCE_TYPE,
            os=self.OS,
            ports=[self.license_server_props.lmgrd_port, self.license_server_props.qnxlm_port],
            subnet=cloud.subnets[SubnetType.Secondary],
        )
        super().__init__(cloud, ns, self.props)

        assert isinstance(self.cloud, AWSVpc)
        assert isinstance(self.provider, AWSProvider)

        self.NAME_PREFIX = f"{self.provider.name}-{self.name}-qnx-ls"

        self._user_email_secret = None
        self._user_password_secret = None
        self._license_secret = None

        with as_file(files("sdvcf.aws.resources").joinpath("license-server/scripts/qnx-license-server.sh")) as file:
            self.AddUserDataFile(
                file,
                {
                    "user": self.posix_username,
                    "region": self.cloud.region,
                    "user_email_secret_id": self.secrets[Secrets.UserEmail].id,
                    "user_password_secret_id": self.secrets[Secrets.UserPassword].id,
                    "license_secret_id": self.secrets[Secrets.License].id,
                    "bucket": self.provider.misc_s3_bucket.bucket,
                },
            )

        Output(
            self,
            id="flexlm_host",
            value=f"{self.license_server_props.lmgrd_port}@{self.instance.private_dns}",
            resource_id=self.instance.arn,
        )

    @property
    def secrets(self) -> Dict[str, SecretsmanagerSecret]:
        """
        Creates AWS Secrets Manager secrets for storing user's sensitive information.

        This property ensures that all necessary secrets, such as user credentials,
        are securely created and managed in AWS Secrets Manager.

        Returns:
            Dict[str, SecretsmanagerSecret]:
                A dictionary where each key is a string representing the secret's name,
                and the corresponding value is an instance of SecretsmanagerSecret
                containing the secret's details.
        """

        def CreateSecret(name: str, secret_string: str) -> SecretsmanagerSecret:
            rid = f"{self.NAME_PREFIX}-{name}-secret"
            secret = SecretsmanagerSecret(
                self,
                rid,
                name=rid,
                tags=Tags(self, rid).to_dict,
            )

            secret_policy_document = DataAwsIamPolicyDocument(
                self,
                f"{rid}-iam-policy-document",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(type="AWS", identifiers=[self.iam_role.arn])
                        ],
                        actions=[
                            "secretsmanager:GetSecretValue",
                            "secretsmanager:DescribeSecret",
                        ],
                        resources=[
                            secret.arn,
                        ],
                    ),
                ],
            )
            SecretsmanagerSecretPolicy(
                self,
                f"{rid}-policy",
                policy=secret_policy_document.json,
                secret_arn=secret.arn,
            )
            SecretsmanagerSecretVersion(
                self,
                f"{rid}-version",
                secret_id=secret.id,
                secret_string=secret_string,
            )
            return secret

        if self._user_email_secret is None:
            self._user_email_secret = CreateSecret(Secrets.UserEmail.value, self.license_server_props.user_email)

        if self._user_password_secret is None:
            self._user_password_secret = CreateSecret(
                Secrets.UserPassword.value, self.license_server_props.user_password
            )

        if self._license_secret is None:
            self._license_secret = CreateSecret(Secrets.License.value, self.license_server_props.license)

        return {
            Secrets.UserEmail: self._user_email_secret,
            Secrets.UserPassword: self._user_password_secret,
            Secrets.License: self._license_secret,
        }

    def GetAclCidrBlocks(self, cloud: IPrivateCloud) -> List[str]:
        """
        Retrieves the CIDR blocks from ACL items.

        This method extracts the CIDR blocks from ACL items and returns them as a list of strings.

        Parameters:
            None:
                This method does not have any parameters.

        Returns:
            List(str):
                A list of strings, each representing a CIDR block.
        """
        acl_cidr_blocks = []
        for acl in self.acl:
            type = acl["type"]
            if ACLTypes[type] == ACLTypes.subnet:
                subnet_type = SubnetType[acl["name"]]
                acl_cidr_blocks.append(cloud.subnets[subnet_type].cidr_block)
        return acl_cidr_blocks

    @property
    def type(self) -> str:
        return "LicenseServer"

    @property
    def posix_username(self) -> str:
        return self._ami_os_family_mapping[self.props.os]

    @property
    def exposed_ports(self) -> List[int]:
        return self.props.ports
