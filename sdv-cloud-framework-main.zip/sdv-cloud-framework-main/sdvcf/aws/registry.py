from typing import Any, Dict, List, Optional, Union

from cdktf import Fn
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementCondition,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.ecr_lifecycle_policy import EcrLifecyclePolicy
from cdktf_cdktf_provider_aws.ecr_repository import EcrRepository
from cdktf_cdktf_provider_aws.ecr_repository_policy import EcrRepositoryPolicy
from cdktf_cdktf_provider_aws.ecrpublic_repository import EcrpublicRepository
from cdktf_cdktf_provider_aws.ecrpublic_repository_policy import (
    EcrpublicRepositoryPolicy,
)
from cdktf_cdktf_provider_aws.s3_bucket import S3Bucket
from cdktf_cdktf_provider_aws.s3_bucket_acl import S3BucketAcl
from cdktf_cdktf_provider_aws.s3_bucket_cors_configuration import (
    S3BucketCorsConfiguration,
)
from cdktf_cdktf_provider_aws.s3_bucket_lifecycle_configuration import (
    S3BucketLifecycleConfiguration,
    S3BucketLifecycleConfigurationRule,
    S3BucketLifecycleConfigurationRuleExpiration,
    S3BucketLifecycleConfigurationRuleFilter,
    S3BucketLifecycleConfigurationRuleFilterAnd,
)
from cdktf_cdktf_provider_aws.s3_bucket_ownership_controls import (
    S3BucketOwnershipControls,
    S3BucketOwnershipControlsRule,
)
from cdktf_cdktf_provider_aws.s3_bucket_policy import S3BucketPolicy
from cdktf_cdktf_provider_aws.s3_bucket_public_access_block import (
    S3BucketPublicAccessBlock,
)

from sdvcf.interface import IPrivateCloud, IRegistry, RegistryProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .provider import AWSProvider
from .utils import AwsUtils
from .vpc import AWSVpc


class AWSRegistry(IRegistry):
    """
    Class that contains resources for a registry implementation in AWS using S3 Bucket.

    Inherits from IRegistry.

    Private Attributes:
        _bucket (S3Bucket):
            Lazily initialized AWS S3 Bucket representation.
            None until accessed.
        _rw_policy_statements (List[Dict[str, Any]]):
            List of dictionaries containing registry policy statements.
        _ro_policy_doc (DataAwsIamPolicyDocument):
            Lazily initialized AWS IAM Policy Document representation.
            None until accessed.

    Methods:
        GetUniqueID:
            Get an ARN of the registry.
        GetUrl:
            Get a URL of the registry.
        GetPolicyInfo:
            Get a dictionary containing the policy information of the registry.

    Properties:
        bucket:
            Returns the S3Bucket instance, initializing it if it has not been already.
        rw_policy_statements:
            Returns the list of dictionaries containing RW Policy statements.
        ro_policy_doc:
            Returns the DataAwsIamPolicyDocument instance, initializing it if it has not been already.
    """

    cloud: AWSVpc
    provider: AWSProvider

    _bucket: Optional[S3Bucket]
    _rw_policy_statements: Optional[List[Dict[str, Any]]]
    _ro_policy_doc: Optional[DataAwsIamPolicyDocument]

    def __init__(self, cloud: IPrivateCloud, ns: str, props: RegistryProps, tags: Dict[str, str] = {}):
        super().__init__(cloud.provider, ns, props=props)

        assert isinstance(cloud, AWSVpc)
        self.cloud = cloud

        self._bucket = None
        self._rw_policy_statements = None
        self._ro_policy_doc = None

        self._tags = tags

    @property
    def bucket(self) -> S3Bucket:
        """
        Creates and configures a S3 Bucket.

        Returns:
            S3Bucket:
                An object representing the configured S3 Bucket.
        """
        if self._bucket is None:
            bucket_name = AwsUtils.makeUniqueS3BucketName(f"{self.provider.name}-{self.name}-bucket")
            self._bucket = S3Bucket(
                self,
                bucket_name,
                bucket=bucket_name,
                tags=Tags(self, bucket_name, self._tags).to_dict,
            )
            S3BucketCorsConfiguration(
                self,
                f"{bucket_name}-cors-configuration",
                bucket=self._bucket.id,
                cors_rule=self.provider.s3_bucker_cors_configuration_rule_list,
            )
            policy_name = AwsUtils.iamPolicyName(f"{bucket_name}-ro-policy")

            if self.props.is_public:
                S3BucketPolicy(self, policy_name, policy=self.ro_policy_doc.json, bucket=self._bucket.id)
            if self.props.retention:
                S3BucketLifecycleConfiguration(
                    self,
                    f"{bucket_name}-lcp",
                    bucket=self._bucket.id,
                    rule=[
                        S3BucketLifecycleConfigurationRule(
                            id="retention-rule",
                            status="Enabled",
                            filter=S3BucketLifecycleConfigurationRuleFilter(
                                and_=S3BucketLifecycleConfigurationRuleFilterAnd(tags=self.props.retention["tags"])
                            ),
                            expiration=S3BucketLifecycleConfigurationRuleExpiration(
                                days=self.props.retention["days"],
                            ),
                        ),
                    ],
                )
            Output(
                self,
                id="registry_id",
                value=self._bucket.arn,
                resource_id=self._bucket.arn,
            )
        return self._bucket

    @property
    def rw_policy_statements(self) -> List[Dict[str, Any]]:
        """
        Creates and configures an list of dictionaries containing AWS IAM Policy Statements.

        Returns:
            List[Dict[str, Any]]:
                List of dictionaries containing AWS IAM Policy Statements.
        """
        if self._rw_policy_statements is None:
            self._rw_policy_statements = [
                {
                    "effect": "Allow",
                    "actions": ["s3:*"],
                    "resources": [
                        self.bucket.arn,
                        f"{self.bucket.arn}/*",
                    ],
                },
            ]
        return self._rw_policy_statements

    @property
    def ro_policy_doc(self) -> DataAwsIamPolicyDocument:
        """
        Creates and configures a Read Only IAM Policy Document for the ECR repository.

        Returns:
            DataAwsIamPolicyDocument:
                An object representing the IAM Policy Document for the ECR repository.
        """
        if self._ro_policy_doc is None:
            rid = f"{self.name}"
            bucket_ownership_controls = S3BucketOwnershipControls(
                self,
                f"{self.name}-bucket-os-controls",
                bucket=self.bucket.id,
                rule=S3BucketOwnershipControlsRule(object_ownership="BucketOwnerPreferred"),
            )
            bucket_public_access_block = S3BucketPublicAccessBlock(
                self,
                f"{self.name}-bucket-pab",
                bucket=self.bucket.id,
                block_public_acls=False,
                block_public_policy=False,
                ignore_public_acls=False,
                restrict_public_buckets=False,
            )
            acl = S3BucketAcl(
                self,
                f"{self.name}-bucket-acl",
                acl="public-read",
                bucket=self.bucket.id,
                depends_on=[bucket_ownership_controls, bucket_public_access_block],
            )
            principals = [
                DataAwsIamPolicyDocumentStatementPrincipals(
                    identifiers=["*"],
                    type="*",
                )
            ]
            self._ro_policy_doc = DataAwsIamPolicyDocument(
                self,
                f"{rid}-ro-pd",
                statement=(
                    [
                        DataAwsIamPolicyDocumentStatement(
                            principals=principals,
                            effect="Allow",
                            actions=["s3:GetObject"],
                            resources=[
                                f"{self.bucket.arn}/*",
                            ],
                        )
                    ]
                    if self.props.is_public
                    else [
                        DataAwsIamPolicyDocumentStatement(
                            principals=principals,
                            effect="Allow",
                            actions=["s3:GetObject", "s3:List*"],
                            resources=[
                                self.bucket.arn,
                                f"{self.bucket.arn}/*",
                            ],
                            condition=[
                                DataAwsIamPolicyDocumentStatementCondition(
                                    test="IpAddress",
                                    variable="aws:SourceIp",
                                    values=[f"{self.cloud.nat_gw_eip.public_ip}/32"],
                                )
                            ],
                        ),
                        DataAwsIamPolicyDocumentStatement(
                            principals=principals,
                            effect="Allow",
                            actions=["s3:*"],
                            resources=[
                                self.bucket.arn,
                                f"{self.bucket.arn}/*",
                            ],
                            condition=[
                                DataAwsIamPolicyDocumentStatementCondition(
                                    test="StringEquals",
                                    variable="aws:PrincipalAccount",
                                    values=[self.provider.caller_identity.account_id],
                                ),
                            ],
                        ),
                    ]
                ),
                depends_on=[acl],
            )
        return self._ro_policy_doc

    def GetUniqueID(self) -> str:
        """
        Get an ARN of the registry.

        Returns:
            str: A unique identifier as a string.
        """
        return self.bucket.arn

    def GetURL(self) -> str:
        """
        Get a URL of the registry.

        Returns:
            str: A URL as a string.
        """
        # F-String may cause undefined behavior in complex Terraform constructions,
        # join() is a better alternative.
        return Fn.join("", ["https://", self.bucket.bucket_regional_domain_name])

    def GetPolicyInfo(self) -> Dict[str, Any]:
        """
        Method to get an information about the registry's IAM policy.

        Returns:
            Dict: A dictionary of policy's info.
        """
        return {"info": self.rw_policy_statements, "name": f"{self.name}"}


# Wrapper class to align EcrpublicRepository and EcrRepository interfaces
class WrapperEcrpublicRepository(EcrpublicRepository):
    """
    This class is a wrapper which aligns the interfaces of EcrpublicRepository and
    EcrRepository by providing a unified property interface.

    Properties:
        repository_name (str):
            Gets the name of the repository.

        repository_url (str):
            Gets the URL of the repository.
    """

    @property
    def name(self) -> str:
        return self.repository_name

    @property
    def repository_url(self) -> str:
        return self.repository_uri


class AWSEcr(IRegistry):
    """
    Class that contains resources for a registry implementation in AWS using ECR.

    Inherits from IRegistry.

    Private Attributes:
        _repository (Union[EcrRepository, WrapperEcrpublicRepository]):
            Lazily initialized AWS ECR repository representation.
            None until accessed.
        _rw_policy_statements (List[Dict[str, Any]]):
            List of dictionaries containing registry policy statements.
        _ro_policy_doc (DataAwsIamPolicyDocument):
            Lazily initialized AWS IAM Policy Document representation.
            None until accessed.

    Methods:
        GetUniqueID:
            Get an ARN of the registry.
        GetUrl:
            Get a URL of the registry.
        GetPolicyInfo:
            Get a dictionary containing the policy information of the registry.

    Properties:
        repository:
            Returns either EcrRepository or WrapperEcrpublicRepository instance,
            initializing it if it has not been already.
        rw_policy_statements:
            Returns the list of dictionaries containing RW Policy statements.
        ro_policy_doc:
            Returns the DataAwsIamPolicyDocument instance, initializing it if it has not been already.
    """

    _repository: Optional[Union[EcrRepository, WrapperEcrpublicRepository]]
    _rw_policy_statements: Optional[List[Dict[str, Any]]]
    _ro_policy_doc: Optional[DataAwsIamPolicyDocument]

    def __init__(self, cloud: IPrivateCloud, ns: str, props: RegistryProps, tags: Dict[str, str] = {}):
        super().__init__(cloud.provider, ns, props=props)

        assert isinstance(cloud, AWSVpc)
        self.cloud = cloud

        self._repository = None
        self._rw_policy_statements = None
        self._ro_policy_doc = None

        self._tags = tags

    @property
    def repository(self) -> Union[EcrRepository, WrapperEcrpublicRepository]:
        """
        Creates and configures either EcrRepository or WrapperEcrpublicRepository.

        Returns:
            Union[EcrRepository, WrapperEcrpublicRepository]:
                An object representing the configured AWS ECR.
        """
        if self._repository is None:
            rid = f"{self.provider.name}-{self.name}-ecr"
            name = AwsUtils.ecrName(self.name)
            if self.props.is_public:
                self._repository = WrapperEcrpublicRepository(
                    self,
                    f"{rid}-repository",
                    repository_name=name,
                    provider=self.cloud.provider.default,
                    tags=Tags(self, self.name, self._tags).to_dict,
                )
                EcrpublicRepositoryPolicy(
                    self,
                    f"{rid}-ro-policy",
                    provider=self.cloud.provider.default,
                    repository_name=self._repository.name,
                    policy=self.ro_policy_doc.json,
                )
            else:
                self._repository = EcrRepository(
                    self,
                    f"{rid}-repository",
                    name=name,
                    image_tag_mutability="MUTABLE",
                    force_delete=True,
                    tags=Tags(self, f"{rid}-repository", self._tags).to_dict,
                )
                EcrRepositoryPolicy(
                    self,
                    f"{rid}-ro-policy",
                    repository=self._repository.name,
                    policy=self.ro_policy_doc.json,
                )
                EcrLifecyclePolicy(
                    self,
                    f"{rid}-rlp",
                    repository=self._repository.name,
                    policy="""
                            {
                                "rules": [
                                        {
                                            "rulePriority": 1,
                                            "description": "Keep last 30 images",
                                            "selection": {
                                                "tagStatus": "tagged",
                                                "tagPrefixList": ["latest"],
                                                "countType": "imageCountMoreThan",
                                                "countNumber": 30
                                            },
                                            "action": {
                                                "type": "expire"
                                            }
                                        }
                                ]
                            }
                            """,
                )
            Output(
                self,
                id="container_registry_id",
                value=self._repository.arn,
                resource_id=self._repository.arn,
            )
        return self._repository

    @property
    def rw_policy_statements(self) -> List[Dict[str, Any]]:
        """
        Creates and configures an list of dictionaries containing AWS IAM Policy Statements.

        Returns:
            List[Dict[str, Any]]:
                List of dictionaries containing AWS IAM Policy Statements.
        """
        if self._rw_policy_statements is None:
            self._rw_policy_statements = (
                [
                    {"effect": "Allow", "actions": ["ecr-public:*"], "resources": [self.repository.arn]},
                    {
                        "effect": "Allow",
                        "actions": ["ecr-public:GetAuthorizationToken", "sts:GetServiceBearerToken"],
                        "resources": ["*"],
                    },
                ]
                if self.props.is_public
                else [
                    {"effect": "Allow", "actions": ["ecr:*"], "resources": [self.repository.arn]},
                    {
                        "effect": "Allow",
                        "actions": ["ecr:GetAuthorizationToken", "sts:GetServiceBearerToken"],
                        "resources": ["*"],
                    },
                ]
            )
        return self._rw_policy_statements

    @property
    def ro_policy_doc(self) -> DataAwsIamPolicyDocument:
        """
        Creates and configures a Read Only IAM Policy Document for the ECR repository.

        Returns:
            DataAwsIamPolicyDocument:
                An object representing the IAM Policy Document for the ECR repository.
        """
        if self._ro_policy_doc is None:
            rid = f"{self.provider.name}-{self.name}"

            self._ro_policy_doc = DataAwsIamPolicyDocument(
                self,
                f"{rid}-pd",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                identifiers=["*"],
                                type="*",
                            )
                        ],
                        effect="Allow",
                        actions=[
                            "ecr:GetAuthorizationToken",
                            "ecr:BatchCheckLayerAvailability",
                            "ecr:GetDownloadUrlForLayer",
                            "ecr:GetRepositoryPolicy",
                            "ecr:DescribeRepositories",
                            "ecr:ListImages",
                            "ecr:DescribeImages",
                            "ecr:BatchGetImage",
                            "ecr:GetLifecyclePolicy",
                            "ecr:GetLifecyclePolicyPreview",
                            "ecr:ListTagsForResource",
                            "ecr:DescribeImageScanFindings",
                        ],
                    )
                ],
            )
        return self._ro_policy_doc

    def GetUniqueID(self) -> str:
        """
        Get an ARN of the registry.

        Returns:
            str: A unique identifier as a string.
        """
        return self.repository.arn

    def GetURL(self) -> str:
        """
        Get a URL of the registry.

        Returns:
            str: A URL as a string.
        """
        # F-String may cause undefined behavior in complex Terraform constructions,
        # join() is a better alternative.
        return Fn.join("", ["https://", self.repository.repository_url])

    def GetPolicyInfo(self) -> Dict[str, Any]:
        """
        Method to get an information about the registry's IAM policy.

        Returns:
            Dict: A dictionary of policy's info.
        """
        return {"info": self.rw_policy_statements, "name": f"{self.name}"}
