import json
from collections import defaultdict
from copy import deepcopy
from enum import Enum, auto
from string import Template
from typing import TYPE_CHECKING, Any, Dict, List, Union

from cdktf_cdktf_provider_aws.cloudwatch_dashboard import CloudwatchDashboard

from sdvcf.interface.i_dashboard import IDashboard

from .utils import AwsUtils

if TYPE_CHECKING:
    from .provider import AWSProvider


class AWSDashboardWidgetType(Enum):
    """
    Enumeration for AWS Dashboard Widget Types.

    This enumeration defines the types of widgets that can be used on an AWS CloudWatch Dashboard.

    Attributes:
        EXPLORER:
            Represents a widget type that is used for AWS Resource Explorer
            which allows you to visually browse and discover AWS resources.
        METRIC:
            Represents a widget type that displays metric data from AWS services,
            allowing you to monitor and analyze these metrics over time.
    """

    EXPLORER = auto()
    METRIC = auto()


class AWSDashboard(IDashboard):
    """
    Class responsible for the creation and configuration of dashboards in AWS.

    This class inherits from the IDashboard.

    Attributes:
        provider (`AWSProvider`):
            The instance of the AWSProvider associated with this dashboard.
        _widgets (`Dict[str, Dict[str, Any]`):
            A dictionary that stores the widgets' titles and their respective properties.

    Methods:
        EnableWidget:
            Enable a widget to be processed further,
        _RecursiveStringSubstitution:
            Perform recursive string substitution on the given target.
        Commit:
            Commits the configuration and creates the dashboard with all enabled widgets.
        _TransformWidgetProperties:
            Convert widget properties into a JSON template based on the widget type.
    """

    provider: "AWSProvider"

    _widgets: Dict[str, Dict[str, Any]]

    def __init__(self, provider: "AWSProvider") -> None:
        self.provider = provider

        self._widgets = defaultdict(dict)

    def EnableWidget(self, widget: Enum, **kwargs: Any) -> None:
        """
        Enables a widget to be included in further dashboard generation.

        Parameters:
            widget (`Enum`):
                Widget type to be enabled.
            **kwargs (`Any`):
                Additional keyword arguments representing widgets' configuration properties.

        Raises:
            NotImplementedError:
                If the requested widget type is not supported yet.

        Returns:
            None:
                This method does not return any value.
        """
        WIDGET_PROPS = {
            self.WigdetTypes.SharedFSSize: {
                "type": AWSDashboardWidgetType.EXPLORER,
                "title": "EFS Total Storage Usage",
                "metricName": "StorageBytes",
                "resourceType": "AWS::EFS::FileSystem",
                "stat": "Sum",
                "period": 900,
            },
            self.WigdetTypes.ProjectStorageSize: {
                "type": AWSDashboardWidgetType.EXPLORER,
                "title": "Storage used by all S3 buckets",
                "metricName": "BucketSizeBytes",
                "resourceType": "AWS::S3::Bucket",
                "stat": "Average",
                "period": 604800,
            },
            self.WigdetTypes.VPNTraffic: {
                "type": AWSDashboardWidgetType.METRIC,
                "title": "VPN Connection Details",
                "metrics": [
                    [
                        "AWS/TransitGateway",
                        "BytesIn",
                        "TransitGatewayAttachment",
                        "$attachment_id",
                        "TransitGateway",
                        "$gateway_id",
                    ],
                    [".", "BytesOut", ".", ".", ".", "."],
                ],
            },
        }

        if widget not in WIDGET_PROPS:
            raise NotImplementedError(f"`{widget.name.lower()}` widget type is not implemented yet")

        props = deepcopy(WIDGET_PROPS[widget])
        if "name" in kwargs:
            props["title"] = f'`{kwargs.get("name")}` {props["title"]}'
        for prop_n, prop_v in props.items():
            props[prop_n] = self._RecursiveStringSubstitution(prop_v, **kwargs)
        self._widgets[props["title"]] = props

    def _RecursiveStringSubstitution(
        self, target: Union[str, List[Any], Any], max_depth: int = 10, **kwargs: Any
    ) -> Union[str, List[Any], Any]:
        """
        Perform recursive string substitution on the given target.

        This method recursively substitutes placeholders in a string or list with provided values.
        It supports a maximum depth for recursive substitution to avoid infinite loops.

        Parameters:
            target (`Union[str, List[Any], Any]`):
                The target string or list to perform substitution on.
            max_depth (`int`):
                The maximum depth for recursive substitution (default is 10).
            **kwargs (`Any`):
                Additional keyword arguments representing placeholders and their values.

        Returns:
            Union[str, List[Any], Any]:
                The result of recursive string substitution on the target.
        """
        if max_depth > 0:
            if isinstance(target, str):
                target = Template(target).substitute(kwargs)
            elif isinstance(target, List):
                target = [self._RecursiveStringSubstitution(subtarget, max_depth - 1, **kwargs) for subtarget in target]
        return target

    def Commit(self) -> None:
        """
        Commits the configuration and creates the dashboard with all enabled widgets.

        This method finalizes the setup of the widgets and generates the dashboard,
        incorporating all the widgets that have been enabled previously.

        Parameters:
            None:
                This method does not have any parameters.

        Returns:
            None:
                This method does not return any value.
        """
        widgets_source_code = []
        for idx, (title, widget) in enumerate(self._widgets.items()):
            widgets_source_code.append(
                {
                    "height": 9,
                    "width": 12,
                    "y": int((idx / 2)) * 9,
                    "x": (idx % 2) * 12,
                    "type": widget["type"].name.lower(),
                    "properties": self._TransformWidgetProperties(title, widget),
                }
            )
        dashboard_name = AwsUtils.cloudwatchDashboardName(f"{self.provider.name}-dashboard")
        CloudwatchDashboard(
            self.provider,
            f"{self.provider.name}-dashboard",
            dashboard_name=dashboard_name,
            dashboard_body=json.dumps({"widgets": widgets_source_code}),
        )

    def _TransformWidgetProperties(self, title: str, widget: Dict[str, Any]) -> Dict[str, Any]:
        """
        Convert widget properties into a JSON template based on the widget type.

        Parameters:
            title (`str`):
                The title of the widget.
            widget (`Dict[str, Any]`):
                A dictionary containing the configuration properties of the widget.

        Raises:
            NotImplementedError:
                If the requested widget type is not supported yet.

        Returns:
            Dict[str, Any]:
                JSON template containing the configuration properties of the widget.
        """
        w_type: AWSDashboardWidgetType = widget["type"]
        if w_type == AWSDashboardWidgetType.METRIC:
            return {
                "view": "timeSeries",
                "stacked": False,
                "metrics": widget["metrics"],
                "region": self.provider.region,
                "title": title,
            }
        elif w_type == AWSDashboardWidgetType.EXPLORER:
            return {
                "metrics": [
                    {
                        "metricName": widget["metricName"],
                        "resourceType": widget["resourceType"],
                        "stat": widget["stat"],
                    }
                ],
                "aggregateBy": {"key": "*", "func": "SUM"},
                "labels": [{"key": "Stack", "value": self.provider.name}],
                "widgetOptions": {
                    "legend": {"position": "hidden"},
                    "view": "timeSeries",
                    "stacked": False,
                    "rowsPerPage": 1,
                    "widgetsPerRow": 1,
                },
                "period": widget["period"],
                "splitBy": "",
                "region": self.provider.region,
                "title": title,
            }
        else:
            raise NotImplementedError(f"`{w_type.name.lower()}` widget type is not implemented yet")
