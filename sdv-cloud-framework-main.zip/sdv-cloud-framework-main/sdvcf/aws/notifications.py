from typing import TYPE_CHECKING, Dict, List, Tuple, Union

from cdktf import Fn, ITerraformDependable
from cdktf_cdktf_provider_aws.cloudwatch_metric_alarm import CloudwatchMetricAlarm
from cdktf_cdktf_provider_aws.data_aws_vpc_endpoint import DataAwsVpcEndpoint
from cdktf_cdktf_provider_aws.sns_topic import SnsTopic
from cdktf_cdktf_provider_aws.sns_topic_subscription import SnsTopicSubscription
from constructs import Construct

from sdvcf.interface import IComponent, INotification
from sdvcf.tags import Tags

from .utils import AwsUtils

if TYPE_CHECKING:
    from .cloud9 import AwsCloud9
    from .compute_server import AWSComputeServer
    from .eks_runner import AwsEksRunner
    from .virtual_desktop import AWSVirtualDesktop
    from .vpc import AWSVpc


class AWSBaseNotification(INotification):
    """
    Class that contains resources for AWS Notifications.

    Inherits from INotification.

    Private Attributes:
        _sns_topics (Dict[Construct, SnsTopic]):
            A dictionary that holds a mapping from cloud constructs to their corresponding SNS Topic resources.
        _sns_subscriptions (Dict[Tuple[Construct, str], SnsTopicSubscription]):
            A dictionary that maps tuples of cloud constructs and
            subscription identifiers to their corresponding SNS Topic Subscription resources.

    Methods:
        _GetSnsTopic:
            Internal method that retrieves an SNS topic associated with a given cloud construct.
        _SnsTopicSubscriptions:
            Internal method that retrieves SNS topic subscription details
            for a given cloud construct and subscription identifier.
    """

    _sns_topics: Dict[Construct, SnsTopic]
    _sns_subscriptions: Dict[Tuple[Construct, str], SnsTopicSubscription]

    @classmethod
    def _GetSnsTopic(cls, scope: Construct) -> SnsTopic:
        """
        Gets an SNS topic associated with a given cloud construct.

        Parameters:
            scope (Construct):
                A string that contains the cloud construct.

        Returns:
            SnsTopic:
                An object representing the SNS Topic.
        """
        if not hasattr(cls, "_sns_topics"):
            cls._sns_topics = {}

        rid_prefix = f"{scope.provider.name}-{scope.name}" if isinstance(scope, IComponent) else scope.node.id

        if scope not in cls._sns_topics:
            rid = f"{rid_prefix}-{cls.__name__.lower()}-sns-topic"
            name = AwsUtils.snsTopicName(rid)
            cls._sns_topics[scope] = SnsTopic(
                scope,
                rid,
                name=name,
                display_name=name,
                tags=Tags(scope, name).to_dict,
            )
        return cls._sns_topics[scope]

    @classmethod
    def _SnsTopicSubscriptions(cls, target: Construct, subscribers: List[str]) -> List[ITerraformDependable]:
        """
        Gets SNS topic subscription details for a given cloud construct and subscription identifier.

        Parameters:
            target (Construct):
                A string that contains the cloud construct.
            subscribers (List[str]):
                A string that list of subscribers.

        Returns:
            List[ITerraformDependable]:
                A list of objects representing the SNS Topic Subscription.
        """
        if not hasattr(cls, "_sns_subscriptions"):
            cls._sns_subscriptions = {}

        ret: List[ITerraformDependable] = []
        for email in subscribers:
            key = (target, email)
            if key not in cls._sns_subscriptions:
                cls._sns_subscriptions[key] = SnsTopicSubscription(
                    target,
                    f"{target.node.id}-{cls.__name__.lower()}-{email}-sns-subscription",
                    protocol="email",
                    topic_arn=cls._GetSnsTopic(target).arn,
                    endpoint=email,
                )
            ret.append(cls._sns_subscriptions[key])
        return ret


class AWSWorkbenchNotifications(AWSBaseNotification):
    """
    Class that contains resources for AWS Workbench Notifications.

    Inherits from AWSBaseNotification.

    Methods:
        SetupAlarms:
            Sets up alarms for the target workbench.
    """

    @classmethod
    def SetupAlarms(
        cls, target: Union["AWSComputeServer", "AWSVirtualDesktop", "AwsCloud9"]
    ) -> List[ITerraformDependable]:
        """
        Sets up alarms for the target workbench.

        Parameters:
            target (Union["AWSComputeServer", "AWSVirtualDesktop", "AwsCloud9"]):
                The target object representing the workbench for which alarms are being set up.
                This could be an AWS Compute Server, AWS Virtual Desktop, or AwsCloud9 instance.

        Returns:
            List[ITerraformDependable]:
                A list of objects representing AWS CloudWatch Metric Alarms.
        """
        NAME_PREFIX = f"{target.provider.name}-{target.name}"

        ret: List[ITerraformDependable] = []

        specific_sns = cls._GetSnsTopic(target) if target.user.email else None
        generic_sns = cls._GetSnsTopic(target.provider)

        system_check_alarm_name = AwsUtils.cloudwatchAlarmName(f"{NAME_PREFIX}-system-check-alarm")
        instance_check_alarm_name = AwsUtils.cloudwatchAlarmName(f"{NAME_PREFIX}-instance-check-alarm")
        instance_cpu_alarm_name = AwsUtils.cloudwatchAlarmName(f"{NAME_PREFIX}-instance-cpu-alarm")

        sns_arns: List[str] = [generic_sns.arn]
        if specific_sns is not None:
            sns_arns.append(specific_sns.arn)

        from .cloud9 import AwsCloud9

        if not isinstance(target, AwsCloud9):
            ret.append(
                CloudwatchMetricAlarm(
                    target,
                    system_check_alarm_name,
                    alarm_name=f"{target.instance.id}_system_check_fail",
                    alarm_description="System check has failed",
                    alarm_actions=(
                        [
                            f"arn:aws:automate:{target.provider.region}:ec2:recover",
                            *sns_arns,
                        ]
                    ),
                    ok_actions=sns_arns,
                    metric_name="StatusCheckFailed_System",
                    namespace="AWS/EC2",
                    dimensions={"InstanceId": target.instance.id},
                    statistic="Maximum",
                    period=300,
                    evaluation_periods=2,
                    datapoints_to_alarm=2,
                    threshold=1,
                    treat_missing_data="notBreaching",
                    comparison_operator="GreaterThanOrEqualToThreshold",
                    tags=Tags(target, system_check_alarm_name).to_dict,
                )
            )
        ret.append(
            CloudwatchMetricAlarm(
                target,
                instance_check_alarm_name,
                alarm_name=f"{target.instance.id}_instance_check_fail",
                alarm_description="Instance check has failed",
                alarm_actions=[
                    f"arn:aws:automate:{target.provider.region}:ec2:reboot",
                    *sns_arns,
                ],
                ok_actions=sns_arns,
                metric_name="StatusCheckFailed_Instance",
                namespace="AWS/EC2",
                dimensions={"InstanceId": target.instance.id},
                statistic="Maximum",
                period=300,
                evaluation_periods=3,
                datapoints_to_alarm=3,
                threshold=1,
                treat_missing_data="notBreaching",
                comparison_operator="GreaterThanOrEqualToThreshold",
                tags=Tags(target, instance_check_alarm_name).to_dict,
            )
        )
        ret.append(
            CloudwatchMetricAlarm(
                target,
                instance_cpu_alarm_name,
                alarm_name=f"{target.instance.id}_instance_cpu_utilization",
                alarm_description="This alarm helps to monitor the CPU utilization of an EC2 instance.",
                alarm_actions=sns_arns,
                ok_actions=sns_arns,
                metric_name="CPUUtilization",
                namespace="AWS/EC2",
                dimensions={"InstanceId": target.instance.id},
                statistic="Average",
                period=300,
                evaluation_periods=3,
                datapoints_to_alarm=3,
                threshold=95,
                treat_missing_data="missing",
                comparison_operator="GreaterThanOrEqualToThreshold",
                tags=Tags(target, instance_cpu_alarm_name).to_dict,
            )
        )

        return (
            ret
            + cls._SnsTopicSubscriptions(target.provider, cls._subscribers)
            + (cls._SnsTopicSubscriptions(target, [target.user.email]) if target.user.email else [])
        )


class AWSNetworkNotifications(AWSBaseNotification):
    """
    Class that contains resources for AWS Network Notifications.

    Inherits from AWSBaseNotification.

    Methods:
        SetupAlarms:
            Sets up alarms for the target Network.
    """

    @classmethod
    def SetupAlarms(cls, target: "AWSVpc") -> List[ITerraformDependable]:
        """
        Sets up alarms for the target Network.

        Parameters:
            target ("AWSVpc"):
                The target object representing the network for which alarms are being set up.

        Returns:
            List[ITerraformDependable]:
                A list of objects representing AWS CloudWatch Metric Alarms.
        """
        NAME_PREFIX = f"{target.provider.name}-{target.name}"

        ret: List[ITerraformDependable] = []

        generic_sns = cls._GetSnsTopic(target.provider)

        # Create NAT Gateway Cloudwatch metric alarms
        dropped_packets_alarm_name = AwsUtils.cloudwatchAlarmName(
            f"{NAME_PREFIX}-nat-gw-dropped-packets-cloudwatch-alarm"
        )
        error_port_alloc_alarm_name = AwsUtils.cloudwatchAlarmName(
            f"{NAME_PREFIX}-nat-gw-error-port-alloc-cloudwatch-alarm"
        )
        ret.append(
            CloudwatchMetricAlarm(
                target.nat_gateway,
                dropped_packets_alarm_name,
                alarm_name=dropped_packets_alarm_name,
                alarm_description="This alarm helps to detect when packets are dropped by NAT Gateway.",
                alarm_actions=[generic_sns.arn],
                ok_actions=[generic_sns.arn],
                metric_name="PacketsDropCount",
                namespace="AWS/NATGateway",
                dimensions={"NatGatewayId": target.nat_gateway.id},
                statistic="Sum",
                period=60,
                evaluation_periods=5,
                datapoints_to_alarm=5,
                threshold=1,
                treat_missing_data="notBreaching",
                comparison_operator="GreaterThanOrEqualToThreshold",
                tags=Tags(target.nat_gateway, dropped_packets_alarm_name).to_dict,
            )
        )
        ret.append(
            CloudwatchMetricAlarm(
                target.nat_gateway,
                error_port_alloc_alarm_name,
                alarm_name=error_port_alloc_alarm_name,
                alarm_description=(
                    "This alarm helps to detect when the NAT Gateway is unable to allocate ports to new connections"
                ),
                alarm_actions=[generic_sns.arn],
                ok_actions=[generic_sns.arn],
                metric_name="ErrorPortAllocation",
                namespace="AWS/NATGateway",
                dimensions={"NatGatewayId": target.nat_gateway.id},
                statistic="Sum",
                period=60,
                evaluation_periods=15,
                datapoints_to_alarm=15,
                threshold=0,
                treat_missing_data="notBreaching",
                comparison_operator="GreaterThanThreshold",
                tags=Tags(target.nat_gateway, error_port_alloc_alarm_name).to_dict,
            ),
        )

        # Create VPC firewall endpoint Cloudwatch metric alarms
        vpc_endpoint_id = Fn.lookup(
            Fn.element(target.firewall.firewall_status.get(0).sync_states.get(0).attachment, 0),
            "endpoint_id",
        )
        subnet_id = Fn.lookup(
            Fn.element(target.firewall.firewall_status.get(0).sync_states.get(0).attachment, 0),
            "subnet_id",
        )
        vpc_endpoint_service_name = DataAwsVpcEndpoint(
            target.firewall, f"{NAME_PREFIX}-fw-vpc-endpoint-name", vpc_id=target.vpc.id, id=vpc_endpoint_id
        ).service_name
        vpce_dropped_packets_alarm_name = AwsUtils.cloudwatchAlarmName(
            f"{NAME_PREFIX}-fw-vpc-endpoint-dropped-packets-cloudwatch-alarm"
        )
        ret.append(
            CloudwatchMetricAlarm(
                target.firewall,
                vpce_dropped_packets_alarm_name,
                alarm_name=vpce_dropped_packets_alarm_name,
                alarm_description=(
                    "This alarm helps to detect if the endpoint or endpoint service is unhealthy "
                    "by monitoring the number of packets dropped by the endpoint."
                ),
                alarm_actions=[generic_sns.arn],
                ok_actions=[generic_sns.arn],
                metric_name="PacketsDropped",
                namespace="AWS/PrivateLinkEndpoints",
                dimensions={
                    "VPC Id": target.vpc.id,
                    "VPC Endpoint Id": vpc_endpoint_id,
                    "Endpoint Type": "GatewayLoadBalancer",
                    "Subnet Id": subnet_id,
                    "Service Name": vpc_endpoint_service_name,
                },
                statistic="Sum",
                period=60,
                evaluation_periods=5,
                datapoints_to_alarm=5,
                threshold=1,
                treat_missing_data="notBreaching",
                comparison_operator="GreaterThanThreshold",
                tags=Tags(target.firewall, vpce_dropped_packets_alarm_name).to_dict,
            )
        )

        return ret + cls._SnsTopicSubscriptions(target.provider, cls._subscribers)


class AWSRunnerNotifications(AWSBaseNotification):
    """
    Class that contains resources for AWS EKS Runner Notifications.

    Inherits from AWSBaseNotification.

    Private Attributes:
        _node_group_alarms (Dict["AwsEksRunner", List[ITerraformDependable]]):
            A dictionary that holds a mapping from AWS EKS Runners to their corresponding list of Cloud Alarms.

    Methods:
        SetupAlarms:
            Sets up alarms for the target EKS Runner.
    """

    _node_group_alarms: Dict["AwsEksRunner", List[ITerraformDependable]] = {}

    @classmethod
    def SetupAlarms(cls, target: "AwsEksRunner") -> List[ITerraformDependable]:
        """
        Sets up alarms for the target EKS Runner.

        Parameters:
            target ("AwsEksRunner"):
                The target object representing the EKS Runner for which alarms are being set up.

        Returns:
            List[ITerraformDependable]:
                A list of objects representing AWS CloudWatch Metric Alarms.
        """
        if target not in cls._node_group_alarms:
            cls._node_group_alarms[target] = []
            NAME_PREFIX = f"{target.provider.name}-{target.name}"

            generic_sns = cls._GetSnsTopic(target.provider)

            system_check_alarm_name = AwsUtils.cloudwatchAlarmName(f"{NAME_PREFIX}-system-check-alarm")
            instance_check_alarm_name = AwsUtils.cloudwatchAlarmName(f"{NAME_PREFIX}-instance-check-alarm")
            instance_cpu_alarm_name = AwsUtils.cloudwatchAlarmName(f"{NAME_PREFIX}-instance-cpu-alarm")
            cls._node_group_alarms[target].append(
                CloudwatchMetricAlarm(
                    target.node_group,
                    system_check_alarm_name,
                    alarm_name=f"{target.node_group.node_group_name}_system_check_fail",
                    alarm_description="System check has failed",
                    alarm_actions=[generic_sns.arn],
                    ok_actions=[generic_sns.arn],
                    metric_name="StatusCheckFailed_System",
                    namespace="AWS/EC2",
                    dimensions={"AutoScalingGroupName": target.node_group.node_group_name},
                    statistic="Maximum",
                    period=300,
                    evaluation_periods=2,
                    datapoints_to_alarm=2,
                    threshold=1,
                    treat_missing_data="notBreaching",
                    comparison_operator="GreaterThanOrEqualToThreshold",
                    tags=Tags(target.node_group, system_check_alarm_name).to_dict,
                )
            )
            cls._node_group_alarms[target].append(
                CloudwatchMetricAlarm(
                    target.node_group,
                    instance_check_alarm_name,
                    alarm_name=f"{target.node_group.node_group_name}_instance_check_fail",
                    alarm_description="Instance check has failed",
                    alarm_actions=[generic_sns.arn],
                    ok_actions=[generic_sns.arn],
                    metric_name="StatusCheckFailed_Instance",
                    namespace="AWS/EC2",
                    dimensions={"AutoScalingGroupName": target.node_group.node_group_name},
                    statistic="Maximum",
                    period=300,
                    evaluation_periods=3,
                    datapoints_to_alarm=3,
                    threshold=1,
                    treat_missing_data="notBreaching",
                    comparison_operator="GreaterThanOrEqualToThreshold",
                    tags=Tags(target.node_group, instance_check_alarm_name).to_dict,
                )
            )
            cls._node_group_alarms[target].append(
                CloudwatchMetricAlarm(
                    target.node_group,
                    instance_cpu_alarm_name,
                    alarm_name=f"{target.node_group.node_group_name}_instance_cpu_utilization",
                    alarm_description="This alarm helps to monitor the CPU utilization of an EC2 instance.",
                    alarm_actions=[generic_sns.arn],
                    ok_actions=[generic_sns.arn],
                    metric_name="CPUUtilization",
                    namespace="AWS/EC2",
                    dimensions={"AutoScalingGroupName": target.node_group.node_group_name},
                    statistic="Average",
                    period=300,
                    evaluation_periods=3,
                    datapoints_to_alarm=3,
                    threshold=95,
                    treat_missing_data="missing",
                    comparison_operator="GreaterThanOrEqualToThreshold",
                    tags=Tags(target.node_group, instance_cpu_alarm_name).to_dict,
                )
            )

        return cls._node_group_alarms[target] + cls._SnsTopicSubscriptions(target.provider, cls._subscribers)
