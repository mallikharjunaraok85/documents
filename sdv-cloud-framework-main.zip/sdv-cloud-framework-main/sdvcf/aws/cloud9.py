import json
import os
from importlib.resources import as_file, files
from typing import Any, Dict, List, Optional

from cdktf import Fn
from cdktf_cdktf_provider_archive.data_archive_file import (
    DataArchiveFile,
    DataArchiveFileSource,
)
from cdktf_cdktf_provider_aws.cloud9_environment_ec2 import Cloud9EnvironmentEc2
from cdktf_cdktf_provider_aws.cloud9_environment_membership import (
    Cloud9EnvironmentMembership,
)
from cdktf_cdktf_provider_aws.data_aws_iam_policy import DataAwsIamPolicy
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.data_aws_iam_role import DataAwsIamRole
from cdktf_cdktf_provider_aws.data_aws_instance import DataAwsInstance
from cdktf_cdktf_provider_aws.iam_instance_profile import IamInstanceProfile
from cdktf_cdktf_provider_aws.iam_policy import IamPolicy
from cdktf_cdktf_provider_aws.iam_role import IamRole
from cdktf_cdktf_provider_aws.iam_role_policy_attachment import IamRolePolicyAttachment
from cdktf_cdktf_provider_aws.lambda_function import LambdaFunction
from cdktf_cdktf_provider_aws.lambda_invocation import LambdaInvocation
from cdktf_cdktf_provider_time.sleep import Sleep

from sdvcf.aws.utils import AwsUtils
from sdvcf.interface import (
    IComponent,
    IUser,
    IWorkbench,
    ServiceMachineOS,
    WorkbenchProps,
)
from sdvcf.output import Output
from sdvcf.tags import Tags

from .enums import ConnectionType, SubnetType
from .provider import AWSProvider
from .user import AWSUser
from .vpc import AWSVpc


class AwsC9ExecuteScriptLambda(IComponent):
    """
    Class for setting up Lambda Execution on AWS Cloud9.

    This class facilitates the setup of user data scripts on an AWS Cloud9 workbench using AWS Lambda.

    Attributes:
        provider (AWSProvider):
            An instance of the AWSProvider associated with this AWS Cloud9.
        cloud9 (AwsCloud9):
            An instance of the AWS Cloud9 to execute Lambda on.

    Private Attributes:
        _tags (Dict[str, str]):
            A dictionary mapping user-defined tags.
        _lambda_role (IamRole):
            Lazily initialized AWS IAM Role.
            None until accessed.
        _lambda_role_policy_attachment (IamRolePolicyAttachment):
            Lazily initialized AWS IAM Role Policy Attachment.
            None until accessed.
        _instance_role (IamRole):
            Lazily initialized AWS IAM Role for AWS EC2.
            None until accessed.
        _instance_profile (IamInstanceProfile):
            Lazily initialized AWS IAM Instance Profile.
            None until accessed.
        _instance_role_policy_attachment (IamRolePolicyAttachment):
             initialized AWS IAM Role Policy Attachment.
            None until accessed.
        _lambda_function (LambdaFunction):
            Lazily initialized AWS Lambda Function.
            None until accessed.

    Methods:
        Setup:
            Invokes the setup lambda on the Cloud9 instance.

    Properties:
        type:
            Returns the Cloud9's type.
        lambda_role:
            Returns the IamRole instance, initializing it if it has not been already.
        lambda_role_policy_attachment:
            Returns the IamRolePolicyAttachment instance, initializing it if it has not been already.
        instance_role:
            Returns the IamRole instance, initializing it if it has not been already.
        instance_role_policy_attachment:
            Returns the IamRolePolicyAttachment instance, initializing it if it has not been already.
        instance_profile:
            Returns the IamInstanceProfile instance, initializing it if it has not been already.
        lambda_function:
            Returns the LambdaFunction instance, initializing it if it has not been already.
    """

    provider: AWSProvider
    cloud9: "AwsCloud9"

    _tags: Dict[str, str]
    _lambda_role: Optional[IamRole]
    _lambda_role_policy_attachment: Optional[IamRolePolicyAttachment]
    _instance_role: Optional[IamRole]
    _instance_profile: Optional[IamInstanceProfile]
    _instance_role_policy_attachment: Optional[IamRolePolicyAttachment]
    _lambda_function: Optional[LambdaFunction]

    def __init__(
        self,
        ns: str,
        cloud9: "AwsCloud9",
        tags: Dict[str, str] = {},
    ):
        super().__init__(cloud9.provider, ns)

        self.cloud9 = cloud9

        self._tags = tags
        self._lambda_role = None
        self._lambda_role_policy_attachment = None
        self._instance_role = None
        self._instance_profile = None
        self._instance_role_policy_attachment = None
        self._lambda_function = None

    @property
    def type(self) -> str:
        """
        Retrieve the type of the AWS Cloud9 instance.

        Returns:
            str:
                The type of the AWS Cloud9 instance.
        """
        return self.cloud9.type

    @property
    def lambda_role(self) -> IamRole:
        """
        Creates and configures an IAM role for the AWS Lambda Function.

        This property ensures that the IAM role has a valid name and
        assumes the correct policy document for Lambda.
        Additionally, it applies the appropriate tags to the IAM role.

        Returns:
            IamRole:
                An object representing the AWS IAM Role.
        """
        if self._lambda_role is None:
            iam_role_rid = f"{self.name}-lambda-role"
            document = DataAwsIamPolicyDocument(
                self,
                f"{iam_role_rid}-assume-policy-document",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=["sts:AssumeRole"],
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                type="Service", identifiers=["lambda.amazonaws.com"]
                            )
                        ],
                    )
                ],
            )

            iam_role_name = AwsUtils.iamRoleName(iam_role_rid)
            self._lambda_role = IamRole(
                self,
                iam_role_rid,
                name=iam_role_name,
                path=f"/{self.provider.name}/",
                assume_role_policy=document.json,
                tags=Tags(self, iam_role_name, self._tags).to_dict,
            )
        return self._lambda_role

    @property
    def lambda_role_policy_attachment(self) -> IamRolePolicyAttachment:
        """
        Creates and configures an IAM Role Policy Attachment for the AWS Lambda Function.

        This property ensures that the IAM Policy has a valid name and
        includes the necessary policy statements for a Lambda Function.
        Additionally, it applies the appropriate tags to the IAM Policy.

        Returns:
            IamRolePolicyAttachment:
                An object representing the AWS IAM Role Policy Attachment.
        """
        account_id = self.provider.caller_identity.account_id
        volume_id = self.cloud9.instance.root_block_device.get(0).volume_id
        if self._lambda_role_policy_attachment is None:
            iam_policy_rid = f"{self.name}-lambda-role-policy"
            lambda_pd = DataAwsIamPolicyDocument(
                self,
                f"{iam_policy_rid}-document",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=[
                            "ssm:SendCommand",
                            "ec2:AssociateIamInstanceProfile",
                            "ec2:ReportInstanceStatus",
                            "ec2:StartInstances",
                            "ec2:RebootInstances",
                            "ec2:ModifyVolume",
                            "iam:PassRole",
                        ],
                        resources=[
                            self.cloud9.instance.arn,
                            f"arn:aws:ec2:{self.provider.region}:{account_id}:volume/{volume_id}",
                            f"arn:aws:ssm:{self.provider.region}::document/AWS-RunShellScript",
                            self.instance_role.arn,
                        ],
                    ),
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=[
                            "ec2:DescribeIamInstanceProfileAssociations",
                            "ec2:DescribeInstances",
                            "ec2:DescribeVolumesModifications",
                            "ec2:DescribeVolumes",
                            "ssm:DescribeInstanceInformation",
                        ],
                        resources=["*"],
                    ),
                ],
            )

            iam_policy_name = AwsUtils.iamPolicyName(iam_policy_rid)
            lambda_policy = IamPolicy(
                self,
                iam_policy_rid,
                name=iam_policy_name,
                policy=lambda_pd.json,
                tags=Tags(self, iam_policy_name, self._tags).to_dict,
            )

            self._lambda_role_policy_attachment = IamRolePolicyAttachment(
                self,
                f"{iam_policy_rid}-attachment",
                policy_arn=lambda_policy.arn,
                role=self.lambda_role.name,
            )
        return self._lambda_role_policy_attachment

    @property
    def instance_role(self) -> IamRole:
        """
        Creates and configures an IAM role for the AWS EC2 Instance.

        This property ensures that the IAM role has a valid name and
        assumes the correct policy document for an AWS EC2 Instance.
        Additionally, it applies the appropriate tags to the IAM role.

        Returns:
            IamRole:
                An object representing the AWS IAM Role.
        """
        if self._instance_role is None:
            iam_role_rid = f"{self.name}-instance-role"
            document = DataAwsIamPolicyDocument(
                self,
                f"{iam_role_rid}-policy-document",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=["sts:AssumeRole"],
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                type="Service", identifiers=["ec2.amazonaws.com"]
                            )
                        ],
                    )
                ],
            )

            iam_role_name = AwsUtils.iamRoleName(iam_role_rid)
            self._instance_role = IamRole(
                self,
                iam_role_rid,
                name=iam_role_name,
                path=f"/{self.provider.name}/",
                assume_role_policy=document.json,
                tags=Tags(self, iam_role_name, self._tags).to_dict,
            )
        return self._instance_role

    @property
    def instance_role_policy_attachment(self) -> IamRolePolicyAttachment:
        """
        Creates and configures an IAM Role Policy Attachment for the AWS EC2 Instance.

        This property ensures that the IAM Policy has a valid name and
        includes the necessary policy statements for an AWS EC2 Instance.
        Additionally, it applies the appropriate tags to the IAM Policy.

        Returns:
            IamRolePolicyAttachment:
                An object representing the AWS IAM Role Policy Attachment.
        """
        if self._instance_role_policy_attachment is None:
            iam_policy_rid = f"{self.name}-instance-role-policy"

            instance_policy = DataAwsIamPolicy(self, iam_policy_rid, name="AmazonSSMManagedInstanceCore")

            self._instance_role_policy_attachment = IamRolePolicyAttachment(
                self,
                f"{iam_policy_rid}-attachment",
                policy_arn=instance_policy.arn,
                role=self.instance_role.name,
            )
        return self._instance_role_policy_attachment

    @property
    def instance_profile(self) -> IamInstanceProfile:
        """
        Creates and configures an AWS IAM Instance Profile for a AWS EC2 Instance.

        This property ensures that the IAM Instance Profile is created with a valid name and
        associated with the correct IAM role.
        Additionally, it applies the appropriate tags to the IAM Instance Profile.

        Returns:
            IamInstanceProfile:
                An object representing the configured AWS IAM Instance Profile.
        """
        if self._instance_profile is None:
            instance_profile_rid = f"{self.name}-instance-profile"
            instance_profile_name = AwsUtils.instanceProfileName(instance_profile_rid)
            self._instance_profile = IamInstanceProfile(
                self,
                instance_profile_rid,
                name=instance_profile_name,
                role=self.instance_role.name,
                tags=Tags(self, instance_profile_name, self._tags).to_dict,
            )
        return self._instance_profile

    @property
    def lambda_function(self) -> LambdaFunction:
        """
        Creates and configures an AWS Lambda Function which invokes the user data script on the AWS Cloud9 workbench.

        Returns:
            LambdaFunction:
                An object representing the AWS Lambda Function.
        """
        if self._lambda_function is None:
            lambda_function_rid = f"{self.name}-ec2-execute-script"
            filename = f"{lambda_function_rid}-files.zip"
            lambda_source_archive = DataArchiveFile(
                self,
                id=f"{lambda_function_rid}-lambda-files-archive",
                type="zip",
                output_path=filename,
                source=[
                    DataArchiveFileSource(content=self.cloud9.user_data, filename="configs/startup.sh"),
                    DataArchiveFileSource(
                        content=Fn.file(
                            str(files("sdvcf.aws.resources").joinpath("lambda/ec2_execute_script/execute.py.tmpl"))
                        ),
                        filename="execute.py",
                    ),
                ],
            )

            lambda_function_name = AwsUtils.lambdaName(lambda_function_rid)
            self._lambda_function = LambdaFunction(
                self,
                f"{lambda_function_rid}-lambda-function",
                filename=lambda_source_archive.output_path,
                source_code_hash=lambda_source_archive.output_base64_sha256,
                function_name=lambda_function_name,
                role=self.lambda_role.arn,
                handler="execute.lambda_handler",
                runtime="python3.8",
                timeout=900,
                tags=Tags(self, lambda_function_name, self._tags).to_dict,
            )
        return self._lambda_function

    def Setup(self) -> None:
        """
        Invoke the setup lambda on the Cloud9 instance.

        Ensures that all IAM roles are applied.

        Returns:
            None:
                This method does not return any value.
        """
        wait_for_iam = Sleep(
            self,
            f"{self.name}-invocation-sleep",
            create_duration="60s",
            depends_on=[
                self.lambda_role_policy_attachment,
                self.instance_role_policy_attachment,
            ],
        )
        LambdaInvocation(
            self,
            f"{self.name}-lambda-invocation",
            function_name=self.lambda_function.function_name,
            input=json.dumps(
                {
                    "instanceId": self.cloud9.instance.id,
                    "instanceProfileARN": self.instance_profile.arn,
                    "volumeId": self.cloud9.instance.root_block_device.get(0).volume_id,
                    "volumeSize": self.cloud9.props.disk_size,
                }
            ),
            triggers={"redeployment": self.lambda_function.source_code_hash},
            depends_on=[wait_for_iam],
        )


class AwsCloud9Props(WorkbenchProps):
    """
    AwsCloud9Props is a configuration class that extends WorkbenchProps, adding AWS Cloud9-specific properties.

    Attributes:
        subnet_type (SubnetType):
            Defines the type of Subnet to be used.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        connection_type (ConnectionType):
            Defines the type of Connection to be used.
            This can be either specified directly or
            inferred from an environment variable with a default value.
    """

    def __init__(
        self,
        connection_type: Optional[ConnectionType] = None,
        subnet_type: Optional[SubnetType] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self.connection_type = (
            connection_type or ConnectionType[os.getenv("AWS_C9_CONNECTION_TYPE", ConnectionType.CONNECT_SSM.name)]
        )
        self.subnet_type = subnet_type or SubnetType[os.getenv("AWS_C9_DEFAULT_SUBNET_TYPE", SubnetType.Primary.name)]


class AwsCloud9(IWorkbench):
    """
    Class that contains resources for the AWS Cloud9 workbench.

    Attributes:
        provider (`AWSProvider`):
            An instance of the AWSProvider associated with this Cloud9 workbench.
        cloud (`AWSVpc`):
            An instance of the AWSVpc associated with this Cloud9 workbench.
        props (`AwsCloud9Props`):
            An instance of the AwsCloud9Props associated with this Cloud9 workbench.

    Private Attributes:
        _ec2_environment (`Cloud9EnvironmentEc2`):
            Lazily initialized AWS Cloud9 Environment for AWS Cloud9.
            None until accessed.
        _instance (`DataAwsInstance`):
            Lazily initialized AWS Instance for AWS Cloud9.
            None until accessed.
        _iam_role (`DataAwsIamRole`):
            Lazily initialized AWS IAM Role for AWS Cloud9.
            None until accessed.
        _setup_lambda (`AwsC9ExecuteScriptLambda`):
            Lazily initialized Setup Lambda for AWS Cloud9.
            None until accessed.
        _ami_os_family (`str`):
            OS family in AWS as string
        _ami_ (`str`):
            An AMI Image ID in AWS as a string.
        _os_version (`str`):
            OS version in as string
        _registry_policy (`IamPolicy`):
            Lazily initialized AWS IAM Policy for registries.
            None until accessed.

    Properties:
        ec2_environment:
            Returns the Cloud9EnvironmentEc2 instance, initializing it if it has not been already.
        instance:
            Returns the DataAwsInstance instance, initializing it if it has not been already.
        iam_role:
            Returns the DataAwsIamRole instance, initializing it if it has not been already.
        exposed_ports:
            Returns a list of integer port numbers exposed ports of the Cloud9 workbench.
            If no ports are exposed, the list is empty
        setup_lambda:
            Returns the AwsC9ExecuteScriptLambda instance, initializing it if it has not been already.
        registry_policy:
            Returns the IamPolicy instance, initializing it if it has not been already.

    Public static class constants:
        DEFAULT_WB_PASSWORD (`str`):
            A string that contains the default workbench password.

    Public class constants:
        SCRIPTS_MODULE (`str`):
            A string that contains the python path to the module of the scripts.
        SCRIPTS_PATH_PREFIX (`str`):
            A string that contains the OS path to the scripts.
    """

    DEFAULT_WB_PASSWORD: str = "password"

    provider: AWSProvider
    cloud: AWSVpc
    props: AwsCloud9Props

    SCRIPTS_MODULE: str
    SCRIPTS_PATH_PREFIX: str

    _ami_mapping: Dict[ServiceMachineOS, str] = {
        ServiceMachineOS.Ubuntu22_04: "ubuntu-22.04-x86_64",
        ServiceMachineOS.Ubuntu20_04: "ubuntu-20.04-x86_64",
        ServiceMachineOS.Ubuntu18_04: "ubuntu-18.04-x86_64",
    }

    _ec2_environment: Optional[Cloud9EnvironmentEc2]
    _instance: Optional[DataAwsInstance]
    _iam_role: Optional[DataAwsIamRole]
    _registry_policy: Optional[IamPolicy]
    _setup_lambda: Optional[AwsC9ExecuteScriptLambda]
    _ami_os_family: str
    _ami: str
    _os_version: str

    def __init__(self, user: IUser, props: WorkbenchProps):
        assert isinstance(user, AWSUser)
        super().__init__(user.cloud, f"{user.name}-{self.__class__.__name__.lower()}", props)

        self.NAME_PREFIX = f"{self.provider.name}-{self.name}"

        self.user = user

        self._ec2_environment = None
        self._instance = None
        self._iam_role = None
        self._setup_lambda = None
        self._registry_policy = None
        self._ami_os_family = self.props.ami_os_family_mapping[self.props.os]
        self._ami = self._ami_mapping[self.props.os]
        self._os_version = self.props.os_version_mapping[self.props.os]

        self.SCRIPTS_MODULE = "sdvcf.aws.resources"
        self.SCRIPTS_PATH_PREFIX = f"workbench/scripts/{self._ami_os_family}/{self._os_version}/"

        with as_file(files(self.SCRIPTS_MODULE).joinpath(f"{self.SCRIPTS_PATH_PREFIX}/common.sh")) as file:
            self.AddUserDataFile(file)

    @property
    def ec2_environment(self) -> Cloud9EnvironmentEc2:
        """
        A property that creates and configures a Cloud9 Environment for a Cloud9 workbench.

        This property ensures that the Cloud9 environment is named in accordance with validation rules
        and associates an EC2 instance with the AWS Cloud9 Environment as a member.
        It also applies the necessary tags to the associated Cloud9 Environment.

        Returns:
            Cloud9EnvironmentEc2:
                An object representing the configured AWS Cloud9 Environment.
        """
        if self._ec2_environment is None:
            tags = Tags(self, AwsUtils.cloud9EnvironmentName(f"{self.NAME_PREFIX}-instance")).to_dict
            ec2_environment_rid = tags.pop("Name")
            self._ec2_environment = Cloud9EnvironmentEc2(
                self,
                ec2_environment_rid,
                instance_type=self.props.itype,
                name=ec2_environment_rid,
                image_id=self._ami,
                connection_type=self.props.connection_type,
                subnet_id=self.cloud.subnets[self.props.subnet_type].id,
                automatic_stop_time_minutes=self.props.auto_stop_minutes,
                tags=tags,
                depends_on=self.cloud.internet_connection,
            )

            Cloud9EnvironmentMembership(
                self,
                f"{self.NAME_PREFIX}-membership",
                environment_id=self._ec2_environment.id,
                permissions="read-write",
                user_arn=self.user.GetUniqueID(),
            )
        return self._ec2_environment

    @property
    def instance(self) -> DataAwsInstance:
        """
        A property that creates and configures a AWS Instance for a Cloud9 workbench.

        This property ensures that the AWS instance is initialized with user data that is executed by a Lambda Function.
        Also, it facilitates the generation of Terraform output that includes the instance's HTTPS endpoint address.

        Returns:
            DataAwsInstance:
                An object representing the configured AWS Instance.
        """
        if self._instance is None:
            instance_name = f"{self.NAME_PREFIX}-data-instance"
            self._instance = DataAwsInstance(
                self,
                instance_name,
                instance_tags={"aws:cloud9:environment": self.ec2_environment.id},
                depends_on=[self.ec2_environment],
                tags=Tags(self, instance_name).to_dict,
            )

            if len(self.props.registry_policy_info) > 0:
                self._AttachPolicy("registries", self.registry_policy.arn)
            self.setup_lambda.Setup()

            Output(
                self,
                id="username",
                value=self.posix_username,
                resource_id=self._instance.arn,
                user_name=self.user.user.name,
            )
            Output(
                self,
                id="password",
                value=self.DEFAULT_WB_PASSWORD,
                resource_id=self._instance.arn,
                user_name=self.user.user.name,
            )
            Output(
                self,
                id="endpoint",
                value=f"https://{self.provider.region}.console.aws.amazon.com/cloud9/ide/{self.ec2_environment.id}",
                resource_id=self._instance.arn,
                user_name=self.user.user.name,
            )
        return self._instance

    @property
    def registry_policy(self) -> IamPolicy:
        """
        Creates and configures an AWS IAM Policy for registries.

        This function ensures that the IAM Policy is created with a valid name and
        that the policy document specifies fine-grained permissions for designated actions and
        may include conditional statements to enforce specific requirements for those actions.
        Additionally, it applies the appropriate tags to the IAM Policy.

        Returns:
            IamPolicy:
                An object representing the AWS IAM Policy.
        """
        if self._registry_policy is None:
            rid = f"{self.NAME_PREFIX}-registry-policy"
            reg_name = AwsUtils.iamPolicyName(rid)
            statements = [
                DataAwsIamPolicyDocumentStatement(**registry_statements)
                for registry_info in self.props.registry_policy_info
                for registry_statements in registry_info["info"]
            ]
            self._registry_policy = IamPolicy(
                self,
                rid,
                name=reg_name,
                policy=DataAwsIamPolicyDocument(
                    self,
                    f"{self.NAME_PREFIX}-efs-pd",
                    statement=statements,
                ).json,
                tags=Tags(self, reg_name).to_dict,
            )
        return self._registry_policy

    @property
    def iam_role(self) -> DataAwsIamRole:
        """
        Creates and configures an IAM role for a Cloud9 workbench.

        Returns:
            IamRole:
                An object representing the configured AWS IAM Role.
        """
        if self._iam_role is None:
            self._iam_role = DataAwsIamRole(
                self, f"{self.NAME_PREFIX}-iam-role", name="AWSCloud9SSMAccessRole", depends_on=[self.instance]
            )
        return self._iam_role

    @property
    def posix_username(self) -> str:
        username_mapping = {ServiceMachineOS.Ubuntu22_04: "ubuntu"}

        return username_mapping[self.props.os]

    @property
    def exposed_ports(self) -> List[int]:
        """
        A property that lists the port numbers which are exposed by this Cloud9 workbench.

        Returns:
            List[int]:
                A list of integer port numbers that are exposed by this service.
                If no ports are exposed, the list is empty.
        """
        return []

    @property
    def setup_lambda(self) -> AwsC9ExecuteScriptLambda:
        """
        Creates and configures an AwsC9ExecuteScriptLambda for a Cloud9 workbench.

        This property sets up a Lambda function designed to execute user data scripts in the Cloud9 workbench.

        Returns:
            AwsC9ExecuteScriptLambda:
                An object representing the configured AwsC9ExecuteScriptLambda.
        """
        if self._setup_lambda is None:
            self._setup_lambda = AwsC9ExecuteScriptLambda(f"{self.NAME_PREFIX}-setup", self)
        return self._setup_lambda

    def _AttachPolicy(self, name: str, policy_arn: str) -> None:
        """
        Attaches an IAM policy to the IAM Role.

        Parameters:
            name (`str`):
                The name of the policy attachment.
            policy_arn (`str`):
                The id of the policy.

        Returns:
            None:
                This method does not return any value.
        """
        IamRolePolicyAttachment(
            self,
            f"{self.NAME_PREFIX}-{name}-policy-att",
            role=self.iam_role.name,
            policy_arn=policy_arn,
        )
