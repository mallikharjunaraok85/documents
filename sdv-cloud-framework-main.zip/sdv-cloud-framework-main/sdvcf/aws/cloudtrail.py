from typing import Dict, Optional

from cdktf_cdktf_provider_aws.cloudtrail import Cloudtrail
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementCondition,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.s3_bucket import S3Bucket
from cdktf_cdktf_provider_aws.s3_bucket_acl import S3BucketAcl
from cdktf_cdktf_provider_aws.s3_bucket_ownership_controls import (
    S3BucketOwnershipControls,
    S3BucketOwnershipControlsRule,
)
from cdktf_cdktf_provider_aws.s3_bucket_policy import S3BucketPolicy

from sdvcf.interface import ILogger
from sdvcf.tags import Tags

from .provider import AWSProvider
from .utils import AwsUtils


class AWSCloudtrail(ILogger):

    provider: AWSProvider

    _cloudtrail: Optional[Cloudtrail]
    _bucket: Optional[S3Bucket]

    def __init__(self, ns: str, tags: Dict[str, str] = {}):
        super().__init__(AWSProvider.Instance(), ns)

        self._cloudtrail = None
        self._bucket = None

        self.cloudtrail_name = f"{self.provider.name}-{self.name}-cloudtrail"

        self._tags = tags

    @property
    def cloudtrail(self) -> Cloudtrail:
        if self._cloudtrail is None:
            self._cloudtrail = Cloudtrail(
                self,
                self.cloudtrail_name,
                name=self.cloudtrail_name,
                s3_bucket_name=self.bucket.id,
                tags=Tags(self, self.cloudtrail_name, self._tags).to_dict,
                depends_on=[self.bucket],
            )
        return self._cloudtrail

    @property
    def bucket(self) -> S3Bucket:
        """
        Creates and configures a S3 Bucket.

        Returns:
            S3Bucket:
                An object representing the configured S3 Bucket.
        """
        if self._bucket is None:
            bucket_name = AwsUtils.makeUniqueS3BucketName(f"{self.provider.name}-{self.name}-bucket")
            partition = self.provider.partition.partition
            region = self.provider.region
            account_id = self.provider.caller_identity.account_id
            self._bucket = S3Bucket(
                self,
                bucket_name,
                bucket=bucket_name,
                tags=Tags(self, bucket_name, self._tags).to_dict,
            )
            S3BucketPolicy(
                self,
                f"{bucket_name}-policy",
                bucket=self._bucket.id,
                policy=DataAwsIamPolicyDocument(
                    self,
                    f"{bucket_name}-pd",
                    statement=[
                        DataAwsIamPolicyDocumentStatement(
                            sid="AWSCloudTrailAclCheck",
                            effect="Allow",
                            principals=[
                                DataAwsIamPolicyDocumentStatementPrincipals(
                                    identifiers=["cloudtrail.amazonaws.com"],
                                    type="Service",
                                ),
                            ],
                            actions=["s3:GetBucketAcl"],
                            resources=[
                                self._bucket.arn,
                                f"{self._bucket.arn}/*",
                            ],
                            condition=[
                                DataAwsIamPolicyDocumentStatementCondition(
                                    test="StringEquals",
                                    variable="aws:SourceArn",
                                    values=[
                                        f"arn:{partition}:cloudtrail:{region}:{account_id}:trail/{self.cloudtrail_name}"
                                    ],
                                ),
                            ],
                        ),
                        DataAwsIamPolicyDocumentStatement(
                            sid="AWSCloudTrailWrite",
                            effect="Allow",
                            principals=[
                                DataAwsIamPolicyDocumentStatementPrincipals(
                                    identifiers=["cloudtrail.amazonaws.com"],
                                    type="Service",
                                ),
                            ],
                            actions=["s3:PutObject"],
                            resources=[
                                self._bucket.arn,
                                f"{self._bucket.arn}/AWSLogs/{self.provider.caller_identity.account_id}/*",
                            ],
                            condition=[
                                DataAwsIamPolicyDocumentStatementCondition(
                                    test="StringEquals",
                                    variable="s3:x-amz-acl",
                                    values=["bucket-owner-full-control"],
                                ),
                                DataAwsIamPolicyDocumentStatementCondition(
                                    test="StringEquals",
                                    variable="aws:SourceArn",
                                    values=[
                                        f"arn:{partition}:cloudtrail:{region}:{account_id}:trail/{self.cloudtrail_name}"
                                    ],
                                ),
                            ],
                        ),
                    ],
                ).json,
            )
            bucket_ownership_controls = S3BucketOwnershipControls(
                self,
                f"{bucket_name}-os-controls",
                bucket=self._bucket.id,
                rule=S3BucketOwnershipControlsRule(object_ownership="BucketOwnerPreferred"),
            )
            S3BucketAcl(
                self,
                f"{bucket_name}-acl",
                acl="private",
                bucket=self._bucket.id,
                depends_on=[bucket_ownership_controls],
            )
        return self._bucket
