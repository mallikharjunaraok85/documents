import os
from enum import Enum
from typing import Any, Optional, Union

from cdktf_cdktf_provider_aws.customer_gateway import CustomerGateway
from cdktf_cdktf_provider_aws.data_aws_ec2_transit_gateway import (
    DataAwsEc2TransitGateway,
)
from cdktf_cdktf_provider_aws.ec2_transit_gateway import Ec2TransitGateway
from cdktf_cdktf_provider_aws.ec2_transit_gateway_route import Ec2TransitGatewayRoute
from cdktf_cdktf_provider_aws.ec2_transit_gateway_vpc_attachment import (
    Ec2TransitGatewayVpcAttachment,
)
from cdktf_cdktf_provider_aws.route import Route
from cdktf_cdktf_provider_aws.security_group_rule import SecurityGroupRule
from cdktf_cdktf_provider_aws.vpn_connection import VpnConnection

from sdvcf.interface import IVPN, IPrivateCloud, VpnProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .enums import SubnetType
from .provider import AWSProvider
from .vpc import AWSVpc


class VPNConnectionType(str, Enum):
    """
    Enumeration of the different types of VPN connection protocols supported by AWS.

    Attributes:
        IPSec1:
            Represents the 'ipsec.1' connection type.

    Reference:
        https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_CreateVpnConnection.html
    """

    IPSec1 = "ipsec.1"


class AWSVpnProps(VpnProps):
    """
    AWSVpnProps is a configuration class that extends VpnProps, adding AWS-specific properties.

    Attributes:
        bgp_asn (int):
            Defines the Autonomous System Number (ASN) for Border Gateway Protocol (BGP).
            This can be either specified directly or
            inferred from an environment variable with a default value.
        cgw_type (VPNConnectionType):
            Defines the type of Customer Gateway VPN connection protocol to be used.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        external_gateway (str):
            Defines the name of the external gateway to be used.
            This can be either specified directly or
            inferred from an environment variable with a default value (None).
    """

    bgp_asn: int
    cgw_type: VPNConnectionType
    external_gateway: Optional[str]

    def __init__(
        self,
        bgp_asn: Optional[int] = None,
        cgw_type: Optional[VPNConnectionType] = None,
        external_gateway: Optional[str] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self.bgp_asn = bgp_asn or int(os.getenv("AWS_BGP_ASN", 65000))
        self.cgw_type = (
            cgw_type or VPNConnectionType[os.getenv("AWS_VPN_CONNECTION_TYPE", VPNConnectionType.IPSec1.name)]
        )
        self.external_gateway = external_gateway or os.getenv("AWS_VPN_EXTERNAL_GATEWAY", None)


class AWSVpn(IVPN):
    """
    This class provides the creation and setup of AWS S2S VPN.

    Inherits from IVPN.

    Attributes:
        provider (AWSProvider):
            The instance of the AWSProvider associated with this VPN.
        props (AWSVpnProps):
            The instance of the AWSVpnProps associated with this VPN.

    Private Attributes:
        _tgw (Union[DataAwsEc2TransitGateway, Ec2TransitGateway]):
            Lazily initialized DataAwsEc2TransitGateway.
            None until accessed.

    Properties:
        tgw:
            Returns the DataAwsEc2TransitGateway instance, initializing it if it has not been already.

    Methods:
        Establish:
            Establish VPN S2S connection.
        _Attach:
            Internal method to create a transit gateway attachment.
    """

    provider: AWSProvider
    props: AWSVpnProps

    _tgw: Optional[Union[DataAwsEc2TransitGateway, Ec2TransitGateway]]

    def __init__(self, ns: str, props: AWSVpnProps):
        super().__init__(AWSProvider.Instance(), ns, props)

        self._tgw = None

    @property
    def tgw(self) -> Union[DataAwsEc2TransitGateway, Ec2TransitGateway]:
        """
        A property that creates and configures an AWS EC2 Transit Gateway.

        Returns:
            DataAwsEc2TransitGateway:
                An object representing AWS EC2 Transit Gateway.
        """
        if self._tgw is None:
            self._tgw = (
                DataAwsEc2TransitGateway(self, f"{self.name}-tgw", id=self.props.external_gateway)
                if self.props.external_gateway
                else DataAwsEc2TransitGateway(
                    self,
                    f"{self.name}-tgw",
                    filter=[
                        {
                            "name": "state",
                            "values": ["available"],
                        },
                        {
                            "name": "tag:Name",
                            "values": [f"{self.name}-tgw"],
                        },
                    ],
                )
            )

        return self._tgw

    def Establish(self, device_ip_address: str, device_name: str = "") -> None:
        """
        Establish VPN S2S connection.

        Parameters:
            device_ip_address (str):
                The IP address of the device.
            device_name (str):
                The name of the device.

        Returns:
            None:
                This method does not return any value.
        """
        self._tgw = Ec2TransitGateway(
            self,
            f"{self.name}-transit-gateway",
            tags=Tags(self, f"{self.name}-tgw", {"Connection": self.name, "Device": device_name}).to_dict,
        )

        customer_gateway = CustomerGateway(
            self,
            f"{self.name}-customer-gateway",
            device_name=device_name,
            bgp_asn=str(self.props.bgp_asn),
            ip_address=device_ip_address,
            type=self.props.cgw_type.value,
            tags=Tags(self, f"{self.name}-cgw", {"Connection": self.name, "Device": device_name}).to_dict,
        )

        vpn_connection = VpnConnection(
            self,
            f"{self.name}-vpn-connection",
            customer_gateway_id=customer_gateway.id,
            transit_gateway_id=self.tgw.id,
            type=customer_gateway.type,
            static_routes_only=True,
            tags=Tags(self, f"{self.name}-vc", {"Connection": self.name, "Device": device_name}).to_dict,
        )

        for cidr_block in self.GetCidrBlocks():
            Ec2TransitGatewayRoute(
                self,
                f"{cidr_block}-tgw-route",
                destination_cidr_block=cidr_block,
                transit_gateway_attachment_id=vpn_connection.transit_gateway_attachment_id,
                transit_gateway_route_table_id=self.tgw.association_default_route_table_id,
            )

        Output(
            self,
            id="vpn_connection_id",
            value=vpn_connection.arn,
            resource_id=vpn_connection.arn,
        )

    def _Attach(self, cloud: IPrivateCloud) -> None:
        """
        Create transit gateway attachment.

        Parameters:
            cloud (IPrivateCloud):
                The cloud where VPN is located.

        Returns:
            None:
                This method does not return any value.
        """
        assert isinstance(cloud, AWSVpc)

        tgw_attachment = Ec2TransitGatewayVpcAttachment(
            self,
            f"{cloud.name}-{self.name}-tgw-att",
            subnet_ids=[
                cloud.subnets[SubnetType.Primary].id,
                cloud.subnets[SubnetType.EksPrimary].id,
            ],
            transit_gateway_id=self.tgw.id,
            vpc_id=cloud.vpc.id,
            tags=Tags(self, f"{cloud.name}-{self.name}-tgw-att").to_dict,
        )
        self.provider.cloudwatch_dashboard.EnableWidget(
            self.provider.cloudwatch_dashboard.WigdetTypes.VPNTraffic,
            attachment_id=tgw_attachment.id,
            gateway_id=tgw_attachment.transit_gateway_id,
            name=self.name.upper(),
        )

        cidr_blocks = self.GetCidrBlocks()

        for cidr_block in cidr_blocks:
            Route(
                self,
                f"{cloud.name}-{cidr_block}-vpn-route",
                route_table_id=cloud.vpc.default_route_table_id,
                destination_cidr_block=cidr_block,
                transit_gateway_id=self.tgw.id,
                depends_on=[tgw_attachment],
            )

        SecurityGroupRule(
            self,
            f"{cloud.name}-{self.name}-security-group-rule",
            type="ingress",
            from_port=0,
            to_port=65535,
            protocol="all",
            cidr_blocks=cidr_blocks,
            security_group_id=cloud.vpc.default_security_group_id,
        )
