from copy import deepcopy
from importlib.resources import as_file, files
from pathlib import Path
from string import Template
from typing import Dict, Optional, Union

from cdktf import Fn
from cdktf_cdktf_provider_aws.backup_plan import (
    BackupPlan,
    BackupPlanRule,
    BackupPlanRuleLifecycle,
)
from cdktf_cdktf_provider_aws.backup_selection import BackupSelection
from cdktf_cdktf_provider_aws.data_aws_ec2_instance_types import (
    DataAwsEc2InstanceTypes,
    DataAwsEc2InstanceTypesFilter,
)
from croniter import (
    CroniterBadCronError,
    CroniterBadDateError,
    CroniterBadTypeRangeError,
    CroniterNotAlphaError,
    CroniterUnsupportedSyntaxError,
    croniter,
)

from sdvcf.aws.utils import AwsUtils
from sdvcf.interface import (
    IWorkbenchFactory,
    WorkbenchCPUArch,
    WorkbenchCreationProps,
    WorkbenchType,
)
from sdvcf.interface.i_user import IUser
from sdvcf.interface.i_workbench import IWorkbench
from sdvcf.tags import Tags

from .base_workbench import AWSWorkbenchProps
from .cloud9 import AwsCloud9, AwsCloud9Props
from .compute_server import AWSComputeServer
from .notifications import AWSWorkbenchNotifications
from .provider import AWSProvider
from .repository import AWSCodeCommit
from .virtual_desktop import AWSVirtualDesktop


class AWSWorkbenchFactory(IWorkbenchFactory):
    """
    This class provides the creation and setup of AWS workbenches.

    Inherits from IWorkbenchFactory.

    Attributes:
        SUPPORTED_EC2_FAMILIES (List[str]):
            The list of supported AWS EC2 families.
        _instance_types (Dict[str, DataAwsEc2InstanceTypes]):
            The dictionary mapping of EC2 Instance type name to object representing it.
        _cpu_arch_mapping (Dict[WorkbenchCPUArch, str]):
            The dictionary mapping of CPU Arch type to it's string representation.

    Methods:
        GetInstanceType:
            Determines the appropriate instance type for a workbench
            based on its configuration properties.
        Create:
            Creates a workbench attached to a specific user.
        SetupWorkbenchBackup:
            Configures a backup schedule for the workbench.
    """

    SUPPORTED_EC2_FAMILIES = ["t4g.*", "m5.*"]

    _instance_types: Dict[str, DataAwsEc2InstanceTypes] = {}
    _cpu_arch_mapping: Dict[WorkbenchCPUArch, str] = {
        WorkbenchCPUArch.ARM64: "arm64",
        WorkbenchCPUArch.AMD64: "x86_64",
    }

    @classmethod
    def GetInstanceType(cls, props: WorkbenchCreationProps) -> str:
        """
        Determines the appropriate instance type for a workbench based on its configuration properties.

        Parameters:
            props (WorkbenchCreationProps):
                An object containing the configuration properties of the workbench.

        Returns:
            str:
                Type of an instance which suits worbench properties.
        """
        cpu_arch = cls._cpu_arch_mapping[props.cpu_arch]
        key = f"{cpu_arch}-{props.vcpu}-{props.ram_gib}"
        if key not in cls._instance_types:
            cls._instance_types[key] = DataAwsEc2InstanceTypes(
                AWSProvider.Instance(),
                f"{key}-aws-ec2-instance-types",
                filter=[
                    DataAwsEc2InstanceTypesFilter(name="processor-info.supported-architecture", values=[cpu_arch]),
                    DataAwsEc2InstanceTypesFilter(
                        name="memory-info.size-in-mib", values=[str(int(props.ram_gib * 1024))]
                    ),
                    DataAwsEc2InstanceTypesFilter(name="vcpu-info.default-vcpus", values=[str(props.vcpu)]),
                    DataAwsEc2InstanceTypesFilter(name="current-generation", values=["true"]),
                    DataAwsEc2InstanceTypesFilter(name="instance-type", values=cls.SUPPORTED_EC2_FAMILIES),
                ],
            )
        return Fn.element(cls._instance_types[key].instance_types, 0)

    @classmethod
    def Create(cls, user: IUser, props: WorkbenchCreationProps) -> IWorkbench:
        """
        Create a workbench and assigns it to a specified user.

        Parameters:
            user (IUser):
                The user object to which the workbench will be assigned.
            props (WorkbenchCreationProps):
                An object containing the configuration properties for the new workbench.

        Raises:
            NotImplementedError: If the requested workbench type is not supported yet.

        Returns:
            IWorkbench: An instance representing the newly created workbench.
        """
        workbench: Optional[IWorkbench] = None
        wb_props = {
            "itype": cls.GetInstanceType(props),
            "os": props.os,
            "registry_policy_info": props.registry_policies,
        }

        if props.type == WorkbenchType.ComputeServer:
            workbench = AWSComputeServer(user=user, props=AWSWorkbenchProps(**wb_props))
        elif props.type == WorkbenchType.VirtualDesktop:
            workbench = AWSVirtualDesktop(user=user, props=AWSWorkbenchProps(**wb_props))
        elif props.type == WorkbenchType.WebIDE:
            assert (
                props.cpu_arch == WorkbenchCPUArch.AMD64
            ), f"{props.cpu_arch.name} architecture is not supported by {props.type.name} workbench type"
            workbench = AwsCloud9(user=user, props=AwsCloud9Props(**wb_props))
        else:
            raise NotImplementedError(f"`{props.type}` Workbench type is not supported yet")

        if AWSCodeCommit in user.plugins:
            with as_file(files("sdvcf.aws.resources").joinpath("workbench/scripts/codecommit.sh")) as file:
                workbench.AddUserDataFile(file, {"user": user.name})

        user_data_options = {
            "sdvcf_user": workbench.posix_username,
            "sdvcf_region": workbench.provider.region,
            "sdvcf_miscBucket": workbench.provider.misc_s3_bucket.bucket,
            **{f"sdvcf_misc_{key}": workbench.provider.misc_items[key] for key in workbench.provider.misc_items.keys()},
        }

        for reg in props.registries:
            with as_file(
                files(workbench.SCRIPTS_MODULE).joinpath(f"{workbench.SCRIPTS_PATH_PREFIX}/add-registry.sh")
            ) as file:
                workbench.AddUserDataFile(file, reg)

        for script, parameters in props.blueprints.items():
            parameters_copy = deepcopy(parameters)
            if isinstance(parameters_copy, dict):
                for key, param in parameters_copy.items():
                    parameters_copy[key] = Template(param).safe_substitute(user_data_options)

            workbench.AddUserDataFile(Path(script), parameters_copy)

        AWSWorkbenchNotifications.SetupAlarms(workbench)

        cls.SetupWorkbenchBackup(workbench=workbench, **props.backup)

        return workbench

    @staticmethod
    def SetupWorkbenchBackup(
        workbench: Union[AWSComputeServer, AWSVirtualDesktop, AwsCloud9],
        schedule: str = "0 0 * * * *",
        retention_days: int = 30,
    ) -> BackupSelection:
        """
        Configures a backup schedule for a specified workbench.

        Parameters:
            schedule (str):
                A CRON expression as a string that defines the backup schedule.
            retention_days (int):
                The number of days to retain the backups of the workbench.
            workbench (Union[AWSComputeServer, AWSVirtualDesktop, AwsCloud9]):
                The workbench object for which the backup schedule will be configured.

        Returns:
            BackupSelection: An instance representing the configured backup selection for the workbench.
        """

        splitted_schedule = schedule.split(" ")

        if len(splitted_schedule) == 5:
            splitted_schedule.append("*")

        try:
            croniter(" ".join(splitted_schedule))
        except (
            CroniterBadCronError,
            CroniterBadDateError,
            CroniterBadTypeRangeError,
            CroniterNotAlphaError,
            CroniterUnsupportedSyntaxError,
        ) as error:
            raise ValueError(f"Invalid cron expression: {error}") from error

        if (splitted_schedule[2] == "*") and (splitted_schedule[4] != "*"):
            splitted_schedule[2] = "?"
        else:
            splitted_schedule[4] = "?"

        schedule = " ".join(splitted_schedule)

        NAME_PREFIX = f"{workbench.provider.name}-{workbench.name}"

        backup_plan_rid = f"{NAME_PREFIX}-bplan"
        backup_plan_name = AwsUtils.backupVaultName(backup_plan_rid)
        backup_plan = BackupPlan(
            workbench,
            backup_plan_rid,
            name=backup_plan_name,
            rule=[
                BackupPlanRule(
                    rule_name=AwsUtils.backupRuleName(f"{backup_plan_name}-rule"),
                    target_vault_name=workbench.provider.workbench_backup_vault.name,
                    schedule=f"cron({schedule})",
                    lifecycle=BackupPlanRuleLifecycle(delete_after=retention_days),
                )
            ],
            tags=Tags(workbench, backup_plan_name).to_dict,
        )

        backup_selection_rid = f"{NAME_PREFIX}-bselection"
        backup_selection_name = AwsUtils.backupSelectionName(backup_selection_rid)
        return BackupSelection(
            workbench,
            backup_selection_rid,
            name=backup_selection_name,
            iam_role_arn=workbench.provider.workbench_backup_vault_role.arn,
            plan_id=backup_plan.id,
            resources=[workbench.instance.arn],
        )
