from enum import Enum

from .notifications import (
    AWSNetworkNotifications,
    AWSRunnerNotifications,
    AWSWorkbenchNotifications,
)


class SecurityRuleProtocol(str, Enum):
    """
    An enumeration of commonly used network protocols for security rule configuration.

    This enumeration represents the protocol types that can be applied to network security rules, such as those used
    in configuring security groups in a cloud environment.

    Attributes:
        TCP (str):
            Represents the TCP (Transmission Control Protocol).
        UDP (str):
            Represents the UDP (User Datagram Protocol).
        ICMP (str):
            Represents the ICMP (Internet Control Message Protocol).
        AllPorts (str):
            Special value representing all protocols across all ports.
            Typically used to specify a wildcard rule that applies to all traffic.
    """

    TCP = "tcp"
    UDP = "udp"
    ICMP = "icmp"
    AllPorts = "-1"


class SubnetType(str, Enum):
    """
    Represents different types of subnets within an AWS Resource Group.

    This enumeration defines various subnet types that could be used to categorize and provision network segments
    in AWS according to their intended use and network configurations.

    Members:
        Primary (str):
            A primary subnet, typically used for main operational resources.
        Secondary (str):
            A secondary subnet, often used for supplementary or non-critical resources.
        EksPrimary (str):
            A primary subnet designated for Elastic Kubernetes Service (EKS) clusters.
        EksSecondary (str):
            A secondary subnet for additional EKS cluster resources or workloads.
        Public (str):
            A public subnet, accessible from the internet, usually with an internet gateway attached.
        NAT (str):
            A subnet used for NAT services, allowing private subnets to access the internet.
    """

    Primary = "primary"
    Secondary = "secondary"
    EksPrimary = "eks_primary"
    EksSecondary = "eks_secondary"
    Public = "public"
    NAT = "nat"


class ConnectionType(str, Enum):
    """
    Enumeration of connection types for accessing an Amazon EC2 environment.

    This defines the supported methods by which a user can establish a connection to an Amazon EC2 instance.

    Members:
        CONNECT_SSH (str):
            Indicates a connection type that utilizes the Secure Shell (SSH) protocol
            for secure command execution on the remote EC2 instance.
        CONNECT_SSM (str):
            Represents a connection type that uses AWS Systems Manager (SSM)
            for managed instance connectivity without requiring an open inbound port.
    """

    CONNECT_SSH = "CONNECT_SSH"
    CONNECT_SSM = "CONNECT_SSM"


class NotificationTypes(Enum):
    """
    Enumeration of notification categories for different AWS resource activities.

    This enumeration groups the different types of notifications by the AWS resource they are associated with,
    allowing for organized handling of notifications based on the resource type.

    Members:
        workbenches (AWSWorkbenchNotifications):
            Notifications related to AWS Workbench activities.
        network (AWSNetworkNotifications):
            Notifications related to AWS Network activities.
        runners (AWSRunnerNotifications):
            Notifications related to AWS Runner activities.
    """

    workbenches = AWSWorkbenchNotifications
    network = AWSNetworkNotifications
    runners = AWSRunnerNotifications
