from abc import abstractmethod
from typing import Any, Dict, List, Optional

from cdktf import TerraformResourceLifecycle
from cdktf_cdktf_provider_aws.data_aws_ami import DataAwsAmi, DataAwsAmiFilter
from cdktf_cdktf_provider_aws.data_aws_ec2_instance_type import DataAwsEc2InstanceType
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.iam_instance_profile import IamInstanceProfile
from cdktf_cdktf_provider_aws.iam_role import IamRole
from cdktf_cdktf_provider_aws.iam_role_policy_attachment import IamRolePolicyAttachment
from cdktf_cdktf_provider_aws.instance import Instance, InstanceEbsBlockDevice
from cdktf_cdktf_provider_aws.security_group import (
    SecurityGroup,
    SecurityGroupEgress,
    SecurityGroupIngress,
)
from cdktf_cdktf_provider_aws.subnet import Subnet

from sdvcf.interface.i_private_cloud import IPrivateCloud
from sdvcf.interface.i_service_machine import (
    IServiceMachine,
    ServiceMachineOS,
    ServiceMachineProps,
)
from sdvcf.tags import Tags

from .enums import SecurityRuleProtocol
from .utils import AwsUtils
from .vpc import AWSProvider, AWSVpc


class AWSServiceMachineProps(ServiceMachineProps):
    """
    AWSServiceMachineProps is a configuration class that extends ServiceMachineProps,
        adding AWS-specific properties.

    Attributes:
        subnet (Subnet): Subnet object where to create service machine.
    """

    subnet: Subnet

    def __init__(self, subnet: Subnet, **kwargs: Any):
        super().__init__(**kwargs)

        self.subnet = subnet


class AWSServiceMachine(IServiceMachine):
    """
    Class that contains resources for service machine.

    This class provides the creation and setup of the service machine using AWS resources.

    Inherits from IServiceMachine.

    Attributes:
        provider (AWSProvider):
            The instance of the AWS Provider.
        cloud (AWSVpc):
            The instance of the AWS VPC.
        props (ServiceMachineProps):
            The instance of the service machine properties.

    Private Attributes:
        _security_group (SecurityGroup):
            Lazily initialized AWS Security Group representation.
            None until accessed.
        _iam_role (IamRole):
            Lazily initialized AWS IAM Role representation.
            None until accessed.
        _instance_profile (IamInstanceProfile):
            Lazily initialized AWS IAM Instance Profile representation.
            None until accessed.
        _instance (Instance):
            Lazily initialized AWS Instance representation.
            None until accessed.
        _ami_os_family_mapping (`Dict[ServiceMachineOS, str]`):
            A dictionary mapping of ServiceMachineOS enum to its family in AWS as a string.
        _ami_filter_mapping (`Dict[ServiceMachineOS, str]`):
            A dictionary mapping of ServiceMachineOS enum to its AMI Image filter in AWS as a string.
        _misc_bucket_policy_att (IamRolePolicyAttachment):
            Lazily initialized IamRolePolicyAttachment.
            None until accessed.
    Public class constants
        NAME_PREFIX (str):
            A string that contains the prefix for the names of all created resources.

    Static Methods:
        GetIngressSecurityRules:
            Creates a list with SecurityGroupIngress objects for security groups creation
            based on provided ports, protocols and CIDR blocks.

    Properties:
        security_group:
            Returns the SecurityGroup instance, initializing it if it has not been already.
        iam_role:
            Returns the IamRole instance, initializing it if it has not been already.
        instance_profile:
            Returns the IamInstanceProfile instance, initializing it if it has not been already.
        instance:
            Returns the Instance instance, initializing it if it has not been already.
        misc_bucket_policy_att:
            Returns IamRolePolicyAttachment object that enables access to the misc bucket
            for service machine. Needs to be triggered explicitly from inherited class to enable.
        user_data:
            Returns compiled user data in string format.
        type:
            Abstract property that is supposed to be defined it inherited classes.
            Returns cloud component type in str.
        posix_username:
            Abstract property that is supposed to be defined it inherited classes.
            Returns user name of the Service Machine OS user.
        exposed ports:
            Abstract property that is supposed to be defined it inherited classes.
            Returns list on Service Machine exposed ports.
    """

    cloud: AWSVpc
    provider: AWSProvider

    NAME_PREFIX: str

    props: AWSServiceMachineProps

    _security_group: Optional[SecurityGroup]
    _iam_role: Optional[IamRole]
    _instance_profile: Optional[IamInstanceProfile]
    _instance: Optional[Instance]
    _ami_os_family_mapping: Dict[ServiceMachineOS, str]
    _ami_filter_mapping: Dict[ServiceMachineOS, str]
    _misc_bucket_policy_att: Optional[IamRolePolicyAttachment]

    def __init__(self, cloud: IPrivateCloud, ns: str, props: ServiceMachineProps):
        super().__init__(cloud, ns, props)

        assert isinstance(self.cloud, AWSVpc)
        assert isinstance(self.provider, AWSProvider)

        self.NAME_PREFIX = f"{self.provider.name}-{self.name}"

        self._instance = None
        self._iam_role = None
        self._instance_profile = None
        self._security_group = None
        self._misc_bucket_policy_att = None
        self._ami_os_family_mapping = {
            ServiceMachineOS.Ubuntu18_04: "ubuntu",
            ServiceMachineOS.Ubuntu20_04: "ubuntu",
            ServiceMachineOS.Ubuntu22_04: "ubuntu",
        }
        self._ami_filter_mapping = {
            ServiceMachineOS.Ubuntu18_04: "ubuntu/images/*/ubuntu-*-18.04-*-server-*",
            ServiceMachineOS.Ubuntu20_04: "ubuntu/images/*/ubuntu-*-20.04-*-server-*",
            ServiceMachineOS.Ubuntu22_04: "ubuntu/images/*/ubuntu-*-22.04-*-server-*",
        }

    @property
    def security_group(self) -> SecurityGroup:
        """
        A property that creates and configures a security group for a service machine instance.

        This property ensures the security group's name adheres to validation rules and generates
        ingress and egress rules based on provided parameters such as ports, CIDR blocks, and protocols.
        Additionally, it applies the appropriate tags to the security group.

        Returns:
            SecurityGroup:
                An object representing the configured AWS Security Group.
        """
        if self._security_group is None:
            rid = f"{self.NAME_PREFIX}-security-group"
            name = AwsUtils.securityGroupName(rid)
            self._security_group = SecurityGroup(
                self,
                rid,
                name=name,
                vpc_id=self.cloud.vpc.id,
                ingress=self.GetIngressSecurityRules(self.props.ports, self.props.ingress_cidr_blocks),
                egress=[
                    SecurityGroupEgress(
                        from_port=0,
                        to_port=0,
                        protocol=SecurityRuleProtocol.AllPorts,
                        cidr_blocks=["0.0.0.0/0"],
                    )
                ],
                tags=Tags(self, name).to_dict,
            )
        return self._security_group

    @property
    def iam_role(self) -> IamRole:
        """
        Creates and configures an IAM role for a service machine.

        This property ensures that the IAM role has a valid name and
        includes the necessary policy statements to be assumed by an EC2 instance.
        Additionally, it applies the appropriate tags to the IAM role.

        Returns:
            IamRole:
                An object representing the configured AWS IAM Role.
        """
        if self._iam_role is None:
            rid = f"{self.NAME_PREFIX}-iam-role"
            assume_document = DataAwsIamPolicyDocument(
                self,
                f"{rid}-policy-doc",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=["sts:AssumeRole"],
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                type="Service", identifiers=["ec2.amazonaws.com"]
                            )
                        ],
                    ),
                ],
            )
            name = AwsUtils.iamRoleName(rid)
            self._iam_role = IamRole(
                self,
                rid,
                name=name,
                path=f"/{self.cloud.name}/",
                assume_role_policy=assume_document.json,
                tags=Tags(self, name).to_dict,
            )
        return self._iam_role

    @property
    def instance_profile(self) -> IamInstanceProfile:
        """
        Creates and configures an AWS IAM Instance Profile for a service machine.

        This property ensures that the IAM Instance Profile is created with a valid name and
        associated with the correct IAM role.
        Additionally, it applies the appropriate tags to the IAM Instance Profile.

        Returns:
            IamInstanceProfile:
                An object representing the configured AWS IAM Instance Profile.
        """
        if self._instance_profile is None:
            rid = f"{self.NAME_PREFIX}-instance-profile"
            name = AwsUtils.instanceProfileName(rid)

            self._instance_profile = IamInstanceProfile(
                self,
                rid,
                name=name,
                role=self.iam_role.name,
                tags=Tags(self, name).to_dict,
            )
        return self._instance_profile

    @property
    def misc_bucket_policy_att(self) -> IamRolePolicyAttachment:
        if self._misc_bucket_policy_att is None:
            self._misc_bucket_policy_att = IamRolePolicyAttachment(
                self,
                f"{self.NAME_PREFIX}-misc-bucket-policy-att",
                role=self.iam_role.name,
                policy_arn=self.provider.misc_s3_bucket_ro_policy.arn,
            )
        return self._misc_bucket_policy_att

    @property
    def instance(self) -> Instance:
        """
        A property that creates and configures an AWS instance for a service machine.

        This property specifies the appropriate AMI image and sets network properties such as subnet and security group.
        It also initializes the instance with a user data script, and assigns an SSH key and tags.
        The username, password, and endpoint information are outputted to Terraform outputs.

        Returns:
            Instance:
                An object representing AWS EC2 instance.
        """
        if self._instance is None:
            ec2_instance_type = DataAwsEc2InstanceType(
                self, f"{self.NAME_PREFIX}-instance-type-ds", instance_type=self.props.itype
            )
            aws_ami = DataAwsAmi(
                self,
                f"{self.NAME_PREFIX}-ami-ids-data",
                owners=["amazon"],
                most_recent=True,
                filter=[
                    DataAwsAmiFilter(name="name", values=[self._ami_filter_mapping[self.props.os]]),
                    DataAwsAmiFilter(name="architecture", values=ec2_instance_type.supported_architectures),
                    DataAwsAmiFilter(name="root-device-type", values=["ebs"]),
                ],
            )

            self._instance = Instance(
                self,
                self.NAME_PREFIX,
                ami=aws_ami.id,
                instance_type=ec2_instance_type.instance_type,
                subnet_id=self.props.subnet.id,
                vpc_security_group_ids=[self.security_group.id],
                iam_instance_profile=self.instance_profile.name,
                associate_public_ip_address=False,
                ebs_optimized=False,
                ebs_block_device=[
                    InstanceEbsBlockDevice(device_name=aws_ami.root_device_name, volume_size=self.props.disk_size),
                ],
                user_data=self.user_data,
                lifecycle=TerraformResourceLifecycle(ignore_changes=["ami"]),
                tags=Tags(self, self.NAME_PREFIX).to_dict,
                depends_on=self.cloud.internet_connection,
            )
        return self._instance

    @staticmethod
    def GetIngressSecurityRules(ports: List[int], ingress_cidr_blocks: List[str]) -> List[SecurityGroupIngress]:
        """
        Creates list with Security Group Ingress rules

        This method generates a list of ingress rules from provided ports,
        using TCP protocol and Ingress CIDR blocks from props.

        Parameters:
            ports (List[str, int]):
                List with ports to expose on the service machine.
                (It is recommended to use SecurityRuleProtocol enum while creating this list in inherited classes)
            ingress_cidr_blocks (List[str]):
                List with ingress CIDR IPs for networks where to expose ports.

        Returns:
            List[SecurityGroupIngress]:
                A list of SecurityGroupIngress objects for Security Rule creation.
        """
        rules: List[SecurityGroupIngress] = []
        for port in ports:
            rules.append(
                SecurityGroupIngress(
                    from_port=port,
                    to_port=port,
                    protocol=SecurityRuleProtocol.TCP.value,
                    cidr_blocks=ingress_cidr_blocks,
                )
            )
        return rules

    @property
    def user_data(self) -> str:
        """
        A property that generates the user data script for initializing the EC2 instance.

        Returns:
            str:
                A multipart user data script.
        """
        data = super().user_data
        # https://repost.aws/knowledge-center/execute-user-data-ec2
        return (
            'Content-Type: multipart/mixed; boundary="//"\n'
            "MIME-Version: 1.0\n"
            "--//\n"
            'Content-Type: text/cloud-config; charset="us-ascii"\n'
            "MIME-Version: 1.0\n"
            "Content-Transfer-Encoding: 7bit\n"
            'Content-Disposition: attachment; filename="cloud-config.txt"\n'
            "#cloud-config\n"
            "cloud_final_modules:\n"
            "- [scripts-user, always]\n"
            "--//\n"
            'Content-Type: text/x-shellscript; charset="us-ascii"\n'
            "MIME-Version: 1.0\n"
            "Content-Transfer-Encoding: 7bit\n"
            'Content-Disposition: attachment; filename="userdata.txt"\n'
            f"{data}"
            "--//--\n"
        )

    @property
    @abstractmethod
    def exposed_ports(self) -> List[int]: ...

    @property
    @abstractmethod
    def posix_username(self) -> str: ...
