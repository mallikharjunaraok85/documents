import json
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import boto3
from cdktf import Fn, TerraformBackend
from cdktf_cdktf_provider_aws import provider
from cdktf_cdktf_provider_aws.backup_vault import BackupVault
from cdktf_cdktf_provider_aws.data_aws_caller_identity import DataAwsCallerIdentity
from cdktf_cdktf_provider_aws.data_aws_iam_policy import DataAwsIamPolicy
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.data_aws_partition import DataAwsPartition
from cdktf_cdktf_provider_aws.iam_policy import IamPolicy
from cdktf_cdktf_provider_aws.iam_role import IamRole
from cdktf_cdktf_provider_aws.iam_role_policy_attachment import IamRolePolicyAttachment
from cdktf_cdktf_provider_aws.provider import AwsProviderDefaultTags
from cdktf_cdktf_provider_aws.s3_bucket import S3Bucket
from cdktf_cdktf_provider_aws.s3_bucket_cors_configuration import (
    S3BucketCorsConfiguration,
    S3BucketCorsConfigurationCorsRule,
)
from cdktf_cdktf_provider_aws.s3_object import S3Object
from cdktf_cdktf_provider_aws.s3_object_copy import S3ObjectCopy
from constructs import Construct

from sdvcf.interface import ICloudProvider, IProvider, MiscProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .dashboard import AWSDashboard
from .enums import NotificationTypes
from .s3_managed_backend import S3ManagedBackend
from .utils import AwsUtils


class AWSProvider(ICloudProvider):
    """
    Class that contains resources for AWS Provider.

    Inherits from ICloudProvider.

    Private Attributes:
        _caller_identity (DataAwsCallerIdentity):
            Lazily initialized AWS Caller Identity representation.
            None until accessed.
        _misc_s3_bucket (S3Bucket):
            Lazily initialized AWS S3 Bucket representation.
            None until accessed.
        _misc_s3_bucket_ro_policy (IamPolicy):
            Lazily initialized AWS IAM Policy representation.
            None until accessed.
        _cloudwatch_dashboard (AWSDashboard):
            Lazily initialized AWS Dashboard representation.
            None until accessed.
        _workbench_backup_vault (BackupVault):
            Lazily initialized AWS Backup Vault representation.
            None until accessed.
        _workbench_backup_vault_role (IamRole):
            Lazily initialized AWS IAM Role representation.
            None until accessed.
        _default (provider.AwsProvider):
            Lazily initialized AWS Provider representation with default region "us-east-1".
            None until accessed.
            If selected region is "us-east-1", "self.provider" will be returned.

    Public Attributes:
        provider:
            Returns the AwsProvider instance.


    Public static class constants
        MISC_PREFIX (str):
            A string that contains the prefix for the S3 Misc Bucket.

    Public class constants
        region (str):
            A string that contains the region.
        s3_bucker_cors_configuration_rule_list (List[S3BucketCorsConfigurationCorsRule]):
            A list with S3 Buckets CORS configuration for Misc and Registry buckets

    Methods:
        _SetupBackend:
            Internal method to set up the Terraform backend. configuration.
        _CreateVmimportRole:
            Internal method to create vmimport role with policies for AMI import if not exist in account
        AddMiscItem:
            Adds an items to Misc S3 Bucket.
        CommitDashboard:
            Commit AWS Dashboard.

    Properties:
        caller_identity:
            Returns the DataAwsCallerIdentity instance, initializing it if it has not been already.
        misc_s3_bucket:
            Returns the S3Bucket instance, initializing it if it has not been already.
        misc_s3_bucket_ro_policy:
            Returns the IamPolicy instance, initializing it if it has not been already.
        cloudwatch_dashboard:
            Returns the AWSDashboard instance, initializing it if it has not been already.
        workbench_backup_vault:
            Returns the BackupVault instance, initializing it if it has not been already.
        workbench_backup_vault_role:
            Returns the IamRole instance, initializing it if it has not been already.
        default:
            Returns the AwsProvider instance, initializing it if it has not been already.
    """

    MISC_PREFIX = "Project/External"
    region: str
    s3_bucker_cors_configuration_rule_list: List[S3BucketCorsConfigurationCorsRule]

    _account_prefix: str = ""

    _default: Optional[provider.AwsProvider]
    _caller_identity: Optional[DataAwsCallerIdentity]
    _partition: Optional[DataAwsPartition]
    _misc_s3_bucket: Optional[S3Bucket]
    _misc_s3_bucket_ro_policy: Optional[IamPolicy]
    _cloudwatch_dashboard: Optional[AWSDashboard]
    _workbench_backup_vault: Optional[BackupVault]
    _workbench_backup_vault_role: Optional[IamRole]

    def __init__(
        self, scope: Construct, ns: str, region: str, notifications: Dict[str, Dict[str, List[str]]] = {}, **_: Any
    ):
        self.region = region
        super().__init__(scope, ns)

        self.s3_bucker_cors_configuration_rule_list = [
            S3BucketCorsConfigurationCorsRule(
                allowed_headers=["*"], allowed_methods=["GET", "PUT"], allowed_origins=["*"], expose_headers=[]
            )
        ]

        self._default = None
        self._caller_identity = None
        self._partition = None
        self._misc_s3_bucket = None
        self._misc_s3_bucket_ro_policy = None
        self._cloudwatch_dashboard = None
        self._workbench_backup_vault = None
        self._workbench_backup_vault_role = None

        for type, config in notifications.items():
            for email in config.get("subscribers", []):
                NotificationTypes[type].value.Subscribe(email)

        default_tags = Tags(self, self.name).to_dict
        default_tags.pop("Name")
        self.provider = provider.AwsProvider(
            self, ns, region=region, default_tags=[AwsProviderDefaultTags(tags=default_tags)]
        )

        self._CreateVmimportRole()

    @property
    def default(self) -> provider.AwsProvider:
        if self._default is None:
            if self.region == "us-east-1":
                return self.provider
            else:
                self._default = provider.AwsProvider(
                    self,
                    f"{self.name}-default",
                    region="us-east-1",
                    alias=f"{self.name}-default",
                )
        return self._default

    @property
    def account_prefix(self) -> str:
        """
        A property that generates the unique for AWS prefix with account ID.

        Returns:
            str:
                Plain string with reserved keyword and account ID.
        """
        if not self.__class__._account_prefix:
            account_id = boto3.client("sts").get_caller_identity().get("Account")
            self.__class__._account_prefix = f"sdvcf-{account_id}"
        return self.__class__._account_prefix

    def _SetupBackend(self, provider: Optional[IProvider] = None) -> TerraformBackend:
        """
        Sets up the Terraform backend configuration.

        Parameters:
            provider (IProvider):
                The provider where the backend is to be set up.
                If no provider is specified (None), the backend is set up within the local context.

        Returns:
            TerraformBackend:
                The configured Terraform backend instance.
        """
        bucket_name = AwsUtils.makeUniqueS3BucketName(f"{self.account_prefix}-{self.name}")
        key = AwsUtils.makeUniqueS3BucketName(f"{self.account_prefix}-{provider.name}") if provider else bucket_name
        return S3ManagedBackend(
            provider or self,
            region=self.region,
            bucket=f"{bucket_name}",
            key=f"{key}.terraform.tfstate",
            encrypt=True,
        )

    def AddMiscItem(self, props: MiscProps):
        """
        Sets up the Terraform backend configuration.

        Parameters:
            props (MiscProps):
                An object of MiscProps which contains properties of the Misc Item.

        Returns:
            None:
                This method does not return any value.
        """
        s3obj = None
        parsed_uri = urlparse(props.uri)
        if parsed_uri.scheme == "" and parsed_uri.path != "" and parsed_uri.netloc == "":
            s3obj = S3Object(
                self,
                f"{self.name}-{props.name}-s3-object",
                bucket=self.misc_s3_bucket.bucket,
                key=f"{self.MISC_PREFIX}/{props.path.strip('/')}",
                source=parsed_uri.path,
            )
        elif parsed_uri.scheme == "s3" and parsed_uri.path != "" and parsed_uri.netloc != "":
            s3obj = S3ObjectCopy(
                self,
                f"{self.name}-{props.name}-s3-object",
                bucket=self.misc_s3_bucket.bucket,
                key=f"{self.MISC_PREFIX}/{props.path.strip('/')}",
                source=f"{parsed_uri.netloc}/{parsed_uri.path.strip('/')}",
            )
        else:
            raise RuntimeError(f"Unsupported uri type: {props.uri}")

        self.misc_items.update({props.name: Fn.format("s3://%s/%s", [s3obj.bucket, s3obj.key])})

    @property
    def caller_identity(self) -> DataAwsCallerIdentity:
        """
        A property that creates and configures an AWS Caller Identity.

        Returns:
            DataAwsCallerIdentity:
                An object representing AWS Caller Identity.
        """
        if self._caller_identity is None:
            self._caller_identity = DataAwsCallerIdentity(self, f"{self.name}-data-aws-caller-identity")
        return self._caller_identity

    @property
    def partition(self) -> DataAwsPartition:
        """
        A property that creates and configures an AWS Partition.

        Returns:
            DataAwsPartition:
                An object representing information about the current AWS partition in which Terraform is working.
        """
        if self._partition is None:
            self._partition = DataAwsPartition(self, f"{self.name}-data-aws-partition")
        return self._partition

    @property
    def misc_s3_bucket(self) -> S3Bucket:
        """
        A property that creates and configures an AWS S3 Bucket.

        Returns:
            S3Bucket:
                An object representing AWS S3 Bucket.
        """
        if self._misc_s3_bucket is None:
            bucket_name = AwsUtils.makeUniqueS3BucketName(f"internal-{self.name}-misc")
            self._misc_s3_bucket = S3Bucket(
                self,
                bucket_name,
                bucket=bucket_name,
                tags=Tags(self, bucket_name).to_dict,
            )
            S3BucketCorsConfiguration(
                self,
                f"{bucket_name}-cors-configuration",
                bucket=self._misc_s3_bucket.id,
                cors_rule=self.s3_bucker_cors_configuration_rule_list,
            )
            Output(
                self,
                id="misc_id",
                value=self._misc_s3_bucket.arn,
                resource_id=self._misc_s3_bucket.arn,
                is_s3_bucket=True,
            )
            self.cloudwatch_dashboard.EnableWidget(self.cloudwatch_dashboard.WigdetTypes.ProjectStorageSize)
        return self._misc_s3_bucket

    @property
    def misc_s3_bucket_ro_policy(self) -> IamPolicy:
        """
        A property that creates and configures an AWS IAM Policy.

        Returns:
            IamPolicy:
                An object representing AWS IAM Policy.
        """
        if self._misc_s3_bucket_ro_policy is None:
            rid = f"{self.name}-misc-bucket-ro-policy"
            policy_doc = DataAwsIamPolicyDocument(
                self,
                f"{rid}-document",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=["s3:ListBucket"],
                        resources=[self.misc_s3_bucket.arn],
                    ),
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=["s3:GetObject"],
                        resources=[f"{self.misc_s3_bucket.arn}/*"],
                    ),
                ],
            )

            name = AwsUtils.iamPolicyName(rid)
            self._misc_s3_bucket_ro_policy = IamPolicy(
                self,
                rid,
                name=name,
                path=f"/{self.name}/",
                policy=policy_doc.json,
                tags=Tags(self, name).to_dict,
            )
        return self._misc_s3_bucket_ro_policy

    @property
    def cloudwatch_dashboard(self) -> AWSDashboard:
        """
        A property that creates and configures an AWS Dashboard.

        Returns:
            AWSDashboard:
                An object representing AWS Dashboard.
        """
        if self._cloudwatch_dashboard is None:
            self._cloudwatch_dashboard = AWSDashboard(self)
        return self._cloudwatch_dashboard

    def CommitDashboard(self) -> None:
        """
        Commit AWS Dashboard.

        Parameters:
            None:
                This method does not have any parameters.

        Returns:
            None:
                This method does not return any value.
        """
        self.cloudwatch_dashboard.Commit()

    @property
    def workbench_backup_vault(self) -> BackupVault:
        """
        A property that creates and configures an AWS Backup Vault.

        Returns:
            BackupVault:
                An object representing AWS Backup Vault.
        """
        if self._workbench_backup_vault is None:
            rid = f"{self.name}-workbenches-bv"
            name = AwsUtils.backupVaultName(rid)
            self._workbench_backup_vault = BackupVault(
                self,
                rid,
                name=name,
                force_destroy=True,
                tags=Tags(self, name).to_dict,
            )
        return self._workbench_backup_vault

    @property
    def workbench_backup_vault_role(self) -> IamRole:
        """
        A property that creates and configures an AWS IAM Role.

        Returns:
            IamRole:
                An object representing AWS IAM Role.
        """
        if self._workbench_backup_vault_role is None:
            iam_role_rid = f"{self.name}-workbenches-biam-role"
            assume_document = DataAwsIamPolicyDocument(
                self,
                f"{iam_role_rid}-policy-document",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=["sts:AssumeRole"],
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                type="Service", identifiers=["backup.amazonaws.com"]
                            )
                        ],
                    )
                ],
            )
            iam_role_name = AwsUtils.iamRoleName(iam_role_rid)
            self._workbench_backup_vault_role = IamRole(
                self,
                iam_role_rid,
                name=iam_role_name,
                path=f"/{self.name}/",
                assume_role_policy=assume_document.json,
                tags=Tags(self, iam_role_name).to_dict,
            )

            backup_service_policy_rid = f"{iam_role_rid}-backup-service-policy"
            backup_service_policy = DataAwsIamPolicy(
                self, backup_service_policy_rid, name="AWSBackupServiceRolePolicyForBackup"
            )
            IamRolePolicyAttachment(
                self,
                f"{backup_service_policy_rid}-attach",
                policy_arn=backup_service_policy.arn,
                role=self._workbench_backup_vault_role.name,
            )

            restore_service_policy_rid = f"{iam_role_rid}-restore-service-policy"
            restore_service_policy = DataAwsIamPolicy(
                self, restore_service_policy_rid, name="AWSBackupServiceRolePolicyForRestores"
            )
            IamRolePolicyAttachment(
                self,
                f"{restore_service_policy_rid}-attach",
                policy_arn=restore_service_policy.arn,
                role=self._workbench_backup_vault_role.name,
            )
        return self._workbench_backup_vault_role

    def _CreateVmimportRole(self):
        """
        Create vmimport role and grant access to creating
        EC2 snapshots if role doesn't exist.
        Checks existing using boto3

        Parameters:
            None:
                This method does not have any parameters.

        Returns:
            None:
                This method does not return any value.
        """
        iam_role_name = "vmimport"
        client = boto3.client("iam")
        inline_policy = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Effect": "Allow",
                    "Action": [
                        "s3:GetBucketLocation",
                        "s3:GetObject",
                        "s3:ListBucket",
                        "s3:PutObject",
                        "s3:GetBucketAcl",
                    ],
                    "Resource": "*",
                },
                {
                    "Effect": "Allow",
                    "Action": ["ec2:ModifySnapshotAttribute", "ec2:CopySnapshot", "ec2:RegisterImage", "ec2:Describe*"],
                    "Resource": "*",
                },
            ],
        }
        try:
            client.get_role(RoleName=iam_role_name)
            policies = client.list_role_policies(RoleName=iam_role_name)
            if iam_role_name not in policies["PolicyNames"]:
                client.put_role_policy(
                    RoleName=iam_role_name, PolicyName=iam_role_name, PolicyDocument=json.dumps(inline_policy)
                )

        except client.exceptions.NoSuchEntityException:
            trusted_policy = {
                "Version": "2012-10-17",
                "Statement": [
                    {
                        "Effect": "Allow",
                        "Principal": {"Service": "vmie.amazonaws.com"},
                        "Action": "sts:AssumeRole",
                        "Condition": {"StringEquals": {"sts:Externalid": "vmimport"}},
                    }
                ],
            }

            client.create_role(
                RoleName=iam_role_name,
                AssumeRolePolicyDocument=json.dumps(trusted_policy),
            )

            client.put_role_policy(
                RoleName=iam_role_name, PolicyName=iam_role_name, PolicyDocument=json.dumps(inline_policy)
            )
