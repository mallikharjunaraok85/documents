import json
from datetime import datetime
from importlib.resources import as_file, files
from typing import Dict, List, Optional, Union

from cdktf import Fn, TerraformResourceLifecycle, Token
from cdktf_cdktf_provider_archive.data_archive_file import DataArchiveFile
from cdktf_cdktf_provider_aws.codecommit_approval_rule_template import (
    CodecommitApprovalRuleTemplate,
)
from cdktf_cdktf_provider_aws.codecommit_approval_rule_template_association import (
    CodecommitApprovalRuleTemplateAssociation,
)
from cdktf_cdktf_provider_aws.codecommit_repository import CodecommitRepository
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementCondition,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.iam_group_policy_attachment import (
    IamGroupPolicyAttachment,
)
from cdktf_cdktf_provider_aws.iam_policy import IamPolicy
from cdktf_cdktf_provider_aws.iam_role import IamRole
from cdktf_cdktf_provider_aws.iam_role_policy_attachment import IamRolePolicyAttachment
from cdktf_cdktf_provider_aws.iam_user_policy_attachment import IamUserPolicyAttachment
from cdktf_cdktf_provider_aws.lambda_function import LambdaFunction
from cdktf_cdktf_provider_aws.lambda_invocation import LambdaInvocation
from cdktf_cdktf_provider_aws.s3_object import S3Object
from constructs import Construct

from sdvcf.interface import (
    IPipeline,
    IRepository,
    IUser,
    IUserGroup,
    RepositoryAccessType,
    RepositoryProps,
)
from sdvcf.output import Output
from sdvcf.tags import Tags

from .group import AwsUserGroup
from .provider import AWSProvider
from .user import AWSUser
from .utils import AwsUtils


class AWSRepoSetupLambda(Construct):
    """
    Class that contains resources for Lambda that sets up AWS CodeCommit repository infrastucture.

    Inherits from Construct.

    Attributes:
        provider (AWSProvider):
            The instance of the AWSProvider associated with this Lambda Function.
        name (str):
            The name of the Lambda Function.

    Private Attributes:
        _repo_structure_s3 (S3Object):
            Lazily initialized AWS S3 Object.
            None until accessed.
        _lambda_func (LambdaFunction):
            Lazily initialized AWS Lambda Function.
            None until accessed.
        _repository_files_lambda (DataArchiveFile):
             initialized Data Archive file.
            None until accessed.
        _lambda_role (IamRole):
            Lazily initialized AWS IAM Role for AWS Lambda.
            None until accessed.
        _tags (Dict[str, str]):
            A dictionary containing user defined tags.
        _lambda_role_attachment (IamRolePolicyAttachment):
            Lazily initialized AWS IAM Role Policy Attachment for AWS Lambda.
            None until accessed.

    Public static class constants
        MISC_BUCKET_PREFIX (str):
            A string that contains the prefix of the Setup Lambda.

    Public class constants
        NAME_PREFIX (str):
            A string that contains the prefix for the names of all created resources.

    Methods:
        Setup:
            Sets up repository infrastrusture.

    Properties:
        repo_structure_s3:
            Returns the S3Object instance, initializing it if it has not been already.
        lambda_role:
            Returns the IamRole instance, initializing it if it has not been already.
        lambda_role_attachment:
            Returns the IamRolePolicyAttachment instance, initializing it if it has not been already.
        repository_files_lambda:
            Returns the DataArchiveFile instance, initializing it if it has not been already.
        lambda_func:
            Returns the LambdaFunction instance, initializing it if it has not been already.
    """

    MISC_BUCKET_PREFIX = "CodeCommit/Utils/RepoSetupLambda"

    provider: AWSProvider
    name: str

    _repo_structure_s3: Optional[S3Object]
    _lambda_func: Optional[LambdaFunction]
    _repository_files_lambda: Optional[DataArchiveFile]
    _lambda_role: Optional[IamRole]
    _lambda_role_attachment: Optional[IamRolePolicyAttachment]

    _tags: Dict[str, str]

    def __init__(self, ns: str, tags: Dict[str, str] = {}):
        self.provider = AWSProvider.Instance()
        super().__init__(self.provider, ns)

        self.name = ns
        self._tags = tags

        self._repo_structure_s3 = None
        self._lambda_func = None
        self._lambda_role = None
        self._lambda_role_attachment = None
        self._repository_files_lambda = None

    @property
    def repo_structure_s3(self) -> S3Object:
        """
        A property that creates and configures a S3 Object which contains the initial repo structure.

        Returns:
            S3Object:
                An object representing the configured AWS S3 Object.
        """
        if self._repo_structure_s3 is None:
            filename = "repository_structure.zip"
            with as_file(files("sdvcf.resources").joinpath("repository/structure")) as file:
                base_structure_archive = DataArchiveFile(
                    self,
                    id=f"{self.name}-base-structure-archive",
                    type="zip",
                    output_path=filename,
                    source_dir=str(file),
                )

            self._repo_structure_s3 = S3Object(
                self,
                f"{self.name}-s3-structure",
                bucket=self.provider.misc_s3_bucket.bucket,
                key=f"{self.MISC_BUCKET_PREFIX}/Source/{filename}",
                source=base_structure_archive.output_path,
                source_hash=base_structure_archive.output_base64_sha512,
            )
        return self._repo_structure_s3

    @property
    def lambda_role(self) -> IamRole:
        """
        A property that creates and configures a AWS IAM Role for Lambda.

        Returns:
            IamRole:
                An object representing the configured AWS IAM Role.
        """
        if self._lambda_role is None:
            lambda_assume_role_pd = DataAwsIamPolicyDocument(
                self,
                f"{self.name}-lambda-assume-role-pd",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=["sts:AssumeRole"],
                        effect="Allow",
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                type="Service", identifiers=["lambda.amazonaws.com"]
                            ),
                        ],
                    ),
                ],
            )
            lambda_id = f"{self.name}-lambda-role"
            self._lambda_role = IamRole(
                self,
                lambda_id,
                assume_role_policy=lambda_assume_role_pd.json,
                tags=Tags(self, lambda_id, self._tags).to_dict,
            )
        return self._lambda_role

    @property
    def lambda_role_attachment(self) -> IamRolePolicyAttachment:
        """
        A property that creates and configures a AWS IAM Role Attachment for Lambda.

        Returns:
            IamRolePolicyAttachment:
                An object representing the configured AWS IAM Role Attachment.
        """
        if self._lambda_role_attachment is None:
            lambda_pd = DataAwsIamPolicyDocument(
                self,
                f"{self.name}-lambda-pd",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=[
                            "codecommit:GetBranch",
                            "codecommit:GetFile",
                            "codecommit:PutFile",
                            "codecommit:CreateCommit",
                            "codecommit:CreateBranch",
                            "codecommit:GetCommit",
                            "codecommit:GetRepository",
                        ],
                        effect="Allow",
                        resources=[
                            f"arn:aws:codecommit:{self.provider.region}:{self.provider.caller_identity.account_id}:*"
                        ],
                    ),
                    DataAwsIamPolicyDocumentStatement(
                        actions=["s3:GetObject"], effect="Allow", resources=[f"{self.provider.misc_s3_bucket.arn}/*"]
                    ),
                ],
            )
            lambda_policy_id = f"{self.name}-lambda-policy"
            lambda_policy = IamPolicy(
                self,
                lambda_policy_id,
                policy=lambda_pd.json,
                tags=Tags(self, lambda_policy_id, self._tags).to_dict,
            )

            self._lambda_role_attachment = IamRolePolicyAttachment(
                self,
                f"{self.name}-lambda-rp-attach",
                policy_arn=lambda_policy.arn,
                role=self.lambda_role.name,
            )
        return self._lambda_role_attachment

    @property
    def repository_files_lambda(self) -> DataArchiveFile:
        """
        A property that creates and configures a Data Archive File for Lambda.

        Returns:
            DataArchiveFile:
                An object representing the configured Data Archive File.
        """
        if self._repository_files_lambda is None:
            with as_file(files("sdvcf.aws.resources").joinpath("lambda/repository_files/push_files.py.tmpl")) as file:
                self._repository_files_lambda = DataArchiveFile(
                    self,
                    id=f"{self.name}-lambda-setup-archive",
                    output_path="repository_files_lambda.zip",
                    source_content=Fn.templatefile(str(file), {"bucket": self.provider.misc_s3_bucket.bucket}),
                    source_content_filename="push_files.py",
                    type="zip",
                )
        return self._repository_files_lambda

    @property
    def lambda_func(self) -> LambdaFunction:
        """
        A property that creates and configures a AWS Lambda Function.

        Returns:
            LambdaFunction:
                An object representing the configured AWS Lambda Function.
        """
        if self._lambda_func is None:
            lambda_rid = f"{self.name}-lambda"
            lambda_name = AwsUtils.lambdaName(lambda_rid)
            self._lambda_func = LambdaFunction(
                self,
                lambda_rid,
                function_name=lambda_name,
                role=self.lambda_role.arn,
                filename=self.repository_files_lambda.output_path,
                source_code_hash=self.repository_files_lambda.output_base64_sha256,
                handler="push_files.lambda_handler",
                runtime="python3.8",
                timeout=300,
                tags=Tags(self, lambda_name, self._tags).to_dict,
                depends_on=[self.lambda_role_attachment],
            )
        return self._lambda_func

    def Setup(self, repo: "AWSCodeCommit") -> None:
        """
        Sets up repository infrastrusture.

        Parameters:
            repo (AWSCodeCommit):
                An object of a Code Commit repository.

        Returns:
            None:
                This method does not return any value.
        """
        LambdaInvocation(
            self,
            f"{self.name}-{repo.name}-lambda-invocation",
            function_name=self.lambda_func.function_name,
            input=json.dumps(
                {
                    "contentsKey": self.repo_structure_s3.key,
                    "repositoryDescription": repo.repository.description,
                    "repositoryName": repo.repository.repository_name,
                    "branchName": repo.props.dev_branch,
                    "defaultBranch": repo.props.default_branch,
                }
            ),
            triggers={"redeployment": self.lambda_func.source_code_hash},
            depends_on=[self.repo_structure_s3],
        )


class AWSCodeCommit(IRepository):
    """
    Class that contains resources for AWS CodeCommit repository.

    Inherits from IRepository.

    Attributes:
        provider (AWSProvider):
            The instance of the AWSProvider associated with this repository.

    Private Attributes:
        _repository (CodecommitRepository):
            Lazily initialized CodeCommit repository.
            None until accessed.
        _repo_users (List[str]):
            A list of repository users.
            None until added through the method AddUser.
        _repo_groups (List[str]):
            A list of repository groups.
            None until added through the method AddGroup.
        _tags (Dict[str, str]):
            A dictionary containing user defined tags.

    Private Static Attributes:
        _setup_lambda (AWSRepoSetupLambda):
            An object representing Setup Lambda.
        _default_principal_policy (IamPolicy):
            An object representing AWS IAM Policy.

    Methods:
        AddUser:
            Adds a user to the repository.
        AddGroup:
            Adds a group to the repository.
        CreatePipeline:
            Not Implemented.
        Commit:
            Sets up repository with initial structure.
        _AttachPolicyToUser:
            Attaches policy to a User.
        _AttachPolicyToGroup:
            Attaches policy to a Group.
        _GeneratePrincipalPolicy:
            Generates policy for the principal by the access type.
        _GeneratePrincipalPolicyDocument:
            Generates policy document for the principal by the access type.

    Properties:
        repository:
            Returns the CodecommitRepository instance, initializing it if it has not been already.
        default_principal_policy:
            Returns the IamPolicy instance, initializing it if it has not been already.
        repo_setup_lambda:
            Returns the AWSRepoSetupLambda instance, initializing it if it has not been already.
    """

    # Class attributes which are shared across all CodeCommit repositories
    _setup_lambda: Optional[AWSRepoSetupLambda] = None
    _default_principal_policy: Optional[IamPolicy] = None

    provider: AWSProvider

    _repository: Optional[CodecommitRepository]
    _repo_users: List[str]
    _repo_groups: List[str]
    _tags: Dict[str, str]

    def __init__(
        self,
        ns: str,
        props: RepositoryProps,
        tags: Dict[str, str] = {},
    ):
        ns = AwsUtils.codeCommitName(ns)
        scope = AWSProvider.Instance()

        super().__init__(scope, ns=ns if props.is_global else f"{scope.name}-{ns}", props=props)

        self._repository = None
        self._repo_users = []
        self._repo_groups = []
        self._tags = tags

        self.props.description = self.props.description or f"{self.name} repository"

    @property
    def repository(self) -> CodecommitRepository:
        """
        A property that creates and configures a AWS CodeCommit repository.

        Returns:
            CodecommitRepository:
                An object representing the configured AWS CodeCommit repository.
        """
        if self._repository is None:
            self._repository = CodecommitRepository(
                self,
                f"{self.name}-codecommit",
                lifecycle=TerraformResourceLifecycle(
                    ignore_changes=["default_branch"], prevent_destroy=self.props.is_permanent
                ),
                repository_name=self.name,
                default_branch=self.props.default_branch,
                description=self.props.description,
                tags=Tags(self, self.name, self._tags).to_dict,
            )

            default_art_rid = f"{self.name}-default-art"
            default_art_name = AwsUtils.approvalRuleName(default_art_rid)
            art = CodecommitApprovalRuleTemplate(
                self,
                default_art_rid,
                name=default_art_name,
                content=json.dumps(
                    {
                        "Version": "2018-11-08",
                        "DestinationReferences": ["refs/heads/dev"],
                        "Statements": [{"Type": "Approvers", "NumberOfApprovalsNeeded": 2}],
                    }
                ),
            )

            CodecommitApprovalRuleTemplateAssociation(
                self,
                f"{default_art_rid}-association",
                approval_rule_template_name=art.name,
                repository_name=self._repository.repository_name,
            )

            Output(
                self,
                "grc_url",
                value=f"codecommit::{self.provider.region}://{self._repository.repository_name}",
                resource_id=self._repository.arn,
            )
            Output(
                self,
                "web_url",
                value=(
                    f"https://{self.provider.region}.console.aws.amazon.com/codesuite/codecommit/"
                    f"repositories/{self._repository.repository_name}/browse"
                ),
                resource_id=self._repository.arn,
            )
        return self._repository

    @property
    def default_principal_policy(self) -> IamPolicy:
        """
        A property that creates and configures a AWS IAM Policy.

        Returns:
            IamPolicy:
                An object representing the configured AWS IAM Policy.
        """
        if self.__class__._default_principal_policy is None:
            default_policy_rid = f"{self.provider.name}-default-codecommit-user-policy"
            default_policy_name = AwsUtils.iamPolicyName(default_policy_rid)
            self.__class__._default_principal_policy = IamPolicy(
                self.provider,
                default_policy_rid,
                name=default_policy_name,
                policy=DataAwsIamPolicyDocument(
                    self.provider,
                    f"{default_policy_rid}-pd",
                    statement=[
                        DataAwsIamPolicyDocumentStatement(
                            actions=[
                                "codecommit:ListRepositories",
                            ],
                            effect="Allow",
                            resources=["*"],
                        ),
                    ],
                ).json,
                tags=Tags(self.provider, default_policy_name, self._tags).to_dict,
            )
        return self.__class__._default_principal_policy

    def AddUser(self, user: IUser, atype: RepositoryAccessType, expire: Optional[datetime] = None) -> None:
        """
        Adds a user to the repository.

        Parameters:
            user (IUser):
                An object representing AWS User
            atype (RepositoryAccessType):
                Type of the repository access.
            expire (datetime):
                Expiry date. Optional.

        Raises:
            RuntimeError:
                If user has already been added to the repository.

        Returns:
            None:
                This method does not return any value.
        """
        assert isinstance(user, AWSUser)
        if user.name not in self._repo_users:
            self._AttachPolicyToUser(user, self.default_principal_policy, "default")
            self._AttachPolicyToUser(user, self._GeneratePrincipalPolicy(user, atype, expire), atype.name)
            self._repo_users.append(user.name)
        else:
            raise RuntimeError(f"`{user.name}` user has already been added to the codecommit `{self.name}`")
        user.RegisterPlugin(self.__class__)

    def AddGroup(self, group: IUserGroup, atype: RepositoryAccessType, expire: Optional[datetime] = None) -> None:
        """
        Adds a group to the repository.

        Parameters:
            group (IGroup):
                An object representing AWS Group
            atype (RepositoryAccessType):
                Type of the repository access.
            expire (datetime):
                Expiry date. Optional.

        Raises:
            RuntimeError:
                If user has already been added to the repository.

        Returns:
            None:
                This method does not return any value.
        """
        assert isinstance(group, AwsUserGroup)
        if group.name not in self._repo_groups:
            self._AttachPolicyToGroup(group, self.default_principal_policy, "default")
            self._AttachPolicyToGroup(group, self._GeneratePrincipalPolicy(group, atype, expire), atype.name)
            self._repo_groups.append(group.name)
        else:
            raise RuntimeError(f"`{group.name}` group has already been added to the codecommit `{self.name}`")
        group.RegisterPlugin(self.__class__)

    def CreatePipeline(self) -> IPipeline:
        """
        Not implemented.
        """
        # TODO(SDV-147): Implement CreatePipeline in AWSCodeCommit
        raise NotImplementedError("CreatePipeline is unimplemented in AWSCodeCommit")

    def Commit(self) -> None:
        """
        Sets up repository with initial structure.

        Parameters:
            None:
                This method does not have any parameters.

        Returns:
            None:
                This method does not return any value.
        """
        # Ensure repository will be deployed
        self.repository

        if self.props.auto_init:
            self.repo_setup_lambda.Setup(self)

    def _AttachPolicyToUser(self, user: AWSUser, user_policy: IamPolicy, policy_type: str) -> None:
        """
        Attaches policy to a User.

        Parameters:
            user (AWSUser):
                An object representing AWS User
            user_policy (IamPolicy):
                An object representing AWS IAM Policy.
            policy_type (str):
                Policy type.

        Returns:
            None:
                This method does not return any value.
        """
        IamUserPolicyAttachment(
            self,
            f"{self.name}-{user.name}-{policy_type}-attachment",
            user=user.user.name,
            policy_arn=user_policy.arn,
        )

    def _AttachPolicyToGroup(self, user: AwsUserGroup, group_policy: IamPolicy, policy_type: str) -> None:
        """
        Attaches policy to a Group.

        Parameters:
            user (AWSGroup):
                An object representing AWS Group
            group_policy (IamPolicy):
                An object representing AWS IAM Policy.
            policy_type (str):
                Policy type.

        Returns:
            None:
                This method does not return any value.
        """
        IamGroupPolicyAttachment(
            self,
            f"{self.name}-{user.name}-{policy_type}-attachment",
            group=user.group.name,
            policy_arn=group_policy.arn,
        )

    def _GeneratePrincipalPolicy(
        self, principal: Union[AWSUser, AwsUserGroup], atype: RepositoryAccessType, expire: Optional[datetime] = None
    ) -> IamPolicy:
        """
        Generates policy for the principal by the access type.

        Parameters:
            principal (Union[AWSUser, AwsUserGroup]):
                An object representing AWS User or AWS Group
            atype (RepositoryAccessType):
                Type of the repository access.
            expire (datetime):
                Expiry date. Optional.

        Returns:
            IamPolicy:
                An object representing AWS IAM Policy.
        """
        p_rid = f"{self.name}-{atype.name}-{'u' if isinstance(principal, AWSUser) else 'g'}-{principal.name}-policy"
        p_name = AwsUtils.iamPolicyName(p_rid)
        return IamPolicy(
            self,
            p_rid,
            name=p_name,
            policy=self._GeneratePrincipalPolicyDocument(principal, atype, expire).json,
            tags=Tags(self, p_name, self._tags).to_dict,
        )

    def _GeneratePrincipalPolicyDocument(
        self, principal: Union[AWSUser, AwsUserGroup], atype: RepositoryAccessType, expire: Optional[datetime] = None
    ) -> DataAwsIamPolicyDocument:
        """
        Generates policy document for the principal by the access type.

        Parameters:
            principal (Union[AWSUser, AwsUserGroup]):
                An object representing AWS User or AWS Group
            atype (RepositoryAccessType):
                Type of the repository access.
            expire (datetime):
                Expiry date. Optional.

        Returns:
            DataAwsIamPolicyDocument:
                An object representing AWS IAM Policy Document.
        """
        name_prefix = f"{self.name}-{atype.name}-{'u' if isinstance(principal, AWSUser) else 'g'}-{principal.name}"

        expiry_condition = (
            DataAwsIamPolicyDocumentStatementCondition(
                test="DateLessThanEquals",
                variable="aws:CurrentTime",
                values=[expire.strftime("%Y-%m-%d")],
            )
            if expire
            else None
        )

        viewer_policy = DataAwsIamPolicyDocument(
            self,
            f"{name_prefix}-viewer-pd",
            statement=[
                DataAwsIamPolicyDocumentStatement(
                    actions=[
                        "codecommit:Get*",
                        "codecommit:BatchGetRepositories",
                        "codecommit:GetRepository",
                    ],
                    effect="Allow",
                    resources=[self.repository.arn],
                    condition=[expiry_condition] if expiry_condition else [],
                ),
            ],
        )

        if atype == RepositoryAccessType.VIEWER:
            return viewer_policy

        contributor_policy = DataAwsIamPolicyDocument(
            self,
            f"{name_prefix}-contributor-pd",
            override_policy_documents=[Token.as_string(viewer_policy.json)],
            statement=[
                DataAwsIamPolicyDocumentStatement(
                    actions=[
                        "codecommit:BatchGet*",
                        "codecommit:BatchDescribeMergeConflicts",
                        "codecommit:CreateBranch",
                        "codecommit:Describe*",
                        "codecommit:EvaluatePullRequestApprovalRules",
                        "codecommit:UpdatePullRequestApprovalState",
                    ],
                    effect="Allow",
                    resources=[self.repository.arn],
                    condition=[expiry_condition] if expiry_condition else [],
                ),
                DataAwsIamPolicyDocumentStatement(
                    sid="MergePR",
                    actions=["codecommit:CreatePullRequest", "codecommit:MergePullRequestBySquash"],
                    effect="Allow",
                    resources=[self.repository.arn],
                    condition=(
                        ([expiry_condition] if expiry_condition else [])
                        + [
                            DataAwsIamPolicyDocumentStatementCondition(
                                test="StringEqualsIfExists",
                                variable="codecommit:References",
                                values=["refs/heads/dev"],
                            ),
                            DataAwsIamPolicyDocumentStatementCondition(
                                test="Null",
                                variable="codecommit:References",
                                values=["false"],
                            ),
                        ]
                    ),
                ),
            ],
        )

        if atype == RepositoryAccessType.CONTRIBUTOR:
            return contributor_policy

        maintainer_policy = DataAwsIamPolicyDocument(
            self,
            f"{name_prefix}-maintainer-pd",
            override_policy_documents=[Token.as_string(contributor_policy.json)],
            statement=[
                DataAwsIamPolicyDocumentStatement(
                    actions=[
                        "codecommit:TagResource",
                        "codecommit:UntagResource",
                        "codecommit:GitPush",
                        "codecommit:Delete*",
                        "codecommit:Put*",
                        "codecommit:Post*",
                        "codecommit:Merge*",
                    ],
                    effect="Allow",
                    resources=[self.repository.arn],
                    condition=[expiry_condition] if expiry_condition else [],
                ),
                DataAwsIamPolicyDocumentStatement(
                    sid="MergePR",
                    actions=[
                        "codecommit:CreatePullRequest",
                        "codecommit:MergePullRequestBySquash",
                    ],
                    effect="Allow",
                    resources=[self.repository.arn],
                    condition=[expiry_condition] if expiry_condition else [],
                ),
            ],
        )

        return maintainer_policy

    @property
    def repo_setup_lambda(self) -> AWSRepoSetupLambda:
        """
        A property that creates and configures a Setup Lambda.

        Returns:
            AWSRepoSetupLambda:
                An object representing the configured Setup Lambda.
        """
        if self.__class__._setup_lambda is None:
            self.__class__._setup_lambda = AWSRepoSetupLambda(f"{self.provider.name}-repo-setup-labmda", self._tags)
        return self.__class__._setup_lambda
