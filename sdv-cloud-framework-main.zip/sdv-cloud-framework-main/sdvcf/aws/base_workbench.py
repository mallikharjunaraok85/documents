import itertools
from os import getenv
from typing import Any, List, Optional

from cdktf import Fn, TerraformResourceLifecycle
from cdktf_cdktf_provider_aws.data_aws_ami import DataAwsAmi, DataAwsAmiFilter
from cdktf_cdktf_provider_aws.data_aws_ec2_instance_type import DataAwsEc2InstanceType
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementCondition,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.iam_instance_profile import IamInstanceProfile
from cdktf_cdktf_provider_aws.iam_policy import IamPolicy
from cdktf_cdktf_provider_aws.iam_role import IamRole
from cdktf_cdktf_provider_aws.iam_role_policy_attachment import IamRolePolicyAttachment
from cdktf_cdktf_provider_aws.instance import Instance, InstanceEbsBlockDevice
from cdktf_cdktf_provider_aws.security_group import (
    SecurityGroup,
    SecurityGroupEgress,
    SecurityGroupIngress,
)

from sdvcf.interface import IUser, IWorkbench, WorkbenchProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .enums import SecurityRuleProtocol, SubnetType
from .provider import AWSProvider
from .user import AWSUser
from .utils import AwsUtils
from .vpc import AWSVpc


class AWSWorkbenchProps(WorkbenchProps):
    """
    AWSWorkbenchProps is a configuration class that extends WorkbenchProps, adding AWS-specific properties.

    Attributes:
        subnet_type (`SubnetType`):
            Defines the type of Subnet to be used.
            This can be either specified directly or
            inferred from an environment variable with a default value.
    """

    subnet_type: SubnetType

    def __init__(
        self,
        subnet_type: Optional[SubnetType] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self.subnet_type = subnet_type or SubnetType[getenv("AWS_WB_DEFAULT_SUBNET_TYPE", SubnetType.Primary.name)]


class AWSBaseWorkbench(IWorkbench):
    """
    Class that contains base resources for AWS Virtual Desktop and Compute Server Workbench types.

    This class provides the creation and setup of a base instance for workbench on AWS.

    Inherits from IWorkbench.

    Attributes:
        provider (`AWSProvider`):
            The instance of the AWSProvider associated with this workbench.
        cloud (`AWSVpc`):
            The instance of the AWSVpc associated with this workbench.
        props (`AWSWorkbenchProps`):
            The instance of the AWSWorkbenchProps associated with this workbench
        user (`AWSUser`):
            The instance of the AWSUser associated with this workbench

    Private Attributes:
        _security_group (`SecurityGroup`):
            Lazily initialized AWS Security Group representation.
            None until accessed.
        _instance (`Instance`):
            Lazily initialized AWS Instance representation.
            None until accessed.
        _iam_role (`IamRole`):
            Lazily initialized AWS IAM Role representation.
            None until accessed.
        _instance_profile (`IamInstanceProfile`):
            Lazily initialized AWS IAM Instance Profile representation.
            None until accessed.
        _efs_policy (`IamPolicy`):
            Lazily initialized AWS IAM Policy representation for EFS.
            None until accessed.
        _ami_os_family (`str`):
            OS family in AWS as string
        _ami_filter (`str`):
            An AMI Image filter in AWS as a string.
        _os_version (`str`):
            OS version in as string
        _registry_policy (`IamPolicy`):
            Lazily initialized AWS IAM Policy representation for registries.
            None until accessed.

    Public static class constants
        DEFAULT_WB_PASSWORD (`str`):
            A string that contains the default workbench password.

    Public class constants
        NAME_PREFIX (`str`):
            A string that contains the prefix for the names of all created resources.
        SCRIPTS_MODULE (`str`):
            A string that contains the python path to the module of the scripts.
        SCRIPTS_PATH_PREFIX (`str`):
            A string that contains the OS path to the scripts.

    Methods:
        _GetWBSecurityRules:
            Internal method to get a workbench security rules.
        _AttachPolicy:
            Internal method to attach a policy to a resource.

    Properties:
        user_data:
            Generates the user data script for initializing the EC2 instance.
        security_group:
            Returns the SecurityGroup instance, initializing it if it has not been already.
        instance:
            Returns the Instance instance, initializing it if it has not been already.
        iam_role:
            Returns the IamRole instance, initializing it if it has not been already.
        instance_profile:
            Returns the IamInstanceProfile instance, initializing it if it has not been already.
        efs_policy:
            Returns the IamPolicy instance, initializing it if it has not been already.
        registry_policy:
            Returns the IamPolicy instance, initializing it if it has not been already.
    """

    # Public static class constants
    DEFAULT_WB_PASSWORD: str = "password"

    # Public class constants
    NAME_PREFIX: str
    SCRIPTS_MODULE: str
    SCRIPTS_PATH_PREFIX: str

    # Public class attributes
    provider: AWSProvider
    cloud: AWSVpc
    props: AWSWorkbenchProps
    user: AWSUser

    # Private class attributes
    _security_group: Optional[SecurityGroup]
    _instance: Optional[Instance]
    _iam_role: Optional[IamRole]
    _instance_profile: Optional[IamInstanceProfile]
    _efs_policy: Optional[IamPolicy]
    _registry_policy: Optional[IamPolicy]
    _ami_os_family: str
    _ami_filter: str
    _os_version: str

    def __init__(self, user: IUser, props: AWSWorkbenchProps):
        assert isinstance(user, AWSUser)
        super().__init__(user.cloud, f"{user.name}-{self.__class__.__name__.lower()}", props)

        self.NAME_PREFIX = f"{self.provider.name}-{self.name}"

        self.user = user

        self._security_group = None
        self._instance = None
        self._iam_role = None
        self._instance_profile = None
        self._efs_policy = None
        self._registry_policy = None
        self._ami_os_family = self.props.ami_os_family_mapping[self.props.os]
        self._ami_filter = self.props.ami_filter_mapping[self.props.os]
        self._os_version = self.props.os_version_mapping[self.props.os]

        self.SCRIPTS_MODULE = "sdvcf.aws.resources"
        self.SCRIPTS_PATH_PREFIX = f"workbench/scripts/{self._ami_os_family}/{self._os_version}/"

    @property
    def user_data(self) -> str:
        """
        A property that generates the user data script for initializing the EC2 instance.

        This script checks if the user data has changed since the last run by comparing a hash stored on the instance.
        If there is a change, it executes the user data script and updates the hash. This ensures that the user data
        script runs only when necessary.

        Returns:
            str:
                A multipart user data script that includes a hash comparison and execution logic.
        """
        data = super().user_data
        hash = Fn.sha512(data)
        hash_file = "/var/local/ec2-userdata.hash"
        # https://repost.aws/knowledge-center/execute-user-data-ec2
        return (
            'Content-Type: multipart/mixed; boundary="//"\n'
            "MIME-Version: 1.0\n"
            "--//\n"
            'Content-Type: text/cloud-config; charset="us-ascii"\n'
            "MIME-Version: 1.0\n"
            "Content-Transfer-Encoding: 7bit\n"
            'Content-Disposition: attachment; filename="cloud-config.txt"\n'
            "#cloud-config\n"
            "cloud_final_modules:\n"
            "- [scripts-user, always]\n"
            "--//\n"
            'Content-Type: text/x-shellscript; charset="us-ascii"\n'
            "MIME-Version: 1.0\n"
            "Content-Transfer-Encoding: 7bit\n"
            'Content-Disposition: attachment; filename="userdata.txt"\n'
            "#!/bin/bash\n"
            f'if [[ "$(cat \'{hash_file}\' 2>/dev/null)" != "{hash}" ]]; then\n'
            f"  echo '{Fn.base64gzip(data)}' | base64 --decode | zcat | bash\n"
            f'  echo -n "{hash}" > "{hash_file}"\n'
            "fi\n"
            "--//--\n"
        )

    @property
    def posix_username(self) -> str:
        return AwsUtils.posixUserName(self.user.name)

    @property
    def security_group(self) -> SecurityGroup:
        """
        A property that creates and configures a security group for a workbench.

        This property ensures the security group's name adheres to validation rules and generates
        ingress and egress rules based on provided parameters such as ports, CIDR blocks, and protocols.
        Additionally, it applies the appropriate tags to the security group.

        Returns:
            SecurityGroup:
                An object representing the AWS Security Group.
        """
        if self._security_group is None:
            rid = f"{self.NAME_PREFIX}-security-group"
            name = AwsUtils.securityGroupName(rid)
            self._security_group = SecurityGroup(
                self,
                rid,
                name=name,
                vpc_id=self.cloud.vpc.id,
                ingress=self._GetWBSecurityRules(self.props.ports, [self.cloud.vpc.cidr_block]),
                egress=[
                    SecurityGroupEgress(
                        from_port=0,
                        to_port=0,
                        protocol=SecurityRuleProtocol.AllPorts.value,
                        cidr_blocks=["0.0.0.0/0"],
                    )
                ],
                tags=Tags(self, name).to_dict,
            )
        return self._security_group

    @property
    def instance(self) -> Instance:
        """
        A property that creates and configures an AWS instance for a workbench.

        This property specifies the appropriate AMI image and sets network properties such as subnet and security group.
        It also configures the Elastic Block Store (EBS) settings,
        initializes the instance with a user data script, and assigns an SSH key and tags.
        Furthermore, it attaches policies for Elastic File System (EFS) and a miscellaneous S3 bucket.
        The username, password, and endpoint information are outputted to Terraform outputs.

        Returns:
            Instance:
                An object representing AWS EC2 Instance.
        """
        if self._instance is None:
            name = f"{self.NAME_PREFIX}-instance"

            ec2_instance_type = DataAwsEc2InstanceType(self, f"{name}-instance-data", instance_type=self.props.itype)
            aws_ami = DataAwsAmi(
                self,
                f"{name}-ami-ids-data",
                owners=["amazon"],
                most_recent=True,
                filter=[
                    DataAwsAmiFilter(name="name", values=[self._ami_filter]),
                    DataAwsAmiFilter(name="architecture", values=ec2_instance_type.supported_architectures),
                    DataAwsAmiFilter(name="root-device-type", values=["ebs"]),
                ],
            )

            self._instance = Instance(
                self,
                name,
                ami=aws_ami.id,
                instance_type=self.props.itype,
                subnet_id=self.cloud.subnets[self.props.subnet_type.value].id,
                vpc_security_group_ids=[self.security_group.id],
                key_name=self.user.key_pair.key_name,
                iam_instance_profile=self.instance_profile.name,
                associate_public_ip_address=False,
                ebs_optimized=False,
                ebs_block_device=[
                    InstanceEbsBlockDevice(device_name=aws_ami.root_device_name, volume_size=self.props.disk_size),
                ],
                user_data=self.user_data,
                lifecycle=TerraformResourceLifecycle(ignore_changes=["ami"]),
                tags=Tags(self, name).to_dict,
                depends_on=self.cloud.internet_connection,
            )

            self._AttachPolicy("efs", self.efs_policy.arn)
            self._AttachPolicy("misc-bucket", self.provider.misc_s3_bucket_ro_policy.arn)
            if len(self.props.registry_policy_info) > 0:
                self._AttachPolicy("registries", self.registry_policy.arn)

            Output(
                self,
                id="username",
                value=self.posix_username,
                resource_id=self._instance.arn,
                user_name=self.user.user.name,
            )
            Output(
                self,
                id="password",
                value=self.DEFAULT_WB_PASSWORD,
                resource_id=self._instance.arn,
                user_name=self.user.user.name,
            )
            Output(
                self,
                id="endpoint",
                value=self.instance.private_ip,
                resource_id=self._instance.arn,
                user_name=self.user.user.name,
            )
        return self._instance

    @property
    def registry_policy(self) -> IamPolicy:
        """
        Creates and configures an AWS IAM Policy for registries.

        This function ensures that the IAM Policy is created with a valid name and
        that the policy document specifies fine-grained permissions for designated actions and
        may include conditional statements to enforce specific requirements for those actions.
        Additionally, it applies the appropriate tags to the IAM Policy.

        Returns:
            IamPolicy:
                An object representing the AWS IAM Policy.
        """
        if self._registry_policy is None:
            rid = f"{self.NAME_PREFIX}-registry-policy"
            reg_name = AwsUtils.iamPolicyName(rid)
            statements = [
                DataAwsIamPolicyDocumentStatement(**registry_statements)
                for registry_info in self.props.registry_policy_info
                for registry_statements in registry_info["info"]
            ]
            self._registry_policy = IamPolicy(
                self,
                rid,
                name=reg_name,
                policy=DataAwsIamPolicyDocument(
                    self,
                    f"{rid}-doc",
                    statement=statements,
                ).json,
                tags=Tags(self, reg_name).to_dict,
            )
        return self._registry_policy

    @property
    def iam_role(self) -> IamRole:
        """
        Creates and configures an IAM role for a workbench.

        This property ensures that the IAM role has a valid name,
        includes the necessary policy statements to be assumed by an EC2 instance.
        Additionally, it applies the appropriate tags to the IAM role.

        Returns:
            IamRole:
                An object representing the AWS IAM Role.
        """
        if self._iam_role is None:
            rid = f"{self.NAME_PREFIX}-iam-role"
            assume_document = DataAwsIamPolicyDocument(
                self,
                f"{rid}-policy-doc",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        actions=["sts:AssumeRole"],
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(
                                type="Service", identifiers=["ec2.amazonaws.com"]
                            )
                        ],
                    )
                ],
            )
            name = AwsUtils.iamRoleName(rid)
            self._iam_role = IamRole(
                self,
                rid,
                name=name,
                path=f"/{self.cloud.name}/{self.user.name}/",
                assume_role_policy=assume_document.json,
                tags=Tags(self, name).to_dict,
            )

        return self._iam_role

    @property
    def instance_profile(self) -> IamInstanceProfile:
        """
        Creates and configures an AWS IAM Instance Profile for a workbench.

        This property ensures that the IAM Instance Profile is created with a valid name and
        associated with the correct IAM role.
        Additionally, it applies the appropriate tags to the IAM Instance Profile.

        Returns:
            IamInstanceProfile:
                An object representing the AWS IAM Instance Profile.
        """
        if self._instance_profile is None:
            rid = f"{self.NAME_PREFIX}-iam-instance-profile"
            name = AwsUtils.instanceProfileName(rid)

            self._instance_profile = IamInstanceProfile(
                self,
                rid,
                name=name,
                role=self.iam_role.name,
                tags=Tags(self, name).to_dict,
            )
        return self._instance_profile

    def _GetWBSecurityRules(
        self,
        ports: List[int],
        ingress_cidr_blocks: List[str],
        protocol: SecurityRuleProtocol = SecurityRuleProtocol.TCP,
    ) -> List[SecurityGroupIngress]:
        """
        Creates a list with security rules for workbench network interface ports

        Parameters:
            ports (`List[int]`):
                A list of port numbers for which security rules will be defined.
            ingress_cidr_blocks (`List[str]`):
                A list of CIDR blocks that will be allowed ingress to the ports.
            protocol (`SecurityRuleProtocol`):
                The protocol (e.g., 'tcp', 'udp', 'icmp') used in the security rule.

        Returns:
            List[SecurityGroupIngress]:
                A list of AWS Security Group Ingress.

        Reference:
            https://docs.aws.amazon.com/vpc/latest/userguide/security-group-rules.html
        """
        security_rules = []
        for port in ports:
            security_rules.append(
                SecurityGroupIngress(
                    from_port=port,
                    to_port=port,
                    protocol=protocol,
                    cidr_blocks=ingress_cidr_blocks
                    + list(itertools.chain(*[vpn.GetCidrBlocks() for vpn in self.cloud.vpns])),
                )
            )
        return security_rules

    @property
    def efs_policy(self) -> IamPolicy:
        """
        Creates and configures an AWS IAM Policy for EFS.

        This function ensures that the IAM Policy is created with a valid name and
        that the policy document specifies fine-grained permissions for designated actions and
        may include conditional statements to enforce specific requirements for those actions.
        Additionally, it applies the appropriate tags to the IAM Policy.

        Returns:
            IamPolicy:
                An object representing the AWS IAM Policy.
        """
        if self._efs_policy is None:
            policy_doc = DataAwsIamPolicyDocument(
                self,
                f"{self.NAME_PREFIX}-efs-pd",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=["elasticfilesystem:ClientWrite"],
                        resources=[self.user.efs_file_system.arn],
                        condition=[
                            DataAwsIamPolicyDocumentStatementCondition(
                                test="Bool", variable="elasticfilesystem:AccessedViaMountTarget", values=["true"]
                            )
                        ],
                    ),
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        actions=[
                            "elasticfilesystem:ClientMount",
                            "elasticfilesystem:ClientWrite",
                            "elasticfilesystem:ClientRootAccess",
                        ],
                        resources=[self.user.efs_file_system.arn],
                    ),
                ],
            )

            iam_policy_rid = f"{self.NAME_PREFIX}-efs-iam-policy"
            iam_policy_name = AwsUtils.iamPolicyName(iam_policy_rid)
            self._efs_policy = IamPolicy(
                self,
                iam_policy_rid,
                name=iam_policy_name,
                path=f"/{self.provider.name}/{self.user.name}/workbench/",
                policy=policy_doc.json,
                tags=Tags(self, iam_policy_name).to_dict,
            )
        return self._efs_policy

    def _AttachPolicy(self, name: str, policy_arn: str) -> None:
        """
        Attaches an IAM policy to the IAM Role.

        Parameters:
            name (`str`):
                The name of the policy attachment.
            policy_arn (`str`):
                The id of the policy.

        Returns:
            None:
                This method does not return any value.
        """
        IamRolePolicyAttachment(
            self,
            f"{self.NAME_PREFIX}-{name}-policy-att",
            role=self.iam_role.name,
            policy_arn=policy_arn,
        )
