import hashlib
import re


class AwsUtils:
    """
    Utility class for generating valid names and configurations for various AWS resources.

    Methods:
        mfaVirtualDeviceName(name: str) -> str:     Generate a valid name for an MFA virtual device.
        cloud9EnvironmentName(name: str) -> str:    Generate a valid name for a Cloud9 environment.
        _getHashPrefix(name: str) -> str:           Generate a hash prefix based on the input string.
        snsTopicName(name: str) -> str:             Generate a valid name for an SNS topic.
        cloudwatchAlarmName(name: str) -> str:      Generate a valid name for a CloudWatch alarm.
        iamRoleName(name: str) -> str:              Generate a valid name for an IAM role.
        firewallName(name: str) -> str:             Generate a valid name for a firewall.
        backupVaultName(name: str) -> str:          Generate a valid name for a backup vault.
        backupRuleName(name: str) -> str:           Generate a valid name for a backup rule.
        backupSelectionName(name: str) -> str:      Generate a valid name for a backup selection.
        codeCommitName(name: str) -> str:           Generate a valid name for a CodeCommit repository.
        approvalRuleName(name: str) -> str:         Generate a valid name for a CodeCommit approval rule.
        eksClusterName(name: str) -> str:           Generate a valid name for an EKS cluster.
        eksNodeGroupName(name: str) -> str:         Generate a valid name for an EKS node group.
        iamPolicyName(name: str) -> str:            Generate a valid name for an IAM policy.
        ecrName(name: str) -> str:                  Generate a valid name for an ECR.
    """

    @staticmethod
    def makeUniqueS3BucketName(name: str) -> str:
        """
        Generate a unique Amazon S3 bucket name based on the given `name`.

        Parameters:
            name (str): The base name for the S3 bucket.

        Returns:
            str: A unique S3 bucket name incorporating a hash suffix.

        Note:
            The generated bucket name adheres to Amazon S3 naming rules,
            and the length is adjusted to fit within the required range.

        Reference:
            https://docs.aws.amazon.com/AmazonS3/latest/userguide/bucketnamingrules.html
        """
        suffix = f"-{AwsUtils._getHashPrefix(name)}"

        # Amazon S3: Bucket names must be between 3 (min) and 63 (max) characters long.
        return AwsUtils.s3BucketName(name[: 63 - len(suffix)] + suffix)

    @staticmethod
    def s3BucketName(name: str) -> str:
        """
        Transform a given string `name` into a valid Amazon S3 bucket name.

        Parameters:
            name (str): The input string to be converted into a valid S3 bucket name.

        Returns:
            str: A valid Amazon S3 bucket name adhering to naming rules.

        Note:
            The generated bucket name follows Amazon S3 naming rules,
            ensuring length and character restrictions are met.

        Reference:
            https://docs.aws.amazon.com/AmazonS3/latest/userguide/bucketnamingrules.html
        """
        name = re.sub(r"[^a-z0-9.\-]+", "", name).rjust(3, "0")[:63]
        if re.search(r"^[^0-9a-z]", name):
            name = "0" + name[1:]
        if re.search(r"[^0-9a-z]$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def lambdaName(name: str) -> str:
        """
        Generate a valid name for an AWS Lambda function based on the given `name`.

        Parameters:
            name (str): The desired name for the Lambda function.

        Returns:
            str: A valid Lambda function name adhering to AWS naming rules.

        Note:
            The generated Lambda function name follows AWS naming rules,
            ensuring length and character restrictions are met.

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-lambda-function.html#cfn-lambda-function-functionname
        """
        return re.sub(r"[^a-zA-Z0-9_\-]+", "", name).rjust(1, "0")[:64]

    @staticmethod
    def ecrName(name: str) -> str:
        """
        Generate a valid name for an AWS ECR based on the given `name`.

        Parameters:
            name (str): The desired name for the AWS ECR.

        Returns:
            str: A valid AWS ECR name adhering to AWS naming rules.

        Note:
            The generated AWS ECR name follows AWS naming rules,
            ensuring length and character restrictions are met.

        Reference:
            https://docs.aws.amazon.com/AmazonECR/latest/APIReference/API_Repository.html
        """
        name = re.sub(r"[^a-z0-9\-_./]", "", name.lower())

        if re.search(r"//+", name):
            name = re.sub(r"//+", "/", name)
        if re.search(r"__+", name):
            name = re.sub(r"__+", "_", name)
        if re.search(r"--+", name):
            name = re.sub(r"--+", "-", name)

        if re.search(r"^[^a-z0-9]", name):
            name = "a" + name[1:]
        if re.search(r"[^a-z0-9]$", name):
            name = name[:-1] + "a"

        name = name.rjust(2, "0")[:256]

        return name

    @staticmethod
    def posixUserName(name: str) -> str:
        """
        Generate a valid POSIX user name based on the given `name`.

        Parameters:
            name (str): The input string to be converted into a valid POSIX user name.

        Returns:
            str: A valid POSIX user name adhering to naming rules.

        Note:
            The generated user name follows POSIX naming rules,
            ensuring the use of lower and upper case ASCII letters, digits, and hyphen,
            with the restriction that hyphen is not allowed as the first character.

        Reference:
            https://systemd.io/USER_NAMES/
        """
        name = re.sub(r"[^-a-z0-9]+", "-", name.lower())
        name = re.sub(r"-{2,}", "-", name)
        if re.search(r"^-", name):
            name = name[1:]
        if re.search(r"-$", name):
            name = name[:-1]
        return name

    @staticmethod
    def instanceProfileName(name: str) -> str:
        """
        Generate a valid instance profile name based on the given `name`.

        Parameters:
            name (str): The desired name for the instance profile.

        Returns:
            str: A valid instance profile name adhering to AWS naming rules.

        Note:
            The generated instance profile name follows AWS naming rules,
            allowing upper and lowercase alphanumeric characters with no spaces.
            Additional characters such as _+=,.@- are also allowed.

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iam-instanceprofile.html#cfn-iam-instanceprofile-instanceprofilename
        """
        return re.sub(r"[^\w+=,.@-]+", "", name).rjust(1, "0")[:128]

    @staticmethod
    def securityGroupName(name: str) -> str:
        """
        Generate a valid security group name based on the given `name`.

        Parameters:
            name (str): The input string to be converted into a valid security group name.

        Returns:
            str: A valid security group name adhering to AWS naming rules.

        Note:
            The generated security group name follows AWS naming rules,
            allowing a range of characters and trimming trailing spaces.
            It cannot start with 'sg-'.

        Reference:
            https://docs.aws.amazon.com/vpc/latest/userguide/security-groups.html#security-group-basics
        """
        name = re.sub(r"[^a-zA-Z0-9 ._\-:/()#,@[\]+=&;{}!$*]+", "", name.rstrip())
        return re.sub(r"^sg-", "", name).rjust(1, "0")[:255]

    @staticmethod
    def iamPolicyName(name: str) -> str:
        """
        Generate a valid IAM policy name based on the given `name`.

        Parameters:
            name (str): The desired name for the IAM policy.

        Returns:
            str: A valid IAM policy name adhering to AWS naming rules.

        Note:
            The generated IAM policy name follows AWS naming rules,
            allowing upper and lowercase alphanumeric characters without spaces,
            along with underscores (_), pluses (+), equals (=), commas (,),
            periods(.), ats (@), and hyphens (-).

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iam-policy.html#cfn-iam-policy-policyname
        """
        return re.sub(r"[^a-zA-Z0-9_+=,.@\-]+", "", name).rjust(1, "0")[:128]

    @staticmethod
    def codeCommitName(name: str) -> str:
        """
        Generate a valid CodeCommit repository name based on the given `name`.

        Parameters:
            name (str): The desired name for the CodeCommit repository.

        Returns:
            str: A valid CodeCommit repository name adhering to AWS naming rules.

        Note:
            The generated CodeCommit repository name follows AWS naming rules,
            allowing upper and lowercase alphanumeric characters, underscores (_),
            periods(.), and hyphens (-). It also ensures length restrictions are met.

        Reference:
            https://docs.aws.amazon.com/codecommit/latest/userguide/limits.html
        """
        name = re.sub(r"[^a-zA-Z0-9_.\-]+", "", name).rjust(1, "0")[:100]
        if re.search(r"\.git$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def approvalRuleName(name: str) -> str:
        """
        Generate a valid CodeCommit approval rule name based on the given `name`.

        Parameters:
            name (str): The desired name for the CodeCommit approval rule.

        Returns:
            str: A valid CodeCommit approval rule name adhering to AWS naming rules.

        Note:
            The generated approval rule name follows AWS naming rules,
            allowing upper and lowercase alphanumeric characters, underscores (_),
            periods(.), hyphens (-), and spaces ().
            It also ensures length restrictions are met.

        Reference:
            https://docs.aws.amazon.com/codecommit/latest/userguide/limits.html
        """
        name = re.sub(r"[^a-zA-Z0-9_.\- ]+", "", name).rjust(1, "0")[:100]
        if re.search(r"\.git$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def eksClusterName(name: str) -> str:
        """
        Generate a valid Amazon EKS cluster name based on the given `name`.

        Parameters:
            name (str): The desired name for the EKS cluster.

        Returns:
            str: A valid EKS cluster name adhering to AWS naming rules.

        Note:
            The generated EKS cluster name follows AWS naming rules,
            allowing only alphanumeric characters (case-sensitive) and hyphens.
            It must start with an alphabetic character and can't exceed 100 characters.

        Reference:
            https://docs.aws.amazon.com/eks/latest/userguide/create-cluster.html
        """
        name = re.sub(r"[^a-zA-Z0-9\-]+", "", name).rjust(1, "0")[:100]
        if re.search(r"^[^a-zA-Z]", name):
            name = "a" + name[1:]
        return name

    @staticmethod
    def eksNodeGroupName(name: str) -> str:
        """
        Generate a valid Amazon EKS node group name based on the given `name`.

        Parameters:
            name (str): The desired name for the EKS node group.

        Returns:
            str: A valid EKS node group name adhering to AWS naming rules.

        Note:
            The generated EKS node group name follows AWS naming rules,
            allowing alphanumeric characters, hyphens, and underscores.
            It must start with a letter or digit and can't exceed 63 characters.

        Reference:
            https://docs.aws.amazon.com/eks/latest/userguide/create-managed-node-group.html
        """
        name = re.sub(r"[^a-zA-Z0-9\-_]+", "", name).rjust(1, "0")[:63]
        if re.search(r"^[^a-zA-Z0-9]", name):
            name = "a" + name[1:]
        return name

    @staticmethod
    def iamRoleName(name: str) -> str:
        """
        Generate a valid IAM role name based on the given `name`.

        Parameters:
            name (str): The desired name for the IAM role.

        Returns:
            str: A valid IAM role name adhering to AWS naming rules.

        Note:
            The generated IAM role name follows AWS naming rules,
            allowing alphanumeric characters and common characters such as plus (+),
            equal (=), comma (,), period (.), at (@), underscore (_), and hyphen (-).
            It can't exceed 64 characters.

        Reference:
            https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_iam-quotas.html
        """
        return re.sub(r"[^a-zA-Z0-9+=,.@_\-]+", "", f"{AwsUtils._getHashPrefix(name)}-{name}").rjust(1, "0")[:64]

    @staticmethod
    def firewallName(name: str) -> str:
        """
        Generate a valid name for a firewall based on the given `name`.

        Parameters:
            name (str): The desired name for the firewall.

        Returns:
            str: A valid firewall name adhering to AWS naming rules.

        Note:
            The generated firewall name follows AWS naming rules,
            allowing alphanumeric characters and the hyphen (-).
            It can't exceed 128 characters.

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkfirewall-firewall.html#cfn-networkfirewall-firewall-firewallname
        """
        return re.sub(r"[^a-zA-Z0-9\-]+", "", name).rjust(1, "0")[:128]

    @staticmethod
    def backupVaultName(name: str) -> str:
        """
        Generate a valid name for a backup vault based on the given `name`.

        Parameters:
            name (str): The desired name for the backup vault.

        Returns:
            str: A valid backup vault name adhering to AWS naming rules.

        Note:
            The generated backup vault name follows AWS naming rules,
            allowing lowercase letters, numbers, hyphens, and an optional hash prefix.
            It can't exceed 50 characters.

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-backup-backupvault.html#cfn-backup-backupvault-backupvaultname
        """
        return re.sub(r"[^a-zA-Z0-9\-\_]+", "", f"{AwsUtils._getHashPrefix(name)}-{name}").rjust(2, "0")[:50]

    @staticmethod
    def backupRuleName(name: str) -> str:
        """
        Generate a valid name for a backup rule based on the given `name`.

        Parameters:
            name (str): The desired name for the backup rule.

        Returns:
            str: A valid backup rule name adhering to AWS naming rules.

        Note:
            The generated backup rule name follows AWS naming rules,
            allowing alphanumeric characters, hyphens, and an optional hash prefix.
            It can't exceed 50 characters.

        Reference:
            https://docs.aws.amazon.com/aws-backup/latest/devguide/creating-a-backup-plan.html#rule-name
        """
        return re.sub(r"[^a-zA-Z0-9\-]+", "", f"{AwsUtils._getHashPrefix(name)}-{name}").rjust(1, "0")[:50]

    @staticmethod
    def backupSelectionName(name: str) -> str:
        """
        Generate a valid name for a backup selection based on the given `name`.

        Parameters:
            name (str): The desired name for the backup selection.

        Returns:
            str: A valid backup selection name adhering to AWS naming rules.

        Note:
            The generated backup selection name follows AWS naming rules,
            allowing alphanumeric characters, hyphens, underscores, dots, and an optional hash prefix.
            It can't exceed 50 characters.

        Reference:
            https://docs.aws.amazon.com/aws-backup/latest/devguide/API_BackupSelection.html#Backup-Type-BackupSelection-SelectionName
        """
        return re.sub(r"[^a-zA-Z0-9\-\_\.]+", "", f"{AwsUtils._getHashPrefix(name)}-{name}").rjust(1, "0")[:50]

    @staticmethod
    def mfaVirtualDeviceName(name: str) -> str:
        """
        Generate a valid name for an MFA (Multi-Factor Authentication) virtual device based on the given `name`.

        Parameters:
            name (str): The desired name for the MFA virtual device.

        Returns:
            str: A valid MFA virtual device name adhering to AWS naming rules.

        Note:
            The generated MFA virtual device name follows AWS naming rules,
            allowing alphanumeric characters and the characters '+ = , . @ - _'.
            It can't exceed 128 characters.

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iam-virtualmfadevice.html#cfn-iam-virtualmfadevice-virtualmfadevicename
        """
        return re.sub(r"[^\w+=,.@\-]+", "", name).rjust(1, "0")[:128]

    @staticmethod
    def cloud9EnvironmentName(name: str) -> str:
        """
        Generate a valid name for a Cloud9 environment based on the given `name`.

        Parameters:
            name (str): The desired name for the Cloud9 environment.

        Returns:
            str: A valid Cloud9 environment name adhering to AWS naming rules.

        Note:
            The generated Cloud9 environment name follows AWS naming rules,
            with a minimum length of 1 and a maximum length of 60 characters.

        Reference:
            https://docs.aws.amazon.com/cloud9/latest/APIReference/API_CreateEnvironmentEC2.html#API_CreateEnvironmentEC2_RequestSyntax
        """
        return name.rjust(1, "0")[:60]

    @staticmethod
    def _getHashPrefix(name: str) -> str:
        """
        Generate a hash prefix based on the given `name`.

        Parameters:
            name (str): The input string to generate the hash prefix.

        Returns:
            str: A hash prefix generated from the SHAKE-256 algorithm.

        Note:
            This method is used internally to create a hash prefix for various naming functions.
        """
        return hashlib.shake_256(name.encode("utf8")).hexdigest(4)[:4]

    @staticmethod
    def snsTopicName(name: str) -> str:
        """
        Generate a valid name for an Amazon SNS (Simple Notification Service) topic based on the given `name`.

        Parameters:
            name (str): The desired name for the SNS topic.

        Returns:
            str: A valid SNS topic name adhering to AWS naming rules.

        Note:
            The generated SNS topic name follows AWS naming rules,
            allowing only uppercase and lowercase ASCII letters, numbers, underscores, and hyphens.
            It must be between 1 and 256 characters long.

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-sns-topic.html#cfn-sns-topic-topicname
        """
        return re.sub(r"[^a-zA-Z0-9\-\_]+", "", name).rjust(1, "0")[:256]

    @staticmethod
    def cloudwatchAlarmName(name: str) -> str:
        """
        Generate a valid name for an Amazon CloudWatch alarm based on the given `name`.

        Parameters:
            name (str): The desired name for the CloudWatch alarm.

        Returns:
            str: A valid CloudWatch alarm name adhering to AWS naming rules.

        Note:
            The generated CloudWatch alarm name follows AWS naming rules,
            allowing only UTF-8 characters and avoiding ASCII control characters.
            It must be between 1 and 255 characters long.

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudwatch-alarm.html#cfn-cloudwatch-alarm-alarmname
        """
        return re.sub(r"[^a-zA-Z0-9\w+=,.@\-\_]+", "", name).rjust(1, "0")[:255]

    @staticmethod
    def cloudwatchDashboardName(name: str) -> str:
        """
        Generate a valid name for an Amazon CloudWatch Dashboard based on the given `name`.

        Parameters:
            name (str): The desired name for the CloudWatch Dashboard.

        Returns:
            str: A valid CloudWatch Dashboard name adhering to AWS naming rules.

        Note:
            The generated CloudWatch Dashboard name follows AWS naming rules,
            allowing only numbers, digits, underscore, and dash symbol.
            It must be between 1 and 255 characters long.

        Reference:
            https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudwatch-dashboard.html#aws-resource-cloudwatch-dashboard-properties
        """
        return re.sub(r"[^0-9A-Za-z-_]+", "", name).rjust(1, "0")[:255]
