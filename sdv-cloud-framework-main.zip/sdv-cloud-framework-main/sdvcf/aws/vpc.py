from ipaddress import IPv4Network
from typing import Dict, List, Optional

from cdktf import (
    Fn,
    ITerraformDependable,
    Op,
    TerraformLocal,
    TerraformResourceLifecycle,
    Token,
)
from cdktf_cdktf_provider_aws.data_aws_availability_zones import (
    DataAwsAvailabilityZones,
)
from cdktf_cdktf_provider_aws.ec2_tag import Ec2Tag
from cdktf_cdktf_provider_aws.eip import Eip
from cdktf_cdktf_provider_aws.internet_gateway import InternetGateway
from cdktf_cdktf_provider_aws.nat_gateway import NatGateway
from cdktf_cdktf_provider_aws.networkfirewall_firewall import (
    NetworkfirewallFirewall,
    NetworkfirewallFirewallSubnetMapping,
)
from cdktf_cdktf_provider_aws.networkfirewall_firewall_policy import (
    NetworkfirewallFirewallPolicy,
    NetworkfirewallFirewallPolicyFirewallPolicy,
)
from cdktf_cdktf_provider_aws.route import Route
from cdktf_cdktf_provider_aws.route_table import RouteTable, RouteTableRoute
from cdktf_cdktf_provider_aws.route_table_association import RouteTableAssociation
from cdktf_cdktf_provider_aws.subnet import Subnet
from cdktf_cdktf_provider_aws.vpc import Vpc

from sdvcf.interface import IPrivateCloud, PrivateCloudProps
from sdvcf.tags import Tags

from .enums import SubnetType
from .notifications import AWSNetworkNotifications
from .provider import AWSProvider
from .utils import AwsUtils


class AWSVpc(IPrivateCloud):
    """
    This class provides the creation and setup of AWS VPC.

    Inherits from IPrivateCloud.

    Attributes:
        provider (AWSProvider):
            The instance of the AWSProvider associated with this VPC.

    Private Attributes:
            _primary_subnet (Subnet):
                A reference to the primary subnet within the VPC.
            _secondary_subnet (Subnet):
                A reference to the secondary subnet within the VPC.
            _eks_primary_subnet (Subnet):
                A reference to the primary subnet used by EKS.
            _eks_secondary_subnet (Subnet):
                A reference to the secondary subnet used by EKS.
            _public_subnet (Subnet):
                A reference to the public subnet within the VPC.
            _ci_subnet (Subnet):
                A subnet dedicated to continuous integration processes.
            _nat_subnet (Subnet):
                A subnet designated for NAT gateway purposes.
            _alarms_configured (bool):
                A flag indicating whether alarms have been configured within the VPC.
            _vpc (Vpc):
                The core Vpc instance representing the AWS VPC.
            _nat_gw_eip (Eip):
                An Elastic IP (Eip) associated with the NAT gateway.
            _nat_gateway (NatGateway):
                A NatGateway instance.
            _internet_gateway (InternetGateway):
                An InternetGateway instance providing a gateway to the internet.
            _firewall (NetworkfirewallFirewall):
                An instance of NetworkfirewallFirewall representing the firewall within the VPC.
            _firewall_policy (NetworkfirewallFirewallPolicy):
                The associated NetworkfirewallFirewallPolicy for the firewall.
            _internet_connection (List[ITerraformDependable]):
                A list of dependencies related to the internet connection setup,
                such as Routes and RouteTableAssociations.
            _availability_zones (DataAwsAvailabilityZones):
                Data object representing the availability zones associated with the VPC.

    Properties:
        vpc:
            Lazily initialized Vpc.
            None until accessed
        availability_zones:
            Lazily initialized DataAwsAvailabilityZones.
            None until accessed.
        subnets:
            Lazily initialized dictionary of subnet types to subnet names.
            None until accessed.
        internet_gateway:
            Lazily initialized InternetGateway.
            None until accessed.
        nat_gw_eip:
            Lazily initialized Eip.
            None until accessed.
        nat_gateway:
            Lazily initialized NatGateway.
            None until accessed.
        firewall_policy:
            Lazily initialized NetworkfirewallFirewallPolicy.
            None until accessed.
        firewall:
            Lazily initialized NetworkfirewallFirewall.
            None until accessed.
        internet_connection:
            Lazily initialized list of the internet connection components.
            Empty until accessed.
    """

    provider: AWSProvider

    _primary_subnet: Optional[Subnet]
    _secondary_subnet: Optional[Subnet]
    _eks_primary_subnet: Optional[Subnet]
    _eks_secondary_subnet: Optional[Subnet]
    _public_subnet: Optional[Subnet]
    _ci_subnet: Optional[Subnet]
    _nat_subnet: Optional[Subnet]
    _alarms_configured: bool
    _availability_zones: Optional[DataAwsAvailabilityZones]
    _vpc: Optional[Vpc]
    _internet_gateway: Optional[InternetGateway]
    _nat_gw_eip: Optional[Eip]
    _nat_gateway: Optional[NatGateway]
    _firewall: Optional[NetworkfirewallFirewall]
    _firewall_policy: Optional[NetworkfirewallFirewallPolicy]
    _internet_connection: List[ITerraformDependable]

    def __init__(self, ns: str, props: PrivateCloudProps):
        super().__init__(AWSProvider.Instance(), ns, props)

        self._primary_subnet = None
        self._secondary_subnet = None
        self._eks_primary_subnet = None
        self._eks_secondary_subnet = None
        self._public_subnet = None
        self._ci_subnet = None
        self._nat_subnet = None
        self._alarms_configured = False
        self._availability_zones = None
        self._vpc = None
        self._internet_gateway = None
        self._nat_gw_eip = None
        self._nat_gateway = None
        self._firewall = None
        self._firewall_policy = None
        self._internet_connection = []

    @property
    def vpc(self) -> Vpc:
        """
        Creates and configures a Vpc.

        Returns:
            Vpc:
                An object representing the configured AWS VPC.
        """
        if self._vpc is None:
            self._vpc = Vpc(
                self,
                f"{self.name}-vpc",
                cidr_block=self.cidr,
                enable_dns_support=True,
                enable_dns_hostnames=True,
                tags=Tags(self, self.name).to_dict,
            )
        return self._vpc

    @property
    def availability_zones(self) -> DataAwsAvailabilityZones:
        """
        Creates and configures a DataAwsAvailabilityZones.

        Returns:
            DataAwsAvailabilityZones:
                An object representing the configured AWS Availability Zone.
        """
        if self._availability_zones is None:
            self._availability_zones = DataAwsAvailabilityZones(self, "available-az", state="available")
        return self._availability_zones

    @property
    def subnets(self) -> Dict[str, Subnet]:
        """
        Creates a dictionary of the internet connection components.

        Returns:
            Dict(str, Subnet):
                A dictionary mapping of subnet name and the Subnet object representing it.
        """
        cidr_network = IPv4Network(self.cidr)
        subnets_cidr_blocks = list(cidr_network.subnets(prefixlen_diff=4))
        subnets_cidr_used: List[IPv4Network] = []
        subnets_used_az: List[str] = []

        subnets_cidr_blocks.sort()

        def CreateSubnet(name: str, public: bool = False, tags: Dict[str, str] = {}) -> Subnet:
            name = f"{name}_subnet"

            subnet_cidr: Optional[IPv4Network] = None
            if f"{name}_cidr" in self.props.network:
                subnet_cidr = IPv4Network(self.props.network[f"{name}_cidr"])
            else:
                for cidr in subnets_cidr_blocks:
                    if not any([cidr.overlaps(used) for used in subnets_cidr_used]):
                        subnet_cidr = cidr
                        break

            if subnet_cidr is None:
                raise RuntimeError(f"Failed to deduct `{name}` CIDR")
            elif not subnet_cidr.subnet_of(cidr_network):
                raise RuntimeError(f"Subnet CIDR `{subnet_cidr}` is out of VPC CIDR `{cidr_network}`")
            elif subnet_cidr in subnets_cidr_blocks:
                subnets_cidr_blocks.remove(subnet_cidr)
            subnets_cidr_used.append(subnet_cidr)

            subnet_az = (
                self.props.network.get(f"{name}_az", None)
                or TerraformLocal(
                    self,
                    f"{name}_az_value",
                    Fn.try_(
                        [
                            Fn.element(
                                Fn.tolist(Fn.setsubtract(self.availability_zones.names, subnets_used_az)),
                                0,
                            ),
                            Fn.element(
                                self.availability_zones.names,
                                Token.as_number(
                                    Op.mod(len(subnets_used_az), Fn.length_of(self.availability_zones.names))
                                ),
                            ),
                        ]
                    ),
                ).as_string
            )
            subnets_used_az.append(str(subnet_az))

            return Subnet(
                self,
                name,
                vpc_id=self.vpc.id,
                cidr_block=str(subnet_cidr),
                availability_zone=subnet_az,
                map_public_ip_on_launch=public,
                tags=Tags(self, name, tags).to_dict,
            )

        if self._primary_subnet is None:
            self._primary_subnet = CreateSubnet(SubnetType.Primary.value)

        if self._secondary_subnet is None:
            self._secondary_subnet = CreateSubnet(SubnetType.Secondary.value)

        if self._eks_primary_subnet is None:
            self._eks_primary_subnet = CreateSubnet(
                SubnetType.EksPrimary.value, tags={"kubernetes.io/role/internal-elb": "1"}
            )

        if self._eks_secondary_subnet is None:
            self._eks_secondary_subnet = CreateSubnet(
                SubnetType.EksSecondary.value, tags={"kubernetes.io/role/internal-elb": "1"}
            )

        if self._nat_subnet is None:
            self._nat_subnet = CreateSubnet(SubnetType.NAT.value)

        if self._public_subnet is None:
            self._public_subnet = CreateSubnet(SubnetType.Public.value, public=True)

        if not self._alarms_configured:
            self._alarms_configured = True
            AWSNetworkNotifications.SetupAlarms(self)

        return {
            SubnetType.Primary: self._primary_subnet,
            SubnetType.Secondary: self._secondary_subnet,
            SubnetType.EksPrimary: self._eks_primary_subnet,
            SubnetType.EksSecondary: self._eks_secondary_subnet,
            SubnetType.NAT: self._nat_subnet,
            SubnetType.Public: self._public_subnet,
        }

    @property
    def internet_gateway(self) -> InternetGateway:
        """
        Creates and configures a InternetGateway.

        Returns:
            InternetGateway:
                An object representing the configured AWS Internet Gateway.
        """
        if self._internet_gateway is None:
            name = f"{self.name}-internet-gateway"
            self._internet_gateway = InternetGateway(self, name, vpc_id=self.vpc.id, tags=Tags(self, name).to_dict)
        return self._internet_gateway

    @property
    def nat_gw_eip(self) -> Eip:
        """
        Creates and configures a Eip.

        Returns:
            Eip:
                An object representing the configured AWS Elastic IP.
        """
        if self._nat_gw_eip is None:
            name = f"{self.name}-nat-gw-elastic-ip"
            self._nat_gw_eip = Eip(self, name, tags=Tags(self, name).to_dict)
        return self._nat_gw_eip

    @property
    def nat_gateway(self) -> NatGateway:
        """
        Creates and configures a NatGateway.

        Returns:
            NatGateway:
                An object representing the configured AWS NAT Gateway.
        """
        if self._nat_gateway is None:
            name = f"{self.name}-nat-gateway"
            self._nat_gateway = NatGateway(
                self,
                name,
                subnet_id=self.subnets[SubnetType.NAT].id,
                allocation_id=self.nat_gw_eip.allocation_id,
                tags=Tags(self, name).to_dict,
            )
        return self._nat_gateway

    @property
    def firewall_policy(self) -> NetworkfirewallFirewallPolicy:
        """
        Creates and configures a NetworkfirewallFirewallPolicy.

        Returns:
            NetworkfirewallFirewallPolicy:
                An object representing the configured AWS Network Firewall Policy.
        """
        if self._firewall_policy is None:
            rid = f"{self.name}-default-network-firewall-policy"
            name = AwsUtils.firewallName(rid)
            self._firewall_policy = NetworkfirewallFirewallPolicy(
                self,
                rid,
                name=name,
                firewall_policy=NetworkfirewallFirewallPolicyFirewallPolicy(
                    stateless_default_actions=["aws:pass"], stateless_fragment_default_actions=["aws:drop"]
                ),
                tags=Tags(self, name).to_dict,
                lifecycle=TerraformResourceLifecycle(ignore_changes=["firewall_policy"]),
            )
        return self._firewall_policy

    @property
    def firewall(self) -> NetworkfirewallFirewall:
        """
        Creates and configures a NetworkfirewallFirewall.

        Returns:
            NetworkfirewallFirewall:
                An object representing the configured AWS Network Firewall.
        """
        if self._firewall is None:
            rid = f"{self.name}-default-network-firewall"
            name = AwsUtils.firewallName(rid)
            self._firewall = NetworkfirewallFirewall(
                self,
                rid,
                name=name,
                firewall_policy_arn=self.firewall_policy.arn,
                vpc_id=self.vpc.id,
                subnet_mapping=[NetworkfirewallFirewallSubnetMapping(subnet_id=self.subnets[SubnetType.Public].id)],
                tags=Tags(self, name).to_dict,
                # TODO: Fix destroy timeout issue
                # https://github.com/hashicorp/terraform-provider-aws/pull/34918
            )

            # Add tags to automatically created VPC Endpoints
            for key, value in Tags(self, f"{name}-endpoint").to_dict.items():
                Ec2Tag(
                    self,
                    f"{self.name}-default-network-firewall-endpoint-tag-{key}",
                    key=key,
                    value=value,
                    resource_id=Fn.lookup(
                        Fn.one(
                            Fn.lookup(
                                Fn.one(
                                    Fn.lookup(Fn.one(self._firewall.firewall_status), "sync_states"),
                                ),
                                "attachment",
                            ),
                        ),
                        "endpoint_id",
                    ),
                )

        return self._firewall

    @property
    def internet_connection(self) -> List[ITerraformDependable]:
        """
        Creates and configures an internet connection.

        Returns:
            List(ITerraformDependable):
                A list of dependencies related to the internet connection setup,
                such as Routes and RouteTableAssociations.
        """
        if not self._internet_connection:
            nat_route_table_name = f"{self.name}-{SubnetType.NAT.value}-route-table"
            nat_route_table = RouteTable(
                self,
                nat_route_table_name,
                vpc_id=self.vpc.id,
                route=[
                    RouteTableRoute(
                        vpc_endpoint_id=Fn.lookup(
                            Fn.element(self.firewall.firewall_status.get(0).sync_states.get(0).attachment, 0),
                            "endpoint_id",
                        ),
                        cidr_block="0.0.0.0/0",
                    )
                ],
                tags=Tags(self, nat_route_table_name).to_dict,
            )
            nat_route_table_assoc = RouteTableAssociation(
                self,
                f"{nat_route_table_name}-association",
                route_table_id=nat_route_table.id,
                subnet_id=self.subnets[SubnetType.NAT].id,
            )

            public_route_table_name = f"{self.name}-{SubnetType.Public.value}-route-table"
            public_route_table = RouteTable(
                self,
                public_route_table_name,
                vpc_id=self.vpc.id,
                route=[RouteTableRoute(gateway_id=self.internet_gateway.id, cidr_block="0.0.0.0/0")],
                tags=Tags(self, public_route_table_name).to_dict,
            )
            public_route_table_assoc = RouteTableAssociation(
                self,
                f"{public_route_table_name}-association",
                route_table_id=public_route_table.id,
                subnet_id=self.subnets[SubnetType.Public].id,
            )

            igw_route_table_name = f"{self.name}-igw-route-table"
            igw_route_table = RouteTable(
                self,
                igw_route_table_name,
                vpc_id=self.vpc.id,
                route=[
                    RouteTableRoute(
                        vpc_endpoint_id=Fn.lookup(
                            Fn.element(self.firewall.firewall_status.get(0).sync_states.get(0).attachment, 0),
                            "endpoint_id",
                        ),
                        cidr_block=self.subnets[SubnetType.NAT].cidr_block,
                    )
                ],
                tags=Tags(self, igw_route_table_name).to_dict,
            )
            igw_route_table_assoc = RouteTableAssociation(
                self,
                f"{igw_route_table_name}-association",
                route_table_id=igw_route_table.id,
                gateway_id=self.internet_gateway.id,
            )

            nat_gateway_route = Route(
                self,
                f"{nat_route_table_name}-gw-route",
                route_table_id=self.vpc.main_route_table_id,
                nat_gateway_id=self.nat_gateway.id,
                destination_cidr_block="0.0.0.0/0",
            )

            self._internet_connection = [
                nat_route_table_assoc,
                public_route_table_assoc,
                igw_route_table_assoc,
                nat_gateway_route,
            ]

        return self._internet_connection
