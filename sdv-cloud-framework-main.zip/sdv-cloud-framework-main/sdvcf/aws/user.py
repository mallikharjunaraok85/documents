import os
from enum import Enum
from typing import Any, Dict, NamedTuple, Optional, Union

from cdktf import Fn, TerraformResourceLifecycle
from cdktf_cdktf_provider_aws.data_aws_iam_policy import DataAwsIamPolicy
from cdktf_cdktf_provider_aws.data_aws_iam_policy_document import (
    DataAwsIamPolicyDocument,
    DataAwsIamPolicyDocumentStatement,
    DataAwsIamPolicyDocumentStatementCondition,
    DataAwsIamPolicyDocumentStatementPrincipals,
)
from cdktf_cdktf_provider_aws.data_aws_iam_user import DataAwsIamUser
from cdktf_cdktf_provider_aws.data_aws_iam_user_ssh_key import DataAwsIamUserSshKey
from cdktf_cdktf_provider_aws.data_aws_key_pair import DataAwsKeyPair
from cdktf_cdktf_provider_aws.data_aws_secretsmanager_secret import (
    DataAwsSecretsmanagerSecret,
)
from cdktf_cdktf_provider_aws.data_aws_secretsmanager_secret_version import (
    DataAwsSecretsmanagerSecretVersion,
)
from cdktf_cdktf_provider_aws.efs_file_system import EfsFileSystem
from cdktf_cdktf_provider_aws.efs_file_system_policy import EfsFileSystemPolicy
from cdktf_cdktf_provider_aws.efs_mount_target import EfsMountTarget
from cdktf_cdktf_provider_aws.iam_policy import IamPolicy
from cdktf_cdktf_provider_aws.iam_user import IamUser
from cdktf_cdktf_provider_aws.iam_user_login_profile import IamUserLoginProfile
from cdktf_cdktf_provider_aws.iam_user_policy_attachment import IamUserPolicyAttachment
from cdktf_cdktf_provider_aws.iam_user_ssh_key import IamUserSshKey
from cdktf_cdktf_provider_aws.key_pair import KeyPair
from cdktf_cdktf_provider_aws.secretsmanager_secret import SecretsmanagerSecret
from cdktf_cdktf_provider_aws.secretsmanager_secret_policy import (
    SecretsmanagerSecretPolicy,
)
from cdktf_cdktf_provider_aws.secretsmanager_secret_version import (
    SecretsmanagerSecretVersion,
)
from cdktf_cdktf_provider_aws.security_group import SecurityGroup, SecurityGroupIngress
from cdktf_cdktf_provider_tls.private_key import PrivateKey

from sdvcf.interface import IPrivateCloud, IUser, UserProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .enums import SecurityRuleProtocol, SubnetType
from .provider import AWSProvider
from .vpc import AWSVpc


class SSHKeyType(NamedTuple("SSHKey", [("algorithm", str), ("key_size", int)]), Enum):
    """
    Enumeration of the different types of VPN connection protocols supported by AWS.

    Attributes:
        IPSec1:
            Represents the 'ipsec.1' connection type.

    Reference:
        https://registry.terraform.io/providers/hashicorp/tls/latest/docs/resources/private_key#algorithm
    """

    RSA4096 = ("RSA", 4096)


class AWSUserProps(UserProps):
    """
    AWSUserProps is a configuration class that extends UserProps, adding AWS-specific properties.

    Attributes:
        ssh_key_type (SSHKeyType):
            Specifies the type of the SSH key.
            This can be either specified directly or
            inferred from an environment variable with a default value.
        efs_subnet_type (SubnetType):
            Specifies the type of the EFS Subnet.
            This can be either specified directly or
            inferred from an environment variable with a default value.
    """

    ssh_key_type: SSHKeyType
    efs_subnet_type: SubnetType

    def __init__(
        self, ssh_key_type: Optional[SSHKeyType] = None, efs_subnet_type: Optional[SubnetType] = None, **kwargs: Any
    ) -> None:
        super().__init__(**kwargs)

        self.ssh_key_type = ssh_key_type or SSHKeyType[os.getenv("AWS_SSH_KEY_TYPE", SSHKeyType.RSA4096.name)]
        self.efs_subnet_type = (
            efs_subnet_type or SubnetType[os.getenv("AWS_EFS_DEFAULT_SUBNET_TYPE", SubnetType.Primary.name)]
        )


# Wrapper class to align DataAwsIamUser and IamUser interfaces
class WrapperDataAwsIamUser(DataAwsIamUser):
    """
    This class is a wrapper which aligns the interfaces of DataAwsIamUser and
    IamUser by providing a unified property interface.

    Properties:
        name (str):
            Gets the IAM user's name.
    """

    @property
    def name(self) -> str:
        return self.user_name


class AWSUser(IUser):
    """
    Class that contains resources for AWS User.

    This class provides the creation and setup of a User in AWS.

    Inherits from IUser.

    Attributes:
        cloud (AWSVpc):
            The instance of the AWSVpc associated with this User.
        provider (AWSProvider):
            The instance of the AWSProvider associated with this User.
        props (AWSUserProps):
            The instance of the AWSUserProps associated with this User.

    Private Attributes:
        _user (Union[IamUser, WrapperDataAwsIamUser]):
            Lazily initialized AWS User representation.
            None until accessed.
        _tls_key (PrivateKey):
            Lazily initialized AWS Private Key representation.
            None until accessed.
        _key_pair (KeyPair):
            Lazily initialized AWS Key Pair representation.
            None until accessed.
        _ssh_key (IamUserSshKey):
            Lazily initialized AWS IAM User SSH Key representation.
            None until accessed.
        _efs_file_system (EfsFileSystem):
            Lazily initialized AWS EFS File System representation.
            None until accessed.

    Methods:
        GetSSHPublicKey:
            Get SSH Public Key.
        GetUniqueID:
            Get Unique ID (ARN).

    Properties:
        user:
            Returns either an IamUser or a wrapper around DataAwsIamUser instance,
            initializing it if it has not been already.
        tls_key:
            Returns the PrivateKey instance,
            initializing it if it has not been already.
        key_pair:
            Returns the KeyPair instance,
            initializing it if it has not been already.
        ssh_key:
            Returns the IamUserSshKey instance,
            initializing it if it has not been already.
        efs_file_system:
            Returns the EfsFileSystem instance,
            initializing it if it has not been already.
    """

    cloud: AWSVpc
    provider: AWSProvider
    props: AWSUserProps

    _user: Optional[Union[IamUser, WrapperDataAwsIamUser]]
    _tls_key: Optional[PrivateKey]
    _key_pair: Optional[Union[KeyPair, DataAwsKeyPair]]
    _ssh_key: Optional[Union[IamUserSshKey, DataAwsIamUserSshKey]]
    _efs_file_system: Optional[EfsFileSystem]

    def __init__(self, cloud: IPrivateCloud, ns: str, props: AWSUserProps, tags: Dict[str, str] = {}):
        super().__init__(cloud.provider, ns, props)

        assert isinstance(cloud, AWSVpc)
        self.cloud = cloud
        self.props = props

        self._tags = tags

        self._user = None
        self._tls_key = None
        self._key_pair = None
        self._ssh_key = None
        self._access_key = None
        self._efs_file_system = None

        self.user
        self.ssh_key

    def GetSSHPublicKey(self) -> str:
        """
        Get SSH Public Key.

        Parameters:
            None:
                This method does not have any parameters.

        Returns:
            str:
                A string representing SSH Public Key.
        """
        return self.ssh_key.public_key

    def GetUniqueID(self) -> str:
        """
        Get Unique ID (ARN).

        Parameters:
            None:
                This method does not have any parameters.

        Returns:
            str:
                A string representing UniqueID (ARN).
        """
        return self.user.arn

    @property
    def user(self) -> Union[IamUser, WrapperDataAwsIamUser]:
        """
        Creates and configures an AWS IAM User.

        Returns:
            Union[IamUser, WrapperDataAwsIamUser]:
                An object representing the configured AWS IAM User,
                either as a direct IamUser or a wrapper around DataAwsIamUser.
        """
        if self._user is None:
            self._user = (
                WrapperDataAwsIamUser(self, f"{self.name}-iam-user-ds", user_name=self.name)
                if self.props.external
                else IamUser(
                    self,
                    f"{self.name}-iam-user",
                    name=self.name,
                    force_destroy=True,
                    path=f"/{self.provider.name}/",
                    tags=Tags(self, self.name, self._tags).to_dict,
                )
            )

            # Setup initial permissions and boundaries only for managed users
            if not self.props.external:
                aws_iam_policy_document = DataAwsIamPolicyDocument(
                    self,
                    f"{self.name}-aws-iam-policy-document",
                    statement=[
                        # TODO: Please make me more secure
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=["s3:GetObject"],
                            resources=["*"],
                        ),
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=[
                                "iam:GetAccountPasswordPolicy",
                                "iam:GetAccountSummary",
                            ],
                            resources=["*"],
                        ),
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=[
                                "iam:ChangePassword",
                                "iam:ListSSHPublicKeys",
                                "iam:ListUserTags",
                                "iam:GetSSHPublicKey",
                                "iam:ListAccessKeys",
                                "iam:GetAccessKeyLastUsed",
                                "iam:CreateAccessKey",
                                "iam:DeleteAccessKey",
                                "iam:UpdateAccessKey",
                            ],
                            resources=[self._user.arn],
                        ),
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=[
                                "iam:CreateVirtualMFADevice",
                                "iam:DeleteVirtualMFADevice",
                                "iam:ListVirtualMFADevices",
                            ],
                            resources=[f"arn:aws:iam::{self.provider.caller_identity.account_id}:mfa/*"],
                        ),
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=["iam:DeactivateMFADevice"],
                            resources=[self._user.arn],
                            condition=[
                                DataAwsIamPolicyDocumentStatementCondition(
                                    test="Bool",
                                    values=["true"],
                                    variable="aws:MultiFactorAuthPresent",
                                ),
                            ],
                        ),
                        # Allow user to manage own MFA
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=[
                                "iam:EnableMFADevice",
                                "iam:ResyncMFADevice",
                                "iam:ListMFADevices",
                            ],
                            resources=[self._user.arn],
                        ),
                        # TODO[SDV-122]: Move to Virtual Workbench assignment
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=[
                                "ec2:DescribeInstances",
                                "ec2:DescribeInstanceStatus",
                            ],
                            resources=["*"],
                        ),
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=["ec2:StartInstances"],
                            resources=[f"arn:aws:ec2:*:{self.provider.caller_identity.account_id}:instance/*"],
                            condition=[
                                DataAwsIamPolicyDocumentStatementCondition(
                                    test="StringLike",
                                    values=[f"{self._user.name}-*"],
                                    variable="ec2:ResourceTag/ComponentName",
                                ),
                                DataAwsIamPolicyDocumentStatementCondition(
                                    test="Bool",
                                    values=["true"],
                                    variable="aws:MultiFactorAuthPresent",
                                ),
                            ],
                        ),
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            actions=[
                                "ecr:DescribeImages",
                                "ecr:ListImages",
                                "ecr:BatchCheckLayerAvailability",
                                "ecr:BatchGetImage",
                                "ecr:BatchGetRepositoryScanningConfiguration",
                                "ecr:GetAuthorizationToken",
                                "ecr:GetDownloadUrlForLayer",
                                "ecr:GetLifecyclePolicyPreview",
                                "ecr:GetRegistryPolicy",
                            ],
                            resources=["*"],
                        ),
                    ],
                )

                aws_iam_policy = IamPolicy(
                    self,
                    f"{self.name}-iam-policy",
                    name=f"{self._user.name}-user-policy",
                    path=f"/{self.name}/",
                    policy=aws_iam_policy_document.json,
                    tags=Tags(self, f"{self._user.name}-user-policy", self._tags).to_dict,
                )

                IamUserPolicyAttachment(
                    self,
                    f"{self.name}-iam-user-policy-attachment",
                    user=self._user.name,
                    policy_arn=aws_iam_policy.arn,
                )

                # TODO: Forbid access if no MFA configured
                member_policy_rid = f"{self.name}-cloud9-environment-member-policy"
                cloud9_env_member_policy = DataAwsIamPolicy(self, member_policy_rid, name="AWSCloud9EnvironmentMember")
                IamUserPolicyAttachment(
                    self,
                    f"{member_policy_rid}-attachment",
                    policy_arn=cloud9_env_member_policy.arn,
                    user=self._user.name,
                )

                user_login_profile = IamUserLoginProfile(
                    self,
                    f"{self.name}-iam-user-login-profile",
                    user=self._user.name,
                    password_reset_required=True,
                    lifecycle=TerraformResourceLifecycle(ignore_changes=["password_reset_required"]),
                )
                Output(
                    self,
                    "initial_user_password",
                    value=Fn.nonsensitive(user_login_profile.password),
                    resource_id=self._user.arn,
                    user_name=self._user.name,
                )
        return self._user

    @property
    def tls_key(self) -> PrivateKey:
        """
        Creates and configures a AWS Private Key.

        Returns:
            PrivateKey:
                An object representing the configured AWS Private Key.
        """
        if self._tls_key is None:
            if self.props.external:
                raise RuntimeError("TLS Key can not be referenced for external users")
            self._tls_key = PrivateKey(
                self,
                f"{self.name}-tls-key",
                algorithm=self.props.ssh_key_type.algorithm,
                rsa_bits=self.props.ssh_key_type.key_size,
            )
        return self._tls_key

    @property
    def key_pair(self) -> Union[KeyPair, DataAwsKeyPair]:
        """
        Creates and configures a AWS Key Pair.

        Returns:
            KeyPair:
                An object representing the configured AWS Key Pair.
        """
        if self._key_pair is None:
            key_pair_name = f"{self.name}-primary-ssh-key"
            key_pair_rid = f"{self.name}-key-pair"
            self._key_pair = (
                DataAwsKeyPair(
                    self,
                    f"{key_pair_rid}-data",
                    include_public_key=True,
                    key_name=key_pair_name,
                )
                if self.props.external
                else KeyPair(
                    self,
                    key_pair_rid,
                    key_name=key_pair_name,
                    public_key=self.tls_key.public_key_openssh,
                    tags=Tags(self, f"{self.user.name}-key-pair", self._tags).to_dict,
                )
            )

            secretsmanager_secret_rid = f"{key_pair_name}-secret"
            ssh_key_secretsmanager_secret = (
                DataAwsSecretsmanagerSecret(self, f"{secretsmanager_secret_rid}-data", name=key_pair_name)
                if self.props.external
                else SecretsmanagerSecret(
                    self,
                    secretsmanager_secret_rid,
                    name=key_pair_name,
                    recovery_window_in_days=0,
                    tags=Tags(self, f"{self.user.name}-primary-ssh-key", self._tags).to_dict,
                )
            )

            if not self.props.external:
                secret_policy_document = DataAwsIamPolicyDocument(
                    self,
                    f"{secretsmanager_secret_rid}-policy-document",
                    statement=[
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            principals=[
                                DataAwsIamPolicyDocumentStatementPrincipals(
                                    type="AWS", identifiers=[self.GetUniqueID()]
                                )
                            ],
                            actions=[
                                "secretsmanager:GetSecretValue",
                                "secretsmanager:DescribeSecret",
                            ],
                            resources=[ssh_key_secretsmanager_secret.arn],
                        ),
                    ],
                )
                SecretsmanagerSecretPolicy(
                    self,
                    f"{secretsmanager_secret_rid}-policy",
                    policy=secret_policy_document.json,
                    secret_arn=ssh_key_secretsmanager_secret.arn,
                )
                SecretsmanagerSecretVersion(
                    self,
                    f"{secretsmanager_secret_rid}-version",
                    secret_id=ssh_key_secretsmanager_secret.id,
                    secret_string=self.tls_key.private_key_openssh,
                )

            Output(
                self,
                "primary_ssh_key_secretsmanager_id",
                value=ssh_key_secretsmanager_secret.id,
                resource_id=self._key_pair.arn,
                user_name=self.user.name,
            )
        return self._key_pair

    @property
    def ssh_key(self) -> Union[IamUserSshKey, DataAwsIamUserSshKey]:
        """
        Creates and configures a AWS IAM User SSH Key.

        Returns:
            IamUserSshKey:
                An object representing the configured AWS IAM User SSH Key.
        """
        if self._ssh_key is None:
            secretsmanager_secret_rid = f"{self.name}-primary-ssh-key-id-secret"
            ssh_key_id_secretsmanager_secret = (
                DataAwsSecretsmanagerSecret(self, f"{secretsmanager_secret_rid}-data", name=secretsmanager_secret_rid)
                if self.props.external
                else SecretsmanagerSecret(
                    self,
                    secretsmanager_secret_rid,
                    name=secretsmanager_secret_rid,
                    recovery_window_in_days=0,
                    tags=Tags(self, f"{self.user.name}-primary-ssh-key-id", self._tags).to_dict,
                )
            )

            ssh_key_rid = f"{self.name}-iam-primary-ssh-key"
            self._ssh_key = (
                DataAwsIamUserSshKey(
                    self,
                    f"{ssh_key_rid}-data",
                    encoding="SSH",
                    ssh_public_key_id=DataAwsSecretsmanagerSecretVersion(
                        self,
                        f"{secretsmanager_secret_rid}-version",
                        secret_id=ssh_key_id_secretsmanager_secret.id,
                    ).secret_string,
                    username=self.user.name,
                )
                if self.props.external
                else IamUserSshKey(
                    self,
                    ssh_key_rid,
                    username=self.user.name,
                    encoding="SSH",
                    public_key=self.key_pair.public_key,
                )
            )

            if not self.props.external:
                secret_policy_document = DataAwsIamPolicyDocument(
                    self,
                    f"{secretsmanager_secret_rid}-policy-document",
                    statement=[
                        DataAwsIamPolicyDocumentStatement(
                            effect="Allow",
                            principals=[
                                DataAwsIamPolicyDocumentStatementPrincipals(
                                    type="AWS", identifiers=[self.provider.caller_identity.arn]
                                )
                            ],
                            actions=[
                                "secretsmanager:GetSecretValue",
                                "secretsmanager:DescribeSecret",
                            ],
                            resources=[ssh_key_id_secretsmanager_secret.arn],
                        ),
                    ],
                )
                SecretsmanagerSecretPolicy(
                    self,
                    f"{secretsmanager_secret_rid}-policy",
                    policy=secret_policy_document.json,
                    secret_arn=ssh_key_id_secretsmanager_secret.arn,
                )
                SecretsmanagerSecretVersion(
                    self,
                    f"{secretsmanager_secret_rid}-version",
                    secret_id=ssh_key_id_secretsmanager_secret.id,
                    secret_string=self._ssh_key.ssh_public_key_id,
                )
        return self._ssh_key

    @property
    def efs_file_system(self) -> EfsFileSystem:
        """
        Creates and configures a AWS IAM User SSH Key.

        Returns:
            IamUserSshKey:
                An object representing the configured AWS IAM User SSH Key.
        """
        if self._efs_file_system is None:
            NAME_PREFIX = f"{self.provider.name}-{self.name}"
            name = f"{NAME_PREFIX}-efs-file-system"

            self._efs_file_system = EfsFileSystem(
                self,
                name,
                encrypted=True,
                tags=Tags(self, name).to_dict,
            )

            policy_doc = DataAwsIamPolicyDocument(
                self,
                f"{name}-pd",
                statement=[
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        principals=[DataAwsIamPolicyDocumentStatementPrincipals(type="AWS", identifiers=["*"])],
                        actions=["elasticfilesystem:ClientWrite"],
                        resources=[self.efs_file_system.arn],
                        condition=[
                            DataAwsIamPolicyDocumentStatementCondition(
                                test="Bool", variable="elasticfilesystem:AccessedViaMountTarget", values=["true"]
                            )
                        ],
                    ),
                    DataAwsIamPolicyDocumentStatement(
                        effect="Allow",
                        principals=[
                            DataAwsIamPolicyDocumentStatementPrincipals(type="AWS", identifiers=[self.GetUniqueID()])
                        ],
                        actions=[
                            "elasticfilesystem:ClientMount",
                            "elasticfilesystem:ClientWrite",
                            "elasticfilesystem:ClientRootAccess",
                        ],
                        resources=[self.efs_file_system.arn],
                    ),
                ],
            )

            EfsFileSystemPolicy(
                self,
                f"{name}-policy",
                file_system_id=self.efs_file_system.id,
                bypass_policy_lockout_safety_check=True,
                policy=policy_doc.json,
            )

            EFS_MT_DEFAULT_PORT = 2049
            efs_security_group_name = f"{name}-sg"
            security_group = SecurityGroup(
                self,
                efs_security_group_name,
                vpc_id=self.cloud.vpc.id,
                ingress=[
                    SecurityGroupIngress(
                        description="EFS mount target",
                        from_port=EFS_MT_DEFAULT_PORT,
                        to_port=EFS_MT_DEFAULT_PORT,
                        protocol=SecurityRuleProtocol.TCP.value,
                        cidr_blocks=[self.cloud.cidr],
                    )
                ],
                tags=Tags(self, efs_security_group_name).to_dict,
            )

            EfsMountTarget(
                self,
                f"{name}-mount-target",
                file_system_id=self._efs_file_system.id,
                subnet_id=self.cloud.subnets[self.props.efs_subnet_type.value].id,
                security_groups=[security_group.id],
            )
            self.provider.cloudwatch_dashboard.EnableWidget(self.provider.cloudwatch_dashboard.WigdetTypes.SharedFSSize)
        return self._efs_file_system
