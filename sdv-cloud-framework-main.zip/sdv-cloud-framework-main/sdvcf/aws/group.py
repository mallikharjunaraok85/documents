from typing import Optional

from cdktf_cdktf_provider_aws.iam_group import IamGroup
from cdktf_cdktf_provider_aws.iam_user_group_membership import IamUserGroupMembership

from sdvcf.interface import IUser, IUserGroup

from .provider import AWSProvider
from .user import AWSUser


class AwsUserGroup(IUserGroup):
    """
    Represents an AWS IAM User Group within the AWS provider context.

    It provides functionality to manage AWS IAM user groups, including adding users to the group and retrieving
    the group's unique identifier. AWS IAM does not support nested groups, so the AddGroup method is not implemented.

    Attributes:
        provider (AWSProvider):
            The instance of the AWSProvider associated with this user group.

    Private Attributes:
        _group (IamGroup):
            Lazily initialized AWS IAM Group representation. None until accessed.

    Methods:
        GetUniqueID:
            Retrieve the unique Amazon Resource Name (ARN) of the group.
        _AddUser:
            Internal method to add an AWSUser to the IAM group.
        AddGroup:
            Not implemented, as AWS IAM does not support nested groups.

    Properties:
        group:
            Returns the IamGroup instance, initializing it if it has not been already.
    """

    provider: AWSProvider

    _group: Optional[IamGroup]

    def __init__(self, ns: str):
        super().__init__(AWSProvider.Instance(), ns)

        self._group = None

    def GetUniqueID(self) -> str:
        """
        Gets the unique identifier of the AWS IAM User Group.

        The unique identifier is the Amazon Resource Name (ARN) for this IAM User Group.

        Returns:
            str:
                The ARN of the IAM User Group.
        """
        return self.group.arn

    def _AddUser(self, user: IUser) -> None:
        """
        Adds an AWSUser to the IAM group.

        This is an internal method that asserts the user is an instance of AWSUser and creates a membership
        relationship between the user and the group.

        Args:
            user (IUser):
                The user to add to the group. Must be an instance of AWSUser.

        Raises:
            AssertionError:
                If 'user' is not an instance of AWSUser.
        """
        assert isinstance(user, AWSUser)
        IamUserGroupMembership(
            self, f"{self.name}-{user.name}-group-membership", user=user.user.name, groups=[self.group.name]
        )

    def AddGroup(self, group: IUserGroup) -> None:
        """
        Attempt to add a nested user group to this group.

        This method raises NotImplementedError because AWS IAM does not support the concept of nested groups.

        Args:
            group (IUserGroup):
                The user group to attempt to add.

        Raises:
            NotImplementedError:
                Always, because the operation is not supported.
        """
        raise NotImplementedError("AWS IAM Configuration Management does not allow nested groups")

    @property
    def group(self) -> IamGroup:
        """
        Lazily initializes and returns the associated AWS IAM Group.

        If the IAM Group has not been created, it initializes the group with the provided name and path,
        and then returns the initialized group.

        Returns:
            IamGroup:
                The IAM Group associated with this AwsUserGroup.
        """
        if self._group is None:
            self._group = IamGroup(self, f"{self.name}-group", name=self.name, path=f"/{self.provider.name}/")
        return self._group
