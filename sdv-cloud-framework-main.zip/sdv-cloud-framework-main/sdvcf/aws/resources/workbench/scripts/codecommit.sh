#!/bin/bash

USERNAME=$(awk -F: '($3>=1000)&&($1!="nobody"){print $1}' /etc/passwd | head -n1)

# Configure CodeCommit git plugins
su $USERNAME -c 'pip install -U git-remote-codecommit'
su $USERNAME -c 'git config --global --add protocol.codecommit.allow always'
