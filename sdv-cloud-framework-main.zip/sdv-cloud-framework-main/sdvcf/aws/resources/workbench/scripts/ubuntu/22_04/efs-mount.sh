#!/bin/bash
if [ ! -z "${efs_id}" ] && ! grep -qx '${efs_id}' /etc/fstab; then
    # Cleanup previus Shared Folder mount point if efs id is changed
    sed -i.bak "/\/home\/${user}\/Shared-Folder efs/d" /etc/fstab

    # Install required packages
    apt-get update && apt-get -yq install   \
            nfs-common                      \
            git                             \
            make                            \
            binutils                        \
            stunnel4
    test -d /tmp/efs-utils/ || git clone https://github.com/aws/efs-utils /tmp/efs-utils
    cd /tmp/efs-utils && git pull
    ./build-deb.sh && apt-get -yq install ./build/amazon-efs-utils*.deb

    # Create automated mount point
    mkdir -p /home/${user}/Shared-Folder
    echo "${efs_id}:/ /home/${user}/Shared-Folder efs rw,_netdev,tls,iam 0 0" >> /etc/fstab
    mount -a
    chown ${user}:${user} /home/${user}/Shared-Folder
fi
