#!/bin/bash

exec > >(tee /var/log/sdvcf-user-data.log | logger -t sdvcf-user-data ) 2>&1

# Install Development utilities
export DEBIAN_FRONTEND=noninteractive
apt-get update && apt-get upgrade -yq \
    && apt-get install -yq \
        curl \
        unzip \
        wget \
        git \
        gcc \
        ninja-build \
        cmake \
        python3 \
        python3-pip \
        python3-pyinotify \
        python3-psutil \
        linux-firmware \
        ubuntu-drivers-common

# Install AWS CLI v2
AWS_CLIV2_BIN_DIR="/usr/local/bin"
AWS_CLIV2_BIN_PATH="$AWS_CLIV2_BIN_DIR/aws"
if ! [ -f "$AWS_CLIV2_BIN_PATH" ]; then
    AWS_CLI_ZIP="/tmp/awscliv2.zip"
    curl "https://awscli.amazonaws.com/awscli-exe-linux-`uname -p`.zip" -o $AWS_CLI_ZIP
    unzip -qo $AWS_CLI_ZIP -d /tmp

    AWS_CLIV2_INSTALL_DIR="/usr/local/aws-cli"
    /tmp/aws/install --bin-dir $AWS_CLIV2_BIN_DIR --install-dir $AWS_CLIV2_INSTALL_DIR --update
    ln -sf "$AWS_CLIV2_INSTALL_DIR/v2/current/bin/aws" $AWS_CLIV2_BIN_PATH
fi
