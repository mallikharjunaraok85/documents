if [[ ! -f "/etc/apt/sources.list.d/${name}.list" ]]; then
    echo "deb [trusted=yes] ${url} ${release} ${components}" \
        | tee -a /etc/apt/sources.list.d/${name}.list
fi

apt update
