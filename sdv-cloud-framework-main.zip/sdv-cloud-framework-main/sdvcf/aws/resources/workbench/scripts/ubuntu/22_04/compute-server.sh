#!/bin/bash

# Reset default user
if [ -d "/home/ubuntu" ]; then
    usermod -l ${user} ubuntu
    groupmod -n ${user} ubuntu
    usermod -d /home/${user} -m ${user}

    # Set default user password
    echo ${user}:${default_password} | chpasswd
fi

set_setting() {
    sed -i "s/^$1=.*$/$1=$2/" $3
}

# Download and install Autopoweroff
AUTOPOWEROFF_VERSION="4.1.1"
if [[ "$(dpkg-query --showformat='$${Version}' --show autopoweroff)" != $AUTOPOWEROFF_VERSION ]]; then
    apt-get remove autopoweroff

    wget https://github.com/deragon/autopoweroff/releases/download/$${AUTOPOWEROFF_VERSION}/autopoweroff_$${AUTOPOWEROFF_VERSION}_all.deb \
        -O /tmp/autopoweroff.deb

    dpkg --force-confdef -i /tmp/autopoweroff.deb

    # Configure Autopoweroff
    set_setting "StartHour" "0" "/etc/autopoweroff/autopoweroff.conf"
    set_setting "EndHour" "0" "/etc/autopoweroff/autopoweroff.conf"
    set_setting "StartupDelay" "0" "/etc/autopoweroff/autopoweroff.conf"
    set_setting "IdleTime" "${auto_stop_minutes}" "/etc/autopoweroff/autopoweroff.conf"
    set_setting "Action" "Other" "/etc/autopoweroff/autopoweroff.conf"
    set_setting "ActionCommand" "shutdown -h now" "/etc/autopoweroff/autopoweroff.conf"

    systemctl enable autopoweroff.service
    systemctl start autopoweroff.service
fi

# Set High Priority for SSH daemon
mkdir -p /etc/systemd/system/sshd.service.d/
echo \
"[Service]
Nice=-15" > /etc/systemd/system/sshd.service.d/nice_high.conf
systemctl daemon-reload
systemctl restart ssh sshd
