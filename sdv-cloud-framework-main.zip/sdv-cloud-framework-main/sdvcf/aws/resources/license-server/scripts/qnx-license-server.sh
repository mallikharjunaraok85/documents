#!/bin/bash

export DEBIAN_FRONTEND=noninteractive
apt-get update && apt-get upgrade -yq \
    && apt-get install -yq \
        unzip   \
        awscli  \
        curl    \
        lsb

license=$(aws secretsmanager get-secret-value --region ${region} --secret-id ${license_secret_id} --query SecretString --output text)
# Set default password
echo ${user}:$license | chpasswd

mkdir -p /usr/tmp

sudo -u ${user} -i <<'EOF'

aws configure set region ${region}

# Obtain license credentials from the AWS Secrets Manager
user_email=$(aws secretsmanager get-secret-value --secret-id ${user_email_secret_id} --query SecretString --output text)
user_password=$(aws secretsmanager get-secret-value --secret-id ${user_password_secret_id} --query SecretString --output text)
license=$(aws secretsmanager get-secret-value --secret-id ${license_secret_id} --query SecretString --output text)

# Install QNX Software Center
QNX_SWC_HD="$HOME/qnx"
QNX_SWC_CLI="$QNX_SWC_HD/qnxsoftwarecenter/qnxsoftwarecenter_clt"
if ! test -f "$QNX_SWC_CLI"; then
    mkdir -p $HOME/.qnx
    curl --cookie-jar $HOME/.qnx/myqnxcookies.auth --form "userlogin=$user_email"           \
        --form "password=$user_password" -X POST https://www.qnx.com/account/login.html \
        > /tmp/login_response.html

    curl -L --cookie $HOME/.qnx/myqnxcookies.auth   \
        https://www.qnx.com/download/download/68433/qnx-setup-latest-linux.run > /tmp/qnx-setup-linux.run

    chmod a+x /tmp/qnx-setup-linux.run
    /tmp/qnx-setup-linux.run force-override disable-auto-start agree-to-license-terms "$QNX_SWC_HD"
fi

# Update QNX Software Center
"$QNX_SWC_CLI" -myqnx.user $user_email -myqnx.password $user_password -mirror
"$QNX_SWC_CLI" -myqnx.user $user_email -myqnx.password $user_password -selfUpdate

# Insert Latest Licence Key
"$QNX_SWC_CLI" -myqnx.user $user_email -myqnx.password $user_password  \
    -syncLicenseKeys -addLicenseKey $license -listLicenseKeys

# Install Flexera Server
QNX_FLEXLM_HD="$HOME/flexserver"
if ! find "$QNX_FLEXLM_HD" -mindepth 1 -maxdepth 1 2>/dev/null | read; then
    "$QNX_SWC_CLI" -myqnx.user $user_email -myqnx.password $user_password   \
        -cleanInstall -installBaseline com.qnx.flexera.server -destination $QNX_FLEXLM_HD
fi

"$QNX_SWC_CLI" -myqnx.user $user_email -myqnx.password $user_password -updateAll

echo "Host ID: $($QNX_FLEXLM_HD/host/linux/x86_64/usr/bin/lmutil lmhostid | grep -o '"[0-9a-zA-Z]*"' | sed 's/"//g')" \
    > $QNX_FLEXLM_HD/host_info.txt
echo "Hostname (FQDN): $(hostname --fqdn)" >> $QNX_FLEXLM_HD/host_info.txt

QNX_LICENSE_FILE="$QNX_FLEXLM_HD/license.txt"
echo "Path to License Key File provided by BlackBerry QNX: $QNX_LICENSE_FILE" >> $QNX_FLEXLM_HD/host_info.txt

$QNX_FLEXLM_HD/host/linux/x86_64/usr/bin/lmgrd -l +$QNX_FLEXLM_HD/logs.txt -c $QNX_LICENSE_FILE

EOF
