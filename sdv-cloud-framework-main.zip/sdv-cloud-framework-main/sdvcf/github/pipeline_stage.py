from typing import TYPE_CHECKING

from sdvcf.aws.utils import AwsUtils

if TYPE_CHECKING:
    from .repository import GitHubRepository

from importlib.resources import as_file, files

from cdktf import Fn, TerraformResourceLifecycle
from cdktf_cdktf_provider_github.repository_file import RepositoryFile

from sdvcf.interface import IPipelineStage, IStageRunner, PipelineStageProps


class GitHubPipelineStage(IPipelineStage):
    """
    Represents a stage in a GitHub pipeline.

    Args:
        repo (GitHubRepository): The GitHub repository associated with the stage.
        ns (str): The namespace of the stage.
        runner (IStageRunner): The runner for the stage.
        props (PipelineStageProps): The properties of the stage.

    Attributes:
        repo (GitHubRepository): The GitHub repository associated with the stage.
        runner (IStageRunner): The runner for the stage.
    """

    repo: "GitHubRepository"

    def __init__(self, repo: "GitHubRepository", ns: str, runner: IStageRunner, props: PipelineStageProps):
        super().__init__(repo, ns, props)

        self.runner = runner

        if self.repo.dev_branch is not None:
            with as_file(files("sdvcf.github.resources").joinpath("workflow_templates/stage.yaml.tmpl")) as stage_file:
                RepositoryFile(
                    self,
                    f"{self.name}-{props.name.value}-file",
                    repository=self.repo.repository.name,
                    file=f".github/workflows/{props.name.value}.yaml",
                    branch=self.repo.dev_branch.branch,
                    content=Fn.templatefile(
                        str(stage_file),
                        {
                            "artifact_collector": self.repo.props.artifacts_storage["artifact_collector"],
                            "storage_type": self.repo.props.artifacts_storage["storage_type"],
                            "organization": self.repo.provider.owner,
                            "repo": self.repo.provider.name,
                            "container": self.props.container,
                            "timeout": self.props.timeout,
                            "labels": self.runner.labels,
                            "title": self.props.name.name,
                            "id": self.props.name.value,
                            "storage_name": AwsUtils.makeUniqueS3BucketName(
                                f"{self.props.provider_name}-"
                                f"{self.repo.props.artifacts_storage['storage_name']}-"
                                "1-bucket"
                            ),
                        },
                    ),
                    lifecycle=TerraformResourceLifecycle(ignore_changes=["content"]),
                )
