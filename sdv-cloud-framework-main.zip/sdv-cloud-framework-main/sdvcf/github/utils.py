import re


class GitHubUtils:
    @staticmethod
    def accountName(name: str) -> str:
        """
        Converts the given name into a valid GitHub account name.

        Args:
            name (str): The name to be converted.

        Returns:
            str: The converted GitHub account name.

        Raises:
            None
        """
        # Contain at most 39 characters.
        # Can only contain alphanumeric characters and dashes (-).
        # Can't contain two consecutive dashes.
        # Can't start or end with a dash.
        # https://docs.github.com/en/enterprise-cloud@latest/admin/identity-and-access-management/managing-iam-for-your-enterprise/username-considerations-for-external-authentication
        name = re.sub(r"[^a-zA-Z0-9-]+", "-", name)
        name = re.sub(r"-{2,}", "-", name).rjust(1, "a")[:39]
        if re.search(r"^[-]", name):
            name = "a" + name[1:]
        if re.search(r"[-]$", name):
            name = name[:-1] + "a"
        return name

    @staticmethod
    def kubernetesManifestName(name: str) -> str:
        """
        Converts the given name into a valid Kubernetes manifest name.

        Args:
            name (str): The name to be converted.

        Returns:
            str: The converted Kubernetes manifest name.

        Raises:
            None
        """
        # Contain at most 63 characters.
        # Contain only lowercase alphanumeric characters or '-'.
        # Start with an alphabetic character.
        # End with an alphanumeric character
        # https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#rfc-1035-label-names
        name = re.sub(r"[^a-z0-9-]+", "", name.lower()).rjust(1, "a")[:63]
        if re.search(r"^[^a-z]", name):
            name = "0" + name[1:]
        if re.search(r"[^0-9a-z]$", name):
            name = name[:-1] + "0"
        return name
