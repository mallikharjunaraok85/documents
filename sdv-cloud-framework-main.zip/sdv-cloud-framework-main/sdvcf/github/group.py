from typing import Optional

from cdktf_cdktf_provider_github.team import Team
from cdktf_cdktf_provider_github.team_membership import TeamMembership
from cdktf_cdktf_provider_github.team_settings import TeamSettings

from sdvcf.interface import IUser, IUserGroup

from .provider import GitHubProvider


class GitHubUserGroup(IUserGroup):
    provider: GitHubProvider

    _parent_team: Optional[Team]
    _team: Optional[Team]

    def __init__(self, ns: str):
        """
        Initializes a new instance of the GitHubUserGroup class.

        Args:
            ns (str): The namespace of the user group.
        """
        super().__init__(GitHubProvider.Instance(), ns)

        self._parent_team = None
        self._team = None

    def GetUniqueID(self) -> str:
        """
        Gets the unique ID of the user group.

        Returns:
            str: The unique ID of the user group.
        """
        return self.team.slug

    def _AddUser(self, user: IUser) -> None:
        """
        Adds a user to the team membership.

        Args:
            user (IUser): The user to be added.

        Returns:
            None
        """
        TeamMembership(
            self,
            f"{self.name}-{user.name}-team-membership",
            username=user.GetUniqueID(),
            team_id=self.team.slug,
        )

    def AddGroup(self, group: IUserGroup) -> None:
        """
        Adds a user group to the current group.

        Args:
            group (IUserGroup): The user group to be added.

        Raises:
            AssertionError: If the group is not an instance of GitHubUserGroup.
            AssertionError: If the group is already initialized and cannot be added to another group.
        """
        assert isinstance(group, GitHubUserGroup), f"Can not add Non-GitHub group `{group.name}` to {self.name}"
        assert group._team is None, f"Group `{group.name}` already initialized, can not be added to another group"
        group._parent_team = self.team

    @property
    def team(self) -> Team:
        """
        Get the team associated with this group.

        Returns:
            Team: The team associated with this group.
        """
        if self._team is None:
            self._team = Team(
                self,
                f"{self.name}-team",
                name=self.name,
                parent_team_id=self._parent_team.slug if self._parent_team else self.provider.root_team.slug,
                privacy="closed",
            )
            # This resource manages the team settings
            # (in particular the request review delegation settings) within the organization
            TeamSettings(
                self,
                f"{self.name}-team-settings",
                team_id=self._team.id,
                review_request_delegation={
                    "algorithm": "ROUND_ROBIN",
                    "member_count": 1,
                    "notify": True,
                },
            )

        return self._team
