from typing import List

from sdvcf.interface import (
    IStageRunner,
    StageRunnerCPUArch,
    StageRunnerOS,
    StageRunnerProps,
)

from .provider import GitHubProvider

__all__ = [
    "GitHubHostedRunner",
]


class GitHubHostedRunner(IStageRunner):
    """
    Represents a GitHub hosted runner for executing stages in a pipeline.

    Args:
        ns (str): The namespace of the runner.
        props (StageRunnerProps): The properties of the runner.

    Attributes:
        labels (List[str]): The labels associated with the runner.

    Raises:
        AssertionError: If the CPU architecture is not x86_64.

    """

    def __init__(self, ns: str, props: StageRunnerProps):
        super().__init__(GitHubProvider.Instance(), ns, props)

        assert self.props.arch == StageRunnerCPUArch.x86_64, "x86_64 is only supported for GitHub Hosted Runners"

    @property
    def labels(self) -> List[str]:
        os_map = {
            StageRunnerOS.Windows: "windows-latest",
            StageRunnerOS.Linux: "ubuntu-latest",
        }
        return [os_map[self.props.os]]
