import os
from typing import Any, Optional

import requests
from cdktf import LocalBackend, TerraformBackend
from cdktf_cdktf_provider_github import provider
from cdktf_cdktf_provider_github.team import Team
from constructs import Construct

from sdvcf.interface import ICloudProvider, IProvider


class GitHubProvider(ICloudProvider):
    """
    Represents a provider for GitHub cloud services.

    Args:
        scope (Construct): The scope in which the provider is defined.
        ns (str): The namespace of the provider.
        organization (str): The GitHub organization name.
        external_members (bool, optional): Members should be managed within the specified organization if set to True,
                                           otherwise only referenced as the data source. Defaults to False.
        **_ (Any): Additional arguments.

    Attributes:
        owner (str): The GitHub organization name.
        external_members (bool): Members should be managed within the specified organization if set to True,
                                 otherwise only referenced as the data source.
        _root_team (Optional[Team]): The root team of the provider.
        _is_plan_free (bool): The level of GitHub organization plan. True if free.

    Methods:
        root_team: Get the root team of the provider.
        _SetupBackend: Set up the backend for the provider.
        CommitDashboard: Commit the dashboard.

    """

    owner: str
    external_members: bool

    _root_team: Optional[Team]
    _is_plan_free: Optional[bool]

    def __init__(self, scope: Construct, ns: str, organization: str, external_members: bool = False, **_: Any):
        super().__init__(scope, ns)

        self.owner = organization
        self.external_members = external_members

        self._root_team = None
        self._is_plan_free = None

        provider.GithubProvider(self, ns, owner=self.owner)

    @property
    def root_team(self) -> Team:
        """
        Get the root team of the provider.

        Returns:
            Team: The root team of the provider.

        """
        if self._root_team is None:
            self._root_team = self._team = Team(
                self,
                f"{self.name}-root-team",
                name=self.name,
                privacy="closed",
            )
        return self._root_team

    @property
    def is_plan_free(self) -> bool:
        """
        Get the level of GitHub organization plan.

        Returns:
            True is plan is free, otherwise - False

        """
        if self._is_plan_free is None:
            try:
                api_token = os.getenv("GITHUB_TOKEN")
                if api_token is None:
                    raise OSError("GITHUB_TOKEN environmental variable is not set")
                org_name = self.owner
                url = f"https://api.github.com/orgs/{org_name}"
                headers = {"Authorization": f"token {api_token}"}
                response = requests.get(url, headers=headers, timeout=10)
                if response.status_code == 200:
                    org_data = response.json()
                    plan_info = org_data.get("plan", {})
                    if "name" in plan_info:
                        self._is_plan_free = True if plan_info.get("name") == "free" else False
                    else:
                        raise PermissionError(
                            "Not enough rights to get organization plan info for provided token. Add plan permission."
                        )
                else:
                    raise RuntimeError(
                        f"""Failed to retrieve organization information: {response.text}.
                        Status code: {response.status_code}"""
                    )
            except requests.exceptions.RequestException as e:
                raise RuntimeError(f"An error occurred: {str(e)}") from e
        return self._is_plan_free

    def _SetupBackend(self, provider: Optional[IProvider] = None) -> TerraformBackend:
        """
        Set up the backend for the provider.

        Args:
            provider (Optional[IProvider], optional): The provider. Defaults to None.

        Returns:
            TerraformBackend: The backend for the provider.

        """
        return LocalBackend(
            provider or self,
            path="github.terraform.tfstate",
            workspace_dir=provider.name if provider else self.name,
        )

    def CommitDashboard(self) -> None:
        """
        TODO: Commit the dashboard implementation.
        """
        pass
