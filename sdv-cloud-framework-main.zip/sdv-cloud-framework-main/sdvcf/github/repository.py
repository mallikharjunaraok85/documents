import glob
import os
from datetime import datetime
from importlib.resources import as_file, files
from itertools import chain
from typing import Dict, Optional, Union

from cdktf import Fn, TerraformIterator, TerraformResourceLifecycle, Token
from cdktf_cdktf_provider_github.actions_repository_access_level import (
    ActionsRepositoryAccessLevel,
)
from cdktf_cdktf_provider_github.actions_repository_permissions import (
    ActionsRepositoryPermissions,
)
from cdktf_cdktf_provider_github.actions_secret import ActionsSecret
from cdktf_cdktf_provider_github.actions_variable import ActionsVariable
from cdktf_cdktf_provider_github.branch import Branch
from cdktf_cdktf_provider_github.branch_default import BranchDefault
from cdktf_cdktf_provider_github.branch_protection import (
    BranchProtection,
    BranchProtectionRequiredPullRequestReviews,
)
from cdktf_cdktf_provider_github.repository import Repository, RepositoryTemplate
from cdktf_cdktf_provider_github.repository_autolink_reference import (
    RepositoryAutolinkReference,
)
from cdktf_cdktf_provider_github.repository_collaborators import RepositoryCollaborators
from cdktf_cdktf_provider_github.repository_file import RepositoryFile

from sdvcf.interface import (
    IPipeline,
    IRepository,
    IUser,
    IUserGroup,
    RepositoryAccessType,
    RepositoryProps,
)
from sdvcf.output import Output

from .group import GitHubUserGroup
from .pipeline import GitHubActionsPipeline
from .provider import GitHubProvider
from .user import GitHubUser


class GitHubRepository(IRepository):
    """
    Represents a GitHub repository in the SDV Cloud Framework.

    Args:
        ns (str): The namespace of the repository.
        props (RepositoryProps): The properties of the repository.

    Attributes:
        Public:
            provider (GitHubProvider): The GitHub provider associated with the repository.

        Private static class:
            _template_repository (Optional[Repository]): The template repository used for initializing new repositories.
            _common_actions_repository (Optional[Repository]): The repository for common GitHub actions
            _recipes_warehouse_repository (Optional[Repository]): The repository for VM setup recipes

        Private:
            _repository (Optional[Repository]): The underlying CDKTF repository resource.
            _default_branch (Optional[BranchDefault]): The default branch of the repository.
            _dev_branch (Optional[Branch]): The development branch of the repository.
            _repo_users (Dict[IUser, RepositoryAccessType]): The users with their corresponding access types for the
                                                             repository.
            _repo_groups (Dict[IUserGroup, RepositoryAccessType]): The user groups with their corresponding access
                                                                   types for the repository.
            _access_type_mapping (Dict[RepositoryAccessType, str]): The mapping of repository access types to GitHub
                                                                    permission levels.
            _autolink: (Optional[RepositoryAutolinkReference]): The option to enable autolink to external web apps.
    """

    # Public attributes
    provider: GitHubProvider

    # Private static class attributes
    _template_repository: Optional[Repository] = None
    _common_actions_repository: Optional[Repository] = None
    _recipes_warehouse_repository: Optional[Repository] = None

    # Private attributes
    _repository: Optional[Repository]
    _default_branch: Optional[BranchDefault]
    _dev_branch: Optional[Branch]
    _repo_users: Dict[IUser, RepositoryAccessType]
    _repo_groups: Dict[IUserGroup, RepositoryAccessType]
    _access_type_mapping: Dict[RepositoryAccessType, str]
    _autolink: Optional[RepositoryAutolinkReference] = None

    def __init__(self, ns: str, props: RepositoryProps):
        """
        Initializes a new instance of the Repository class.

        Args:
            ns (str): The namespace of the repository.
            props (RepositoryProps): The properties of the repository.

        """
        scope = GitHubProvider.Instance()
        super().__init__(scope, ns if props.is_global else f"{scope.name}-{ns}", props)

        self._repository = None
        self._default_branch = None
        self._dev_branch = None
        self._repo_users = {}
        self._repo_groups = {}
        self._autolink = None

        self._access_type_mapping = {
            RepositoryAccessType.MAINTAINER: "maintain",
            RepositoryAccessType.CONTRIBUTOR: "push",
            RepositoryAccessType.VIEWER: "triage",
            RepositoryAccessType.OWNER: "admin",
        }

        self.common_actions_repository
        self.recipes_warehouse_repository

        if self.props.protection_rule:
            self.AddProtectionRule()

    @property
    def repository(self) -> Repository:
        if self._repository is None:
            self._repository = Repository(
                self,
                self.name,
                name=self.name,
                visibility="public" if self.props.is_public else "private",
                auto_init=self.props.auto_init,
                archive_on_destroy=self.props.is_permanent,
                has_issues=self.props.has_issues,
                description=self.props.description,
                allow_merge_commit=self.props.merge_options.merge_commit,
                allow_rebase_merge=self.props.merge_options.rebase_merge,
                allow_squash_merge=self.props.merge_options.squash_merge,
                template=(
                    RepositoryTemplate(owner=self.provider.owner, repository=self.template_repository.name)
                    if self.props.auto_init
                    else None
                ),
                lifecycle=TerraformResourceLifecycle(ignore_changes=["pages"]),
            )

            if self.props.allow_reuse_pipeline and not self.props.is_public:
                ActionsRepositoryAccessLevel(
                    self.provider,
                    f"{self.name}-actions-repo-access-level",
                    repository=self._repository.name,
                    access_level="organization",
                )

            if self.props.artifacts_storage["artifact_collector"]:
                artifact_push_url_value = str(os.getenv("ARTIFACT_PUSH_URL") or "")
                ActionsVariable(
                    self.provider,
                    f"{self.name}-actions-environment-variable-artifact-push-url",
                    repository=self._repository.name,
                    variable_name="ARTIFACT_PUSH_URL",
                    value=artifact_push_url_value,
                )
                artifact_push_token_value = str(os.getenv("ARTIFACT_PUSH_TOKEN") or "")
                ActionsSecret(
                    self.provider,
                    f"{self.name}-actions-environment-secret-artifact-push-token",
                    repository=self._repository.name,
                    secret_name="ARTIFACT_PUSH_TOKEN",
                    plaintext_value=artifact_push_token_value,
                )

            Output(self, "ssh_url", value=self._repository.ssh_clone_url, resource_id=str(self._repository.repo_id))
            Output(self, "web_url", value=self._repository.http_clone_url, resource_id=str(self._repository.repo_id))
        return self._repository

    @property
    def autolink_reference(self) -> RepositoryAutolinkReference:
        if self._autolink is None:
            self._autolink = RepositoryAutolinkReference(
                self,
                f"{self.name}-autolink",
                repository=self.repository.name,
                key_prefix=self.props.key_prefix,
                target_url_template=self.props.target_url_template,
            )
        return self._autolink

    @property
    def template_repository(self) -> Repository:
        """
        Returns the template repository.

        If the template repository does not exist, it creates a new one with the specified properties.
        The template repository is used as a base for creating new repositories.

        Returns:
            Repository: The template repository.
        """
        if self.__class__._template_repository is None:
            props = RepositoryProps()
            name = f"{self.provider.name}-repository-template"
            self.__class__._template_repository = Repository(
                self.provider, name, name=name, is_template=True, auto_init=True, visibility="private"
            )

            default_branch = BranchDefault(
                self.provider,
                f"{name}-default-branch",
                repository=self.__class__._template_repository.name,
                branch=props.default_branch,
            )

            path = "repository/structure"
            GitHubRepository.uploadFiles(self.provider, path, name, self.__class__._template_repository, default_branch)

        return self.__class__._template_repository

    @property
    def common_actions_repository(self) -> Repository:
        """
        Returns the common actions repository.

        Creates a common actions repository if there is at least one GitHub repository in GitHub.
        The common actions repository is used to store GitHub Workflows actions that can be reused
        across organization.

        Returns:
            Repository: The common actions repository.
        """
        if self.__class__._common_actions_repository is None:
            name = f"{self.provider.name}-common-actions"
            props = RepositoryProps()
            self.__class__._common_actions_repository = Repository(
                self.provider,
                name,
                name=name,
                visibility="private",
                auto_init=True,
                archive_on_destroy=False,
                description="The repository which contains common GitHub Workflow \
                            actions for SDVCF-managed code infrastructure.",
            )

            default_branch = BranchDefault(
                self.provider,
                f"{name}-default-branch",
                repository=self.__class__._common_actions_repository.name,
                branch=props.default_branch,
            )

            if not self.provider.is_plan_free:
                BranchProtection(
                    self.provider,
                    f"{name}-main-branch-protection",
                    repository_id=self.__class__._common_actions_repository.node_id,
                    pattern=default_branch.branch,
                    required_pull_request_reviews=[
                        BranchProtectionRequiredPullRequestReviews(
                            required_approving_review_count=2, dismiss_stale_reviews=True
                        )
                    ],
                    require_conversation_resolution=True,
                )

            path = "repository/common-actions-structure"
            GitHubRepository.uploadFiles(
                self.provider, path, name, self.__class__._common_actions_repository, default_branch
            )

            ActionsRepositoryAccessLevel(
                self.provider,
                f"{name}-actions-repo-access-level",
                repository=self.__class__._common_actions_repository.name,
                access_level="organization",
            )

            ActionsRepositoryPermissions(
                self.provider,
                f"{name}-actions-repo-permissions",
                repository=self.__class__._common_actions_repository.name,
                allowed_actions="local_only",
            )

            RepositoryCollaborators(
                self.provider,
                f"{name}-collaborators",
                repository=self.__class__._common_actions_repository.name,
                team=[{"permission": "maintain", "teamId": self.provider.root_team.slug}],
            )

            Output(
                self,
                "common_actions_ssh_url",
                value=self.__class__._common_actions_repository.ssh_clone_url,
                resource_id=str(self.__class__._common_actions_repository.repo_id),
            )
            Output(
                self,
                "common_actions_web_url",
                value=self.__class__._common_actions_repository.http_clone_url,
                resource_id=str(self.__class__._common_actions_repository.repo_id),
            )

        return self.__class__._common_actions_repository

    @property
    def recipes_warehouse_repository(self) -> Repository:
        """
        Returns the recipes warehouse repository.

        Creates a recipe warehouse if there is at least one GitHub repository in GitHub.
        The recipe warehouse repository is used to store Ansible Playbooks (recipes)
        that can user for VM configuration across SDVCF.

        Returns:
            Repository: The recipe warehouse repository.
        """
        if self.__class__._recipes_warehouse_repository is None:
            name = f"{self.provider.name}-recipes-warehouse"
            props = RepositoryProps()
            self.__class__._recipes_warehouse_repository = Repository(
                self.provider,
                name,
                name=name,
                visibility="private",
                auto_init=True,
                archive_on_destroy=False,
                description="The repository which contains recipes for virtual machines configuration.",
            )

            default_branch = BranchDefault(
                self.provider,
                f"{name}-default-branch",
                repository=self.__class__._recipes_warehouse_repository.name,
                branch=props.default_branch,
            )

            if not self.provider.is_plan_free:
                BranchProtection(
                    self.provider,
                    f"{name}-main-branch-protection",
                    repository_id=self.__class__._recipes_warehouse_repository.node_id,
                    pattern=default_branch.branch,
                    required_pull_request_reviews=[
                        BranchProtectionRequiredPullRequestReviews(
                            required_approving_review_count=2, dismiss_stale_reviews=True
                        )
                    ],
                    require_conversation_resolution=True,
                    depends_on=[default_branch],
                )

            path = "repository/recipes-warehouse-structure"
            GitHubRepository.uploadFiles(
                self.provider, path, name, self.__class__._recipes_warehouse_repository, default_branch
            )

            RepositoryCollaborators(
                self.provider,
                f"{name}-collaborators",
                repository=self.__class__._recipes_warehouse_repository.name,
                team=[{"permission": "maintain", "teamId": self.provider.root_team.slug}],
            )

            Output(
                self,
                "recipes_warehouse_ssh_url",
                value=self.__class__._recipes_warehouse_repository.ssh_clone_url,
                resource_id=str(self.__class__._recipes_warehouse_repository.repo_id),
            )
            Output(
                self,
                "recipes_warehouse_actions_web_url",
                value=self.__class__._recipes_warehouse_repository.http_clone_url,
                resource_id=str(self.__class__._recipes_warehouse_repository.repo_id),
            )

        return self.__class__._recipes_warehouse_repository

    @staticmethod
    def uploadFiles(
        provider: GitHubProvider, path: str, name: str, repository: Repository, branch: BranchDefault
    ) -> RepositoryFile:
        """
        Generate a RepositoryFile object that is used to upload local files to repository.

        Parameters:
            provider (GitHubProvider): Instance of the provider.
            path (str): Path to files folder.
            name (str): Name of static class property scope.
            repository (Repository): The repository where to put files.
            branch (BranchDefault): Branch where to upload files.

        Returns:
            RepositoryFile: File uploading object.

        Note:
            The path must be relative to sdvcf/resources folder.
            Uploading will override existing files in case of collision.
        """
        with as_file(files("sdvcf.resources").joinpath(path)) as files_path:
            iterator = TerraformIterator.from_map(
                map={
                    os.path.relpath(file, files_path): os.path.abspath(file)
                    for file in chain(
                        glob.iglob(os.path.join(files_path, "**", "*"), recursive=True),
                        glob.iglob(os.path.join(files_path, "**", ".*"), recursive=True),
                    )
                    if not os.path.isdir(file)
                }
            )

        return RepositoryFile(
            provider,
            f"{name}-repository-structure-files-upload",
            for_each=iterator,
            repository=repository.name,
            file=iterator.key,
            overwrite_on_create=True,
            branch=branch.branch,
            content=Fn.file(Token.as_string(iterator.value)),
        )

    @property
    def default_branch(self) -> BranchDefault:
        """
        Returns the default branch of the repository.

        :return: The default branch of the repository.
        :rtype: BranchDefault
        """
        if self._default_branch is None:
            self._default_branch = BranchDefault(
                self,
                f"{self.name}-default-branch",
                repository=self.repository.name,
                branch=self.props.default_branch,
            )

            if (not self.provider.is_plan_free and not self.props.is_public) or self.props.is_public:
                BranchProtection(
                    self,
                    f"{self.name}-main-branch-protection",
                    repository_id=self.repository.node_id,
                    pattern=self._default_branch.branch,
                    required_pull_request_reviews=[
                        BranchProtectionRequiredPullRequestReviews(
                            required_approving_review_count=2, dismiss_stale_reviews=True
                        )
                    ],
                    require_conversation_resolution=True,
                )
        return self._default_branch

    @property
    def dev_branch(self) -> Union[Branch, None]:
        """
        Returns the development branch of the repository or None in case repository is empty.

        If the development branch does not exist, it will be created with the following properties:
        - Name: {repository_name}-dev-branch
        - Branch: {dev_branch}
        - Repository: {repository_name}
        - Source Branch: {default_branch}

        The development branch will also have branch protection enabled with the following settings:
        - Pattern: {dev_branch}
        - Required Approving Review Count: 2
        - Require Conversation Resolution: True

        Returns:
        - The development branch of the repository.
        - None in case repository is empty.
        """
        if self.props.auto_init is False:
            return None

        if self._dev_branch is None:
            self._dev_branch = Branch(
                self,
                f"{self.name}-dev-branch",
                branch=self.props.dev_branch,
                repository=self.repository.name,
                source_branch=self.default_branch.branch,
            )

            if (not self.provider.is_plan_free and not self.props.is_public) or self.props.is_public:
                BranchProtection(
                    self,
                    f"{self.name}-dev-branch-protection",
                    repository_id=self.repository.node_id,
                    pattern=self._dev_branch.branch,
                    required_pull_request_reviews=[
                        BranchProtectionRequiredPullRequestReviews(
                            required_approving_review_count=2, dismiss_stale_reviews=True
                        )
                    ],
                    require_conversation_resolution=True,
                    lifecycle=TerraformResourceLifecycle(
                        replace_triggered_by=[
                            (
                                f"{self._dev_branch.terraform_resource_type}.{self._dev_branch.friendly_unique_id}"
                                ".source_branch"
                            )
                        ]
                    ),
                )

        return self._dev_branch

    def AddUser(self, user: IUser, atype: RepositoryAccessType, expire: Optional[datetime] = None) -> None:
        """
        Adds a user to the repository with the specified access type.

        Args:
            user (GitHubUser): The user to add to the repository.
            atype (RepositoryAccessType): The access type for the user.
            expire (Optional[datetime]): The expiration date for the user's access (default: None).

        Raises:
            AssertionError: If the user is not an instance of GitHubUser.
            AssertionError: If the access type is unknown.

        Returns:
            None
        """
        assert isinstance(user, GitHubUser)
        assert (
            atype in self._access_type_mapping
        ), f"Can not add `{user.name}` user to `{self.name}` repository with unknown access type: `{atype}`"

        self._repo_users[user] = atype

    def AddGroup(self, group: IUserGroup, atype: RepositoryAccessType, expire: Optional[datetime] = None) -> None:
        """
        Adds a user group to the repository with the specified access type.

        Args:
            group (IUserGroup): The user group to add.
            atype (RepositoryAccessType): The access type for the group.
            expire (Optional[datetime], optional): NOT USED IN THE CURRENT VERSION. The expiration date for the group's
                                                   access. Defaults to None.
        """
        assert isinstance(group, GitHubUserGroup)
        assert (
            atype in self._access_type_mapping
        ), f"Can not add `{group.name}` group to `{self.name}` repository with unknown access type: `{atype}`"

        self._repo_groups[group] = atype

    def CreatePipeline(self) -> IPipeline:
        """
        Creates a pipeline for the repository.

        Returns:
            An instance of IPipeline representing the created pipeline.
        """
        return GitHubActionsPipeline(self, f"{self.name}-github-actions")

    def AddProtectionRule(self) -> None:
        """
        Adds a protection rules to the repository to the specified branch pattern.

        Returns:
            None
        """

        if (not self.provider.is_plan_free and not self.props.is_public) or self.props.is_public:
            for branch in self.props.protection_rule["branch_names"]:
                BranchProtection(
                    self,
                    f"{self.name}-{branch}-branch-protection",
                    repository_id=self.repository.node_id,
                    pattern=branch,
                    required_pull_request_reviews=[
                        BranchProtectionRequiredPullRequestReviews(
                            required_approving_review_count=2, dismiss_stale_reviews=True
                        )
                    ],
                    require_conversation_resolution=True,
                )

        if self.props.protection_rule.get("reviewers") is not None:
            required_reviewers = []
            for reviewer in self.props.protection_rule["reviewers"]:
                if "user" in reviewer:
                    required_reviewers.append(f"@{reviewer['user']}")
                if "group" in reviewer:
                    required_reviewers.append(f"@{self.provider.owner}/{reviewer['group']}")

            RepositoryFile(
                self,
                f"{self.name}-codeowners-file",
                repository=self.repository.name,
                branch=self.default_branch.branch,
                file=".github/CODEOWNERS",
                content=f"* {' '.join(required_reviewers)}",
            )

    def Commit(self) -> None:
        # Ensure repository will be deployed
        self.repository

        if self._repo_users or self._repo_groups:
            RepositoryCollaborators(
                self,
                f"{self.name}-collaborators",
                repository=self.repository.name,
                user=[
                    {"permission": self._access_type_mapping[atype], "username": user.GetUniqueID()}
                    for user, atype in self._repo_users.items()
                ],
                team=[
                    {"permission": self._access_type_mapping[atype], "teamId": group.GetUniqueID()}
                    for group, atype in self._repo_groups.items()
                ],
            )
