from typing import Optional

from cdktf_cdktf_provider_github.data_github_user import DataGithubUser
from cdktf_cdktf_provider_github.membership import Membership
from cdktf_cdktf_provider_github.team_membership import TeamMembership

from sdvcf.interface import IUser, UserProps

from .provider import GitHubProvider
from .utils import GitHubUtils


class GitHubUser(IUser):
    provider: GitHubProvider

    _user: Optional[DataGithubUser]

    def __init__(self, ns: str, props: UserProps):
        """
        Initializes a new instance of the GitHubUser class.

        Args:
            ns (str): The namespace of the user.
            props (UserProps): The properties of the user.
        """
        super().__init__(GitHubProvider.Instance(), GitHubUtils.accountName(ns), props)

        self._user = None

        membership = (
            [Membership(self, f"{self.name}-user-org-membership", username=self.GetUniqueID(), role="member")]
            if not self.props.external
            else None
        )

        self.user

        TeamMembership(
            self,
            f"{self.name}-root-team-membership",
            username=self.GetUniqueID(),
            team_id=self.provider.root_team.slug,
            depends_on=membership,
        )

    @property
    def user(self) -> DataGithubUser:
        """
        Gets the GitHub user associated with this instance.

        Returns:
            DataGithubUser: The GitHub user.
        """
        if self._user is None:
            github_username = self.name
            if self.props.username_suffix:
                # Add suffix to user: roman-hakh -> roman-hakh-gl
                github_username = github_username + self.props.username_suffix
            self._user = DataGithubUser(self, f"{self.name}-user", username=github_username)
        return self._user

    def GetSSHPublicKey(self) -> str:  # type: ignore[empty-body]
        """
        TODO: NOT IMPLEMENTED YET
        Gets the SSH public key of the user.

        Returns:
            str: The SSH public key.
        """
        # Currently not needed
        pass

    # Optional public SSH key (argument)
    # https://registry.terraform.io/providers/integrations/github/latest/docs/resources/user_ssh_key

    def GetUniqueID(self) -> str:
        """
        Gets the unique ID of the user.

        Returns:
            str: The unique ID.
        """
        return self.user.username
