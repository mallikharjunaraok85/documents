import os
from collections import OrderedDict as OrderedDict_c
from importlib.resources import as_file, files
from typing import TYPE_CHECKING, Dict, List, Optional
from typing import OrderedDict as OrderedDict_t
from typing import Tuple

if TYPE_CHECKING:
    from .repository import GitHubRepository

from cdktf import Fn
from cdktf_cdktf_provider_aws.data_aws_eks_cluster_auth import DataAwsEksClusterAuth
from cdktf_cdktf_provider_aws.eks_node_group import EksNodeGroup
from cdktf_cdktf_provider_aws.provider import AwsProvider as CdktfAwsProvider
from cdktf_cdktf_provider_github.repository_file import RepositoryFile
from cdktf_cdktf_provider_kubernetes.cluster_role_binding_v1 import ClusterRoleBindingV1
from cdktf_cdktf_provider_kubernetes.manifest import Manifest
from cdktf_cdktf_provider_kubernetes.provider import KubernetesProvider
from cdktf_cdktf_provider_kubernetes.service_account_v1 import ServiceAccountV1

from sdvcf.aws import AwsEksRunner
from sdvcf.interface import (
    IPipeline,
    IPipelineStage,
    IStageRunner,
    PipelineStageId,
    PipelineStageProps,
    StageRunnerComputeSize,
)

from .hosted_runner import GitHubHostedRunner
from .pipeline_stage import GitHubPipelineStage
from .utils import GitHubUtils


class GitHubActionsPipeline(IPipeline):
    """
    Represents a GitHub Actions pipeline.

    Attributes:
        NAME_PREFIX (str): The prefix for the pipeline name.
        repo (GitHubRepository): The GitHub repository associated with the pipeline.
        _eks_kubernetes_provider (Optional[KubernetesProvider]): The Kubernetes provider for EKS.
        _eks_kubernetes_service_account (Optional[ServiceAccountV1]): The Kubernetes service account for EKS.
        _connected_eks_runners (List[Tuple[str, EksNodeGroup]]): The list of connected EKS runners.
        _enabled_stages (OrderedDict_t[PipelineStageId, bool]): The enabled stages in the pipeline.
        _compute_to_n_pods_mapping (Dict[StageRunnerComputeSize, int]): The mapping of compute size to number of pods.
    """

    NAME_PREFIX: str

    # Public class attributes
    repo: "GitHubRepository"

    # Private static class attributes
    _eks_kubernetes_provider: Optional[KubernetesProvider] = None
    _eks_kubernetes_service_account: Optional[ServiceAccountV1] = None
    _connected_eks_runners: List[Tuple[str, EksNodeGroup]] = []

    # Private class attributes
    _enabled_stages: OrderedDict_t[PipelineStageId, bool]
    _compute_to_n_pods_mapping: Dict[StageRunnerComputeSize, int]

    def __init__(self, repo: "GitHubRepository", ns: str):
        """
        Initializes a new instance of the GitHubActionsPipeline class.

        Args:
            repo (GitHubRepository): The GitHub repository associated with the pipeline.
            ns (str): The namespace of the pipeline.
        """
        super().__init__(repo, ns)

        self.NAME_PREFIX = f"{self.provider.name}-github-pipeline"

        self._enabled_stages = OrderedDict_c(
            [
                (PipelineStageId.StaticAnalysis, False),
                (PipelineStageId.Build, False),
                (PipelineStageId.UnitTest, False),
                (PipelineStageId.BuildImage, False),
                (PipelineStageId.IntegrationTest, False),
                (PipelineStageId.SystemTest, False),
                (PipelineStageId.Release, False),
            ]
        )

        self._compute_to_n_pods_mapping = {
            StageRunnerComputeSize.Small: 1,
            StageRunnerComputeSize.Medium: 1,
            StageRunnerComputeSize.Large: 1,
        }

    def CreateStage(self, runner: IStageRunner, props: PipelineStageProps) -> IPipelineStage:
        """
        Creates a new stage in the pipeline.

        Args:
            runner (IStageRunner): The runner for the stage.
            props (PipelineStageProps): The properties of the stage.

        Returns:
            IPipelineStage: The created stage.
        """
        if isinstance(runner, GitHubHostedRunner):
            pass
        elif isinstance(runner, AwsEksRunner):
            self._ConnectEksRunner(runner)
        else:
            raise NotImplementedError(
                f"`{type(runner).__name__}` runner support not implemented yet for `{self.__class__.__name__}`"
            )

        self._enabled_stages[props.name] = True

        return GitHubPipelineStage(self.repo, f"{self.name}-{props.name.value}-stage", runner, props)

    def Commit(self) -> None:
        """
        Commits the pipeline configuration.
        """
        stages: List[Dict[str, str]] = []
        prev_stage = ""
        for stage, enabled in self._enabled_stages.items():
            if not enabled:
                continue
            stages.append({"id": stage.value, "title": stage.name, "needs": prev_stage})
            prev_stage = stage.value

        if self.repo.dev_branch is not None:
            with as_file(files("sdvcf.github.resources").joinpath("workflow_templates/main.yaml.tmpl")) as stage_file:
                RepositoryFile(
                    self,
                    f"{self.name}-main-file",
                    repository=self.repo.name,
                    file=".github/workflows/main.yaml",
                    branch=self.repo.dev_branch.branch,
                    content=Fn.templatefile(str(stage_file), {"stages": stages}),
                    overwrite_on_create=True,
                )

    def _EnsureEksKubernetesProvider(self, runner: AwsEksRunner) -> KubernetesProvider:
        """
        Ensures the EKS Kubernetes provider is set up.

        Args:
            runner (AwsEksRunner): The EKS runner.

        Returns:
            KubernetesProvider: The EKS Kubernetes provider.
        """
        if self.__class__._eks_kubernetes_provider is None:
            CdktfAwsProvider(self.provider, f"aws-{self.NAME_PREFIX}", region=runner.provider.region)
            auth_data = DataAwsEksClusterAuth(self.provider, f"{self.NAME_PREFIX}-eks-auth-data", name=runner.eks.name)
            self.__class__._eks_kubernetes_provider = KubernetesProvider(
                self.provider,
                f"{self.NAME_PREFIX}-kubernetes-provider",
                host=runner.eks.endpoint,
                cluster_ca_certificate=Fn.base64decode(
                    Fn.lookup_nested(runner.eks.certificate_authority, ["0", "data"])
                ),
                token=auth_data.token,
            )
        return self.__class__._eks_kubernetes_provider

    def _EnsureEksKubernetesServiceAccount(self, runner: AwsEksRunner) -> ServiceAccountV1:
        """
        Ensures the EKS Kubernetes service account is set up.

        Args:
            runner (AwsEksRunner): The EKS runner.

        Returns:
            ServiceAccountV1: The EKS Kubernetes service account.
        """
        self._EnsureEksKubernetesProvider(runner)

        # Ensure actions runner controller was setup
        runner.eks_helm.actions_runner_controller

        service_account_name = f"{self.NAME_PREFIX}-kubernetes-api-sa"
        if self.__class__._eks_kubernetes_service_account is None:
            self.__class__._eks_kubernetes_service_account = ServiceAccountV1(
                self.provider,
                service_account_name,
                metadata={"namespace": "default", "name": service_account_name},
                automount_service_account_token=True,
            )

            KUBERNETES_RBAC_AUTH_API_GROUP = os.getenv("KUBERNETES_RBAC_AUTH_API_GROUP", "rbac.authorization.k8s.io")

            role_binding_name = f"{service_account_name}-role-binding"
            ClusterRoleBindingV1(
                self.provider,
                role_binding_name,
                metadata={"name": role_binding_name},
                subject=[
                    {
                        "kind": "ServiceAccount",
                        "name": service_account_name,
                        "namespace": "default",
                        "api_group": "",
                    }
                ],
                role_ref={"kind": "ClusterRole", "name": "admin", "api_group": KUBERNETES_RBAC_AUTH_API_GROUP},
                depends_on=[self.__class__._eks_kubernetes_service_account],
            )
        return self.__class__._eks_kubernetes_service_account

    def _ConnectEksRunner(self, runner: AwsEksRunner) -> None:
        """
        Connects an EKS runner to the pipeline.

        Args:
            runner (AwsEksRunner): The EKS runner.
        """
        key = (self.repo.name, runner.node_group)
        if key not in self.__class__._connected_eks_runners:
            self.provider.add_dependency(runner.eks_helm)
            self._DeployActionsRunnerControllerManifests(runner)
            self.__class__._connected_eks_runners.append(key)

    def _DeployActionsRunnerControllerManifests(self, runner: AwsEksRunner) -> None:
        """
        Deploys the manifests for the Actions Runner Controller.

        Args:
            runner (AwsEksRunner): The EKS runner.
        """
        MANIFEST_API_VERSION = "actions.summerwind.dev/v1alpha1"
        manifest_dep_rid = f"{self.repo.name}-{runner.static_tag}-arc"
        manifest_dep_name = GitHubUtils.kubernetesManifestName(manifest_dep_rid)
        manifest_scale_rid = f"{manifest_dep_rid}-scale"
        manifest_scale_name = GitHubUtils.kubernetesManifestName(manifest_scale_rid)
        service_account = self._EnsureEksKubernetesServiceAccount(runner)
        pod_cpu_request = runner.instance_resources_mapping[runner.props.arch][runner.props.compute_size]["cpu"]
        pod_memory_request = runner.instance_resources_mapping[runner.props.arch][runner.props.compute_size]["memory"]
        manifest_dep = Manifest(
            self.provider,
            manifest_dep_rid,
            manifest={
                "apiVersion": MANIFEST_API_VERSION,
                "kind": "RunnerDeployment",
                "metadata": {"name": manifest_dep_name, "namespace": service_account.metadata.namespace},
                "spec": {
                    "template": {
                        "spec": {
                            "serviceAccountName": service_account.metadata.name,
                            "automountServiceAccountToken": True,
                            "image": "summerwind/actions-runner-dind",
                            "dockerdWithinRunnerContainer": True,
                            "labels": runner.labels,
                            "nodeSelector": {"runnergroup": runner.static_tag},
                            "repository": self.repo.repository.full_name,
                            "resources": {
                                "requests": {
                                    "cpu": pod_cpu_request,
                                    "memory": pod_memory_request,
                                },
                                "limits": {
                                    "cpu": pod_cpu_request,
                                    "memory": pod_memory_request,
                                },
                            },
                            "workVolumeClaimTemplate": {
                                "storageClassName": "standard",
                                "accessModes": ["ReadWriteOnce"],
                                "resources": {"requests": {"storage": "5Gi"}},
                            },
                        },
                    },
                },
            },
        )
        Manifest(
            self.provider,
            manifest_scale_rid,
            manifest={
                "apiVersion": MANIFEST_API_VERSION,
                "kind": "HorizontalRunnerAutoscaler",
                "metadata": {"name": manifest_scale_name, "namespace": service_account.metadata.namespace},
                "spec": {
                    "scaleTargetRef": {"kind": "RunnerDeployment", "name": manifest_dep_name},
                    "minReplicas": runner.props.scaling_desired,
                    "maxReplicas": runner.props.scaling_max
                    * self._compute_to_n_pods_mapping[runner.props.compute_size],
                    "metrics": [
                        {
                            "type": "TotalNumberOfQueuedAndInProgressWorkflowRuns",
                            "repositoryNames": [self.repo.repository.full_name],
                        },
                    ],
                },
            },
            depends_on=[manifest_dep],
        )
