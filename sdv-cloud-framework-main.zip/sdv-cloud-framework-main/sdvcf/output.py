from typing import Dict

from cdktf import TerraformOutput
from constructs import Construct

from .tags import Tags


class Output(Tags):
    def __init__(
        self, scope: Construct, id: str, value: str, resource_id: str, user_name: str = "", is_s3_bucket: bool = False
    ):
        user_data: Dict[str, str] = {"Value": value, "Id": resource_id}
        if user_name:
            user_data["UserName"] = user_name
        if is_s3_bucket:
            # TODO(SDV-1174): Fix incorrect behavior by separating S3
            user_data["Type"] = "Misc"
            user_data["Component"] = type(scope).__name__
            user_data["ComponentName"] = "AWS-S3-Bucket"
        TerraformOutput(scope, id=id, value=Tags(scope, id, user_data).to_dict)
