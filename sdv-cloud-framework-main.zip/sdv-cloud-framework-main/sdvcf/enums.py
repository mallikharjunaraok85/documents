from enum import Enum

from .aws import AWSProvider
from .azure import AzureProvider
from .github import GitHubProvider


class ProviderAlias(Enum):
    """Represents all allowed providers in terms of the project"""

    aws = AWSProvider
    azure = AzureProvider
    github = GitHubProvider
