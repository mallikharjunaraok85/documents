from enum import Enum, auto
from importlib.resources import as_file, files
from io import FileIO
from typing import Any, Union

import yaml

try:
    from yaml import CFullLoader as Loader
except ImportError:
    from yaml import FullLoader as Loader

from cerberus import Validator


class DomainType(Enum):
    common = auto()
    project = auto()


class DeployConfigUtils:
    _seen_fields = {}

    @classmethod
    def load(cls, domain: DomainType, config: Union[str, FileIO]) -> Any:
        validator = Validator()
        with as_file(
            files("sdvcf.resources").joinpath(f"config/{domain.name}/schema.variables.yaml")
        ) as schema_file_path:
            schema = cls._load_yaml_document(str(schema_file_path))
        document = cls._load_yaml_document(config)
        if not validator.validate(document, schema):  # type: ignore
            errors = yaml.dump(validator.errors, default_flow_style=False).strip()  # type: ignore
            raise SyntaxError(f"The infrastructure deployment configuration file is invalid!\n{errors}")
        return document

    @staticmethod
    def _load_yaml_document(config: Union[str, FileIO]):
        with open(config, "r") if isinstance(config, str) else config as stream:
            return yaml.load(stream, Loader=Loader)
