#!/bin/bash

PLATFORM=${PLATFORM}

apt-get update

# Install a set of software
apt install -y \
    wget \
    git \
    sudo \
    bash-completion \
    openssl \
    nginx

# code-server
## Get latest code-server release version
code_server_latest_release=$(curl -s https://api.github.com/repos/coder/code-server/releases/latest | grep tag_name | awk -F'"' '{gsub ("v", ""); print $4}');
## Download latest code-server release
mkdir /app && cd "$_"
wget https://github.com/coder/code-server/releases/download/v$code_server_latest_release/code-server-$code_server_latest_release-linux-$${PLATFORM,,}.tar.gz \
    && tar -xvzf code-server-$code_server_latest_release-linux-$${PLATFORM,,}.tar.gz \
    && rm -rf code-server-$code_server_latest_release-linux-$${PLATFORM,,}.tar.gz

## Add systemd code-server unit
APP_DIR="/app/code-server-$code_server_latest_release-linux-$${PLATFORM,,}/bin"
APP_PORT="8080"
APP_AUTH="none"
OPTS="--disable-workspace-trust"

touch /etc/systemd/system/code-server.service
echo "# Systemd service file for Visual Studio Code daemon

[Unit]
Description=Visual Studio Code daemon service
After=network.target

[Service]
Type=simple
User=${USER}

ExecStart=$APP_DIR/code-server \
        --bind-addr localhost:$APP_PORT \
        --auth $APP_AUTH \
        --disable-telemetry \
        $OPTS \
        \$HOME
ExecReload=/bin/kill -HUP \$MAINPID

[Install]
WantedBy=multi-user.target" > /etc/systemd/system/code-server.service

systemctl enable --now code-server

# oauth2-proxy
## Get latest oauth2-proxy release version
oauth2_proxy_latest_release=$(curl -s https://api.github.com/repos/oauth2-proxy/oauth2-proxy/releases/latest | grep tag_name | awk -F'"' '{print $4}');

## Download latest oauth2-proxy release
wget https://github.com/oauth2-proxy/oauth2-proxy/releases/download/$oauth2_proxy_latest_release/oauth2-proxy-$oauth2_proxy_latest_release.linux-$${PLATFORM,,}.tar.gz \
    && tar -xvzf oauth2-proxy-$oauth2_proxy_latest_release.linux-$${PLATFORM,,}.tar.gz \
    && rm -rf oauth2-proxy-$oauth2_proxy_latest_release.linux-$${PLATFORM,,}.tar.gz

## Add oauth2-proxy file with available email
ALLOWED_EMAIL="/app/allowed_email.txt"
echo "${USER}@${EMAIL_DOMAIN}" > $ALLOWED_EMAIL

# Add systemd oauth2-proxy unit
OAUTH2_PROXY_DIR="/app/oauth2-proxy-$oauth2_proxy_latest_release.linux-$${PLATFORM,,}"
echo "# Systemd service file for oauth2-proxy daemon

[Unit]
Description=oauth2-proxy daemon service
After=network.target

[Service]
# www-data group and user need to be created before using these lines

ExecStart=$OAUTH2_PROXY_DIR/oauth2-proxy \
--authenticated-emails-file $ALLOWED_EMAIL \
--cookie-secret ${COOKIE_SECRET} \
--http-address http://0.0.0.0:4180 \
--cookie-name _oauth2_proxy \
--cookie-expire 48h \
--cookie-refresh 24h \
--cookie-secure true \
--cookie-httponly true \
--reverse-proxy true \
--provider azure \
--azure-tenant ${TENANT_ID} \
--client-id ${CLIENT_ID} \
--client-secret ${CLIENT_SECRET} \
--oidc-issuer-url https://login.microsoftonline.com/${TENANT_ID}/v2.0 \
--whitelist-domain localhost \
--redirect-url ${REDIRECT_URI}
ExecReload=/bin/kill -HUP \$MAINPID

KillMode=process

[Install]
WantedBy=multi-user.target" > /etc/systemd/system/oauth2-proxy.service
systemctl enable --now oauth2-proxy

# Add systemd nginx unit
## Add nginx configuration file
echo "worker_processes  1;

events {
    worker_connections  1024;
}

http {
    include       mime.types;
    default_type  application/octet-stream;
    sendfile        on;
    proxy_buffer_size   128k;
    proxy_buffers   4 256k;
    proxy_busy_buffers_size   256k;
    keepalive_timeout  65;
    include conf.d/*.conf;
}
" > /etc/nginx/nginx.conf

## Add configuration file for nginx oauth2-proxy
echo "## https://oauth2-proxy.github.io/oauth2-proxy/configuration/overview/
server {
    listen 80;
    server_name _;

    #include ssl/default.conf;

    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Host \$host:80;
    proxy_set_header X-Forwarded-Server \$host;
    proxy_set_header X-Forwarded-Proto \$scheme;

    proxy_http_version 1.1;

    location /oauth2 {
        proxy_set_header X-Auth-Request-Redirect \$scheme://\$host\$request_uri;
        proxy_pass       http://localhost:4180;
    }

    location / {
        auth_request /oauth2/auth;
        error_page 401 =403 /oauth2/sign_in;

        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;

        auth_request_set \$email  \$upstream_http_x_auth_request_email;
        proxy_set_header X-Email \$email;
        auth_request_set \$user  \$upstream_http_x_auth_request_user;
        proxy_set_header X-User  \$user;
        auth_request_set \$token  \$upstream_http_x_auth_request_access_token;
        proxy_set_header X-Access-Token \$token;
        auth_request_set \$auth_cookie \$upstream_http_set_cookie;
        add_header Set-Cookie \$auth_cookie;
        add_header Redirect-Uri \$scheme://\$host\$request_uri;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host \$host;


        proxy_pass http://localhost:8080;
    }
}
" >  /etc/nginx/conf.d/nginx.conf

systemctl enable --now nginx
systemctl restart nginx
