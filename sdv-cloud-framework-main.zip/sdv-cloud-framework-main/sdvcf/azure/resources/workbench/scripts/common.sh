#!/bin/bash

# Install Development utilities
export DEBIAN_FRONTEND=noninteractive
apt-get update && apt-get upgrade -yq \
    && apt-get install -yq \
        curl \
        unzip \
        wget \
        git \
        gcc \
        ninja-build \
        cmake \
        python3 \
        python3-pip \
        python3-pyinotify \
        python3-psutil \
        linux-firmware \
        ubuntu-drivers-common
