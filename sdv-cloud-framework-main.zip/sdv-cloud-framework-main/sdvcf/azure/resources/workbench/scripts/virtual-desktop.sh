#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
apt-get update && apt-get upgrade -yq \
    && apt-get -yq install      \
        wget                    \
        snap                    \
        dbus-user-session       \
        alsa-base               \
        pulseaudio              \
        pulseaudio-utils        \
        xfce4-session           \
        xfce4-goodies           \
        xfce4-panel             \
        xfce4-pulseaudio-plugin \
        remmina                 \
        remmina-plugin-vnc      \
        remmina-plugin-rdp      \
    && sed -i 's/use_compositing=true/use_compositing=false/g' /usr/share/xfwm4/defaults \
    && snap install firefox

# Fix XFCE visual glitches on connect
if ! grep -qx '# XFCE-Glitches-Fix' /home/${user}/.xinitrc; then
    echo '#!/bin/bash
# XFCE-Glitches-Fix
/usr/bin/xfconf-query -c xfce4-session -p /shutdown/LockScreen -s false
/usr/bin/xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/lock-screen-suspend-hibernate -s false
/usr/bin/xfconf-query -c xfwm4 -p /general/use_compositing -s false

# Disable Screen Saver
xset -dpms; xset s off' \
        >> /home/${user}/.xinitrc
fi
chmod +x /home/${user}/.xinitrc
chown ${user}:${user} /home/${user}/.xinitrc

# Fix DBUS Address
if ! grep -qx 'DBUS_SESSION_BUS_ADDRESS=' /home/${user}/.profile; then
    echo 'export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"' >> /home/${user}/.profile
fi

# Install No-Machine
ARCH=$(dpkg --print-architecture)

BASE_NOMACHINE_DOWNLOAD_URL="https://downloads.nomachine.com/download/?id=5"

# Workaround to retrieve the latest NoMachine server version
_request=$(wget $BASE_NOMACHINE_DOWNLOAD_URL -q -O -)
_download_link=$(echo $_request | grep -o 'link_download.*' | grep -o 'href.*' | awk -F '"' '{print $2}')
_latest_nx_version=$(echo $_download_link | grep -oE '[0-9]+.[0-9]+.[0-9]+_[0-9]+')

NOMACHINE_VERSION_MAJOR=$(echo $_latest_nx_version | awk -F '.' '{print $1 "." $2}')
NOMACHINE_VERSION="$NOMACHINE_VERSION_MAJOR.`echo $_latest_nx_version | awk -F '.' '{print $NF}'`"
if [[ "echo $(dpkg-query --showformat='$${Version}' --show nomachine) | tr - _" != $NOMACHINE_VERSION ]]; then
    apt-get remove nomachine

    mkdir -p /home/${user}/.nx/config
    cp -p /home/${user}/.ssh/authorized_keys  /home/${user}/.nx/config/authorized.crt
    chown -R ${user}:${user} /home/${user}/.nx/

    DEB_NAME="/tmp/nomachine.deb"
    if [[ $ARCH == arm* ]]; then
        wget https://download.nomachine.com/download/$NOMACHINE_VERSION_MAJOR/Arm/nomachine_$${NOMACHINE_VERSION}_$${ARCH}.deb -O $DEB_NAME
    else
        wget https://download.nomachine.com/download/$NOMACHINE_VERSION_MAJOR/$(uname -s)/nomachine_$${NOMACHINE_VERSION}_$${ARCH}.deb -O $DEB_NAME
    fi
    dpkg --force-confdef -i $DEB_NAME
fi

# Update No-Machine config
update_nx_conf_file () {
    local FILE="/usr/NX/etc/server.cfg"
    local PATTERN=$${2}
    local VALUE=$${3}

    grep -q "$${PATTERN} " $${FILE}                                                           \
        && sed -i "/$${PATTERN} /s/#//g; s/$${PATTERN} .*/$${PATTERN} \"$${VALUE}\"/g" $${FILE}  \
        || echo "$${PATTERN} $${VALUE}" >> $${FILE}
}

update_nx_conf_file DisablePersistentSession all
/usr/NX/bin/nxserver --restart
