mkdir -p /home/${user}/Shared-Folder
echo "//$storage_account_name.file.core.windows.net/$storage_share_name /home/$user/Shared-Folder cifs vers=3.0,dir_mode=0777,file_mode=0777,serverino,username=$storage_account_name,password=$primary_access_key" >> /etc/fstab
mount -a
chown ${user}:${user} /home/${user}/Shared-Folder
