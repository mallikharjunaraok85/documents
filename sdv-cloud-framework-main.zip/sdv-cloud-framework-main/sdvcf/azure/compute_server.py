from importlib.resources import as_file, files
from typing import Any, List

from .base_workbench import AzureBaseWorkbench


class AzureComputeServer(AzureBaseWorkbench):
    """
    Represents an Azure Compute Server resource within the Azure workbench context.

    This class provides the creation and setup of a compute server on Azure, utilizing user data scripts
    to configure the server during the initialization phase.

    Inherits from AzureBaseWorkbench.

    Properties:
        exposed_ports:
            Returns a list of exposed ports on the compute server.
    """

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)

        with as_file(files(self.SCRIPTS_MODULE).joinpath(f"{self.SCRIPTS_PATH_PREFIX}/common.sh")) as file:
            self.AddUserDataFile(file)
        with as_file(files(self.SCRIPTS_MODULE).joinpath(f"{self.SCRIPTS_PATH_PREFIX}/compute-server.sh")) as file:
            self.AddUserDataFile(
                file,
                {
                    "user": self.user.name,
                    "default_password": self.DEFAULT_WB_PASSWORD,
                    "auto_stop_minutes": str(self.props.auto_stop_minutes),
                },
            )
        with as_file(files(self.SCRIPTS_MODULE).joinpath(f"{self.SCRIPTS_PATH_PREFIX}/sf-mount.sh")) as file:
            self.AddUserDataFile(
                file,
                {
                    "user": self.user.name,
                    "storage_account_name": self.user.cloud.GetStorageAccount().name,
                    "storage_share_name": self.user.storage_share.name,
                    "primary_access_key": self.user.cloud.GetStorageAccount().primary_access_key,
                },
            )

    @property
    def exposed_ports(self) -> List[int]:
        """
        A property that lists the network ports exposed by the compute server.

        For the compute server, typically only the SSH port is exposed for remote access.

        Returns:
            List[int]:
                A list of integers representing the exposed port numbers.
        """
        SSH_PORT: int = 22

        return [SSH_PORT]
