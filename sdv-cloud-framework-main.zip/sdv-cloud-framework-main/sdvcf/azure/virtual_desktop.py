from importlib.resources import as_file, files
from typing import Any, List

from .compute_server import AzureComputeServer


class AzureVirtualDesktop(AzureComputeServer):
    """
    Represents a Virtual Desktop Workbench on Azure, extending the functionality of an Azure compute server.

    This class initializes an Azure virtual desktop with user data and specifies the ports that need
    to be exposed for remote desktop access.

    Properties:
        exposed_ports:
            A property that returns a list of ports that should be exposed by the virtual desktop.
    """

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)

        with as_file(files(self.SCRIPTS_MODULE).joinpath(f"{self.SCRIPTS_PATH_PREFIX}/virtual-desktop.sh")) as file:
            self.AddUserDataFile(file, {"user": self.user.name})

    @property
    def exposed_ports(self) -> List[int]:
        """
        A property that returns a list of ports to be exposed by the virtual desktop instance.

        The default port for NoMachine remote desktop access is appended to the list of ports exposed by
        the superclass (AzureComputeServer).

        Returns:
            List[int]:
                A list of integer ports, including the default NoMachine remote desktop port plus
                any additional ports exposed by the superclass.
        """

        NOMACHINE_PORT: int = 4000

        return super().exposed_ports + [NOMACHINE_PORT]
