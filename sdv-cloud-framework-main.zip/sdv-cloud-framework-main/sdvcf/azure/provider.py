import hashlib
from typing import Any, List, Optional

from azure.identity import DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.subscription import SubscriptionClient
from cdktf import TerraformBackend, Token
from cdktf_cdktf_provider_azuread import provider as azuread_provider
from cdktf_cdktf_provider_azurerm import provider as azurerm_provider
from cdktf_cdktf_provider_azurerm.data_azurerm_client_config import (
    DataAzurermClientConfig,
)
from cdktf_cdktf_provider_azurerm.data_azurerm_subscription import (
    DataAzurermSubscription,
)
from cdktf_cdktf_provider_azurerm.provider import AzurermProviderFeatures
from constructs import Construct

from sdvcf.interface import ICloudProvider, IProvider

from .azurerm_managed_backend import AzurermManagedBackend
from .submodules.azapi.provider import AzapiProvider
from .utils import AzureUtils


class AzureProvider(ICloudProvider):
    """
    Represents the location of the provider.

    Args:
        scope (Construct): The scope of the provider.
        ns (str): The namespace of the provider.
        region (str): The location of the provider.
        **_ (Any): Additional arguments.

    Attributes:
        location (str): The location of the provider.
        _subscription (Optional[DataAzurermSubscription]): The Azure subscription.
        _subscription_client: (Optional[SubscriptionClient]): The Azure subscription client.
        _instance_types: (Optional[List[Any]]): List of Azure VM type objects.
        _credential: (Optional[DefaultAzureCredential]): The Azure credential.
        _client_config (Optional[DataAzurermClientConfig]): The Azure client configuration.
    """

    location: str

    _subscription: Optional[DataAzurermSubscription]
    _subscription_client: Optional[SubscriptionClient]
    _instance_types: Optional[List[Any]]
    _credential: Optional[DefaultAzureCredential]
    _client_config: Optional[DataAzurermClientConfig]

    def __init__(
        self,
        scope: Construct,
        ns: str,
        region: str,
        **_: Any,
    ):
        self.location = region

        self._subscription_client = None
        self._instance_types = None
        self._credential = None

        super().__init__(scope, ns)

        self._subscription = None
        self._client_config = None

        azurerm_provider.AzurermProvider(self, f"{ns}-azurerm", features=Token.as_any(AzurermProviderFeatures()))
        azuread_provider.AzureadProvider(self, f"{ns}-azuread")
        AzapiProvider(self, f"{ns}-azapi")

    def _SetupBackend(self, provider: Optional[IProvider] = None) -> TerraformBackend:
        """
        Set up the backend for the provider.

        Args:
            provider (Optional[IProvider]): The provider to set up the backend for.

        Returns:
            TerraformBackend: The configured backend.
        """

        # Get the first enabled subscription ID from the default Azure credentials
        subscription_id = str(
            [sub.subscription_id for sub in self.subscription_client.subscriptions.list() if sub.state == "Enabled"][0]
        )

        unique_seed = hashlib.shake_256(f"{self.name}{subscription_id}".encode("utf8")).hexdigest(128)
        prefix = f"sdvcf-{unique_seed}"
        container_name = AzureUtils.blobContainerName(f"{prefix[:10]}-{self.name}")
        key = AzureUtils.blobContainerName(f"{prefix[:10]}-{provider.name}") if provider else container_name

        return AzurermManagedBackend(
            provider or self,
            container_name=container_name,
            key=f"{key}.terraform.tfstate",
            storage_account_name=AzureUtils.storageAccountName(prefix),
            resource_group_name=AzureUtils.resourceGroupName(f"{self.name}-service-rg"),
            location=self.location,
        )

    @property
    def credential(self) -> DefaultAzureCredential:
        if self._credential is None:
            self._credential = DefaultAzureCredential()
        return self._credential

    @property
    def subscription_client(self) -> SubscriptionClient:
        if self._subscription_client is None:
            self._subscription_client = SubscriptionClient(self.credential)
        return self._subscription_client

    @property
    def instance_types(self) -> List[Any]:
        if self._instance_types is None:
            subscription_iter = self.subscription_client.subscriptions.list()
            [subscription] = [subscription for subscription in list(subscription_iter)]
            compute_client = ComputeManagementClient(self.credential, str(subscription.subscription_id))
            self._instance_types = list(compute_client.virtual_machine_sizes.list(self.location))
        return self._instance_types

    @property
    def subscription(self) -> DataAzurermSubscription:
        """
        Get the Azure subscription.

        Returns:
            DataAzurermSubscription: The Azure subscription.
        """
        if self._subscription is None:
            self._subscription = DataAzurermSubscription(
                self,
                f"{self.name}-subscription",
            )
        return self._subscription

    @property
    def client_config(self) -> DataAzurermClientConfig:
        """
        Get the Azure client configuration.

        Returns:
            DataAzurermClientConfig: The Azure client configuration.
        """
        if self._client_config is None:
            self._client_config = DataAzurermClientConfig(self, f"{self.name}-azurerm-client-config")
        return self._client_config

    def CommitDashboard(self) -> None:
        """
        TODO: FIXME
        Commit the dashboard. MOCK function.
        """
        pass
