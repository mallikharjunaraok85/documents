from base64 import urlsafe_b64encode
from importlib.resources import as_file, files
from os import urandom
from typing import Any, List, Optional

from cdktf import Fn
from cdktf_cdktf_provider_azuread.app_role_assignment import AppRoleAssignment
from cdktf_cdktf_provider_azuread.application_api_access import ApplicationApiAccess
from cdktf_cdktf_provider_azuread.application_owner import ApplicationOwner
from cdktf_cdktf_provider_azuread.application_password import ApplicationPasswordA
from cdktf_cdktf_provider_azuread.application_redirect_uris import (
    ApplicationRedirectUris,
)
from cdktf_cdktf_provider_azuread.application_registration import (
    ApplicationRegistration,
)
from cdktf_cdktf_provider_azuread.data_azuread_application_published_app_ids import (
    DataAzureadApplicationPublishedAppIds,
)
from cdktf_cdktf_provider_azuread.data_azuread_service_principal import (
    DataAzureadServicePrincipal,
)
from cdktf_cdktf_provider_azuread.service_principal import ServicePrincipal
from cdktf_cdktf_provider_azuread.service_principal_delegated_permission_grant import (
    ServicePrincipalDelegatedPermissionGrant,
)
from cdktf_cdktf_provider_azurerm.application_gateway import (
    ApplicationGateway,
    ApplicationGatewayBackendAddressPool,
    ApplicationGatewayBackendHttpSettings,
    ApplicationGatewayFrontendIpConfiguration,
    ApplicationGatewayFrontendPort,
    ApplicationGatewayGatewayIpConfiguration,
    ApplicationGatewayHttpListener,
    ApplicationGatewayProbe,
    ApplicationGatewayProbeMatch,
    ApplicationGatewayRequestRoutingRule,
    ApplicationGatewaySku,
    ApplicationGatewaySslCertificate,
)
from cdktf_cdktf_provider_azurerm.network_interface_application_gateway_backend_address_pool_association import (
    NetworkInterfaceApplicationGatewayBackendAddressPoolAssociation,
)
from cdktf_cdktf_provider_azurerm.public_ip import PublicIp

from sdvcf.tags import Tags

from .base_workbench import AzureWorkbenchProps
from .compute_server import AzureComputeServer
from .enums import SubnetType
from .provider import AzureProvider
from .utils import AzureUtils


class AzureCodeServer(AzureComputeServer):
    """
    Represents a Code Server Workbench on Azure, extending the functionality of an Azure compute server.

    This class orchestrates the setup of an Azure Code Server within a Docker environment, along with configuring
    the OAuth2_proxy server and Nginx for SSL offloading.

    Properties:
        exposed_ports:
            A property that returns a list of ports that should be exposed by the Code Server.
    """

    provider: AzureProvider
    props: AzureWorkbenchProps

    # Private static class attributes
    _application_publisher_ids: Optional[DataAzureadApplicationPublishedAppIds] = None
    _msgraph_service_principal: Optional[DataAzureadServicePrincipal] = None

    # Private class attributes
    _application_registration: Optional[ApplicationRegistration]
    _application_password: Optional[ApplicationPasswordA]
    _application_gateway: Optional[ApplicationGateway]
    _public_ip: Optional[PublicIp]

    def __init__(self, **kwargs: Any):
        super().__init__(**kwargs)

        self._application_registration = None
        self._application_password = None
        self._application_gateway = None
        self._public_ip = None

        self.application_gateway

        with as_file(files(self.SCRIPTS_MODULE).joinpath(f"{self.SCRIPTS_PATH_PREFIX}/code_server.sh")) as file:

            self.AddUserDataFile(
                file,
                {
                    "PLATFORM": self.props.cpu_arch,
                    "USER": self.user.name,
                    "EMAIL_DOMAIN": self.user.props.domain,
                    "AVAILABLE_EMAIL": self.user.name + "@" + self.user.props.domain,
                    "COOKIE_SECRET": self.generate_cookie_secret(),
                    "TENANT_ID": self.provider.client_config.tenant_id,
                    "CLIENT_ID": self.application_registration.client_id,
                    "CLIENT_SECRET": self.application_password.value,
                    "REDIRECT_URI": Fn.join("", ["https://", self.public_ip.ip_address]),
                },
            )

    @property
    def exposed_ports(self) -> List[int]:
        """
        ...

        Returns:
            List[int]:
                A list of integer ports
        """

        HTTP_PORT: int = 80

        return super().exposed_ports + [HTTP_PORT]

    @property
    def endpoint(self) -> str:
        return f"https://{self.public_ip.ip_address}"

    def generate_cookie_secret(self) -> str:
        return urlsafe_b64encode(urandom(32)).decode()

    @property
    def public_ip(self) -> PublicIp:

        public_ip_name = AzureUtils.publicIPName(f"{self.NAME_PREFIX}-pip")
        if self._public_ip is None:
            self._public_ip = PublicIp(
                self,
                public_ip_name,
                name=public_ip_name,
                location=self.cloud.resource_group.location,
                resource_group_name=self.cloud.resource_group.name,
                sku="Standard",
                allocation_method="Static",
                tags=Tags(self, public_ip_name).to_dict,
            )
        return self._public_ip

    @property
    def application_gateway(self) -> ApplicationGateway:

        application_gateway_name = f"{self.NAME_PREFIX}-application-gateway"
        backend_address_pool_name = f"{self.NAME_PREFIX}-backend"
        backend_http_settings_name = f"{self.NAME_PREFIX}-backend-settings"
        ssl_certificate_name = f"{self.NAME_PREFIX}-ssl-certificate"
        http_listener_name = f"{self.NAME_PREFIX}-http-listener"
        frontend_ip_configuration_name = f"{self.NAME_PREFIX}-fe-ip-conf"
        frontend_port_name = f"{self.NAME_PREFIX}-fe-port"
        probe_name = f"{self.NAME_PREFIX}-probe"
        request_routing_rule_name = f"{self.NAME_PREFIX}-routing-rule"

        if self._application_gateway is None:

            self._application_gateway = ApplicationGateway(
                self,
                application_gateway_name,
                name=application_gateway_name,
                location=self.cloud.resource_group.location,
                resource_group_name=self.cloud.resource_group.name,
                frontend_ip_configuration=[
                    ApplicationGatewayFrontendIpConfiguration(
                        name=frontend_ip_configuration_name, public_ip_address_id=self.public_ip.id
                    ),
                ],
                sku=ApplicationGatewaySku(name="Standard_v2", tier="Standard_v2", capacity=1),
                gateway_ip_configuration=[
                    ApplicationGatewayGatewayIpConfiguration(
                        name=f"{self.NAME_PREFIX}-gtw-ip-configuration",
                        subnet_id=self.cloud.subnets[SubnetType.AppGateway].id,
                    )
                ],
                frontend_port=[ApplicationGatewayFrontendPort(name=frontend_port_name, port=443)],
                backend_address_pool=[ApplicationGatewayBackendAddressPool(name=backend_address_pool_name)],
                backend_http_settings=[
                    ApplicationGatewayBackendHttpSettings(
                        name=backend_http_settings_name,
                        cookie_based_affinity="Disabled",
                        path="/",
                        port=80,
                        protocol="Http",
                        probe_name=probe_name,
                        request_timeout=20,
                    )
                ],
                ssl_certificate=[
                    ApplicationGatewaySslCertificate(
                        name=ssl_certificate_name, key_vault_secret_id=self.user.ssl_certificate.secret_id
                    )
                ],
                http_listener=[
                    ApplicationGatewayHttpListener(
                        name=http_listener_name,
                        frontend_ip_configuration_name=frontend_ip_configuration_name,
                        frontend_port_name=frontend_port_name,
                        protocol="Https",
                        ssl_certificate_name=ssl_certificate_name,
                    )
                ],
                probe=[
                    ApplicationGatewayProbe(
                        name=probe_name,
                        protocol="Http",
                        host="127.0.0.1",
                        path="/",
                        interval=30,
                        timeout=30,
                        unhealthy_threshold=3,
                        match=ApplicationGatewayProbeMatch(status_code=["200-499"]),
                    )
                ],
                identity={"type": "UserAssigned", "identity_ids": [self.user.managed_identity.id]},
                request_routing_rule=[
                    ApplicationGatewayRequestRoutingRule(
                        name=request_routing_rule_name,
                        priority=10,
                        rule_type="Basic",
                        http_listener_name=http_listener_name,
                        backend_address_pool_name=backend_address_pool_name,
                        backend_http_settings_name=backend_http_settings_name,
                    )
                ],
            )

        NetworkInterfaceApplicationGatewayBackendAddressPoolAssociation(
            self,
            f"{self.NAME_PREFIX}-app-gtw-association",
            ip_configuration_name=self.network_interface.ip_configuration.get(0).name,
            network_interface_id=self.network_interface.id,
            backend_address_pool_id=self._application_gateway.backend_address_pool.get(0).id,
        )

        return self._application_gateway

    @property
    def application_publisher_ids(self) -> DataAzureadApplicationPublishedAppIds:
        """
        Returns the AzureAD Application published ids.

        Returns:
            DataAzureadServicePrincipal: TF data source of the Application Published App Ids.
        """
        if self.__class__._application_publisher_ids is None:
            self.__class__._application_publisher_ids = DataAzureadApplicationPublishedAppIds(
                self, f"{self.NAME_PREFIX}-data-application-publisher-ids-vscode-server"
            )
        return self.__class__._application_publisher_ids

    @property
    def msgraph_service_principal(self) -> DataAzureadServicePrincipal:
        """
        Returns the AzureAD Standard Service Principle MsGraph.

        Returns:
            DataAzureadServicePrincipal: TF data source of the service principal.
        """
        if self.__class__._msgraph_service_principal is None:
            self.__class__._msgraph_service_principal = DataAzureadServicePrincipal(
                self,
                f"{self.NAME_PREFIX}-msgraph-service-principal-vscode-server",
                client_id=self.application_publisher_ids.result.lookup("MicrosoftGraph"),
            )
        return self.__class__._msgraph_service_principal

    @property
    def application_registration(self) -> ApplicationRegistration:
        """
        Register an Azure AD App for AzureCodeServer.
        Add Group.Read.All permissions and grant it with admin consent

        Returns:
            Application: ...
        """
        if self._application_registration is None:
            self._application_registration = ApplicationRegistration(
                self,
                f"{self.NAME_PREFIX}-application-registration-vscode-server",
                display_name=f"{self.NAME_PREFIX}-vscode-server-application",
                sign_in_audience="AzureADMyOrg",
                requested_access_token_version=2,
            )

            ApplicationRedirectUris(
                self,
                f"{self.NAME_PREFIX}-app-redirect-uri",
                application_id=self._application_registration.id,
                type="Web",
                redirect_uris=[f"https://{self.public_ip.ip_address}/*"],
            )

            ApplicationApiAccess(
                self,
                f"{self.NAME_PREFIX}-app-api-access",
                application_id=self._application_registration.id,
                api_client_id=self.application_publisher_ids.result.lookup("MicrosoftGraph"),
                role_ids=[self.msgraph_service_principal.app_role_ids.lookup("Group.Read.All")],
                scope_ids=[self.msgraph_service_principal.oauth2_permission_scope_ids.lookup("User.Read")],
            )

            application_service_principal = ServicePrincipal(
                self,
                f"{self.NAME_PREFIX}-vscode-server-service-principal",
                client_id=self._application_registration.client_id,
                owners=[self.provider.client_config.object_id],
            )

            ApplicationOwner(
                self,
                f"{self.NAME_PREFIX}-vs-code-server-app-owner",
                application_id=self._application_registration.id,
                owner_object_id=self.user.user.object_id,
            )

            AppRoleAssignment(
                self,
                f"{self.NAME_PREFIX}-vscode-server-group-app-role-assignment",
                app_role_id=self.msgraph_service_principal.app_role_ids.lookup("Group.Read.All"),
                principal_object_id=application_service_principal.object_id,
                resource_object_id=self.msgraph_service_principal.object_id,
            )

            ServicePrincipalDelegatedPermissionGrant(
                self,
                f"{self.NAME_PREFIX}-vscode-server-delegated-permission-grant",
                service_principal_object_id=application_service_principal.object_id,
                resource_service_principal_object_id=self.msgraph_service_principal.object_id,
                claim_values=["User.Read"],
            )

        return self._application_registration

    @property
    def application_password(self) -> ApplicationPasswordA:
        """
        Add password credential associated with an application within Azure AD.

        Returns:
            ApplicationPasswordA: ...
        """
        if self._application_password is None:
            self._application_password = ApplicationPasswordA(
                self,
                f"{self.NAME_PREFIX}-application-password-vscode-server",
                application_id=self.application_registration.id,
            )

        return self._application_password
