import re


class AzureUtils:
    """
    Set of utility methods for working with Azure resources.
    """

    @staticmethod
    def resourceGroupName(name: str) -> str:
        """
        Cleans and formats the given name to comply with Azure resource group name rules.

        Args:
            name (str): The name to be cleaned and formatted.

        Returns:
            str: The cleaned and formatted name.

        Raises:
            None
        """
        # Between 1 and 90 characters long.
        # Alphanumerics, underscores, parentheses, hyphens, periods.
        # Can't end with period.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftresources

        name = re.sub(r"[^A-Za-z0-9.()_-]+", "", name).rjust(1, "0")[:90]
        if re.search(r"[.]$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def linuxVirtualMachineName(name: str) -> str:
        """
        Cleans and formats the given name to meet the requirements for a Linux virtual machine name in Azure.

        Args:
            name (str): The original name to be cleaned and formatted.

        Returns:
            str: The cleaned and formatted name that meets the requirements for a Linux virtual machine name in Azure.
        """
        # Between 1 and 64 characters long.
        # Can't use spaces, control characters, or these characters: ~!@#$%^&*()=+_[]{}\|;:.'",<>/?
        # Can't end with period or hyphen.

        name = re.sub(r"[\x00-\x1F ~!@#$%^&*()=+_[\]{}\\|;:.'\",<>/?]+", "", name).rjust(1, "0")[:64]
        if re.search(r"[.-]$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def storageAccountName(name: str) -> str:
        """
        Cleans and formats the given name to be a valid Azure Storage Account name.

        Storage account names must be between 3 and 24 characters in length and may contain numbers
        and lowercase letters only.

        Args:
            name (str): The name to be cleaned and formatted.

        Returns:
            str: The cleaned and formatted storage account name.

        References:
            - Azure Storage Account documentation:
              https://learn.microsoft.com/en-us/azure/storage/common/storage-account-overview#storage-account-name
        """
        return re.sub(r"[^a-z0-9]+", "", name.lower()).rjust(3, "0")[:24]

    @staticmethod
    def blobContainerName(name: str) -> str:
        """
        Cleans and formats the given name to be a valid Azure Blob Storage container name.

        Container names must start or end with a letter or number, and can contain only letters, numbers,
        and the hyphen/minus (-) character. Every hyphen/minus (-) character must be immediately preceded
        and followed by a letter or number; consecutive hyphens aren't permitted in container names.
        All letters in a container name must be lowercase.
        Container names must be from 3 through 63 characters long.

        Args:
            name (str): The name to be cleaned and formatted.

        Returns:
            str: The cleaned and formatted container name.

        References:
            - Azure Resource Manager documentation:
              https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftstorage
        """

        name = re.sub(r"[^a-z0-9.-]+", "", name)
        name = re.sub(r"-{2,}", "-", name).rjust(3, "0")[:63]
        if re.search(r"^[^0-9a-z]", name):
            name = "0" + name[1:]
        if re.search(r"[^0-9a-z]$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def virtualNetworkName(name: str) -> str:
        """
        Cleans and formats the given name to meet the requirements for a virtual network name in Azure.

        Args:
            name (str): The original name to be cleaned and formatted.

        Returns:
            str: The cleaned and formatted virtual network name.

        Raises:
            None
        """
        # Between 2 and 64 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork

        name = re.sub(r"[^A-Za-z0-9._-]+", "", name).rjust(2, "0")[:64]
        if re.search(r"^[^0-9A-Za-z]", name):
            name = "0" + name[1:]
        if re.search(r"[^0-9A-Za-z_]$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def subnetName(name: str) -> str:
        """
        Cleans and formats the given name to meet the requirements for a subnet name in Azure.

        Args:
            name (str): The original name to be cleaned and formatted.

        Returns:
            str: The cleaned and formatted subnet name.

        Raises:
            None
        """
        # Between 1 and 80 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork

        name = re.sub(r"[^A-Za-z0-9._-]+", "", name).rjust(1, "0")[:80]
        if re.search(r"^[^0-9A-Za-z]", name):
            name = "0" + name[1:]
        if re.search(r"[^0-9A-Za-z_]$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def securityGroupName(name: str) -> str:
        """
        Generates a valid security group name based on the given name.

        Args:
            name (str): The base name for the security group.

        Returns:
            str: The generated security group name.

        Raises:
            None

        References:
            - Azure Resource Manager documentation:
              https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork
        """

        # Between 1 and 80 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork
        return AzureUtils.subnetName(name)

    @staticmethod
    def networkInterfaceName(name: str) -> str:
        """
        Generates a valid network interface name based on the given input.

        Args:
            name (str): The input name to generate the network interface name from.

        Returns:
            str: The generated network interface name.

        Raises:
            None

        References:
            - Azure Resource Manager documentation:
              https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork
        """

        # Between 1 and 80 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork

        return AzureUtils.subnetName(name)

    @staticmethod
    def localNetworkGatewayName(name: str) -> str:
        """
        Generates a valid local network gateway name based on the given input.

        Args:
            name (str): The input name to generate the local network gateway name from.

        Returns:
            str: The generated local network gateway name.

        Raises:
            None

        Notes:
            The generated name will be between 1 and 80 characters long and will only contain
            alphanumerics, underscores, periods, and hyphens. The name will start with an alphanumeric
            character and end with either an alphanumeric character or an underscore.

            For more information on Azure resource name rules, refer to:
            https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork
        """
        # Between 1 and 80 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork

        return AzureUtils.subnetName(name)

    @staticmethod
    def virtualNetworkGatewayName(name: str) -> str:
        """
        Generates a valid name for a virtual network gateway based on the given name.

        Args:
            name (str): The base name for the virtual network gateway.

        Returns:
            str: A valid name for the virtual network gateway.

        Raises:
            None

        Examples:
            >>> virtualNetworkGatewayName("my_gateway")
            'my_gateway'
            >>> virtualNetworkGatewayName("my-gateway")
            'my-gateway'
            >>> virtualNetworkGatewayName("my.gateway")
            'my.gateway'
        """
        # Between 1 and 80 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork

        return AzureUtils.subnetName(name)

    @staticmethod
    def virtualNetworkGatewayConnectionName(name: str) -> str:
        """
        Generates a valid name for a virtual network gateway connection.

        Args:
            name (str): The base name for the connection.

        Returns:
            str: A valid name for the virtual network gateway connection.

        Raises:
            None

        Notes:
            The generated name will be between 1 and 80 characters long and can only contain
            alphanumerics, underscores, periods, and hyphens. The name must start with an
            alphanumeric character and end with either an alphanumeric character or an underscore.

            For more information on Azure resource name rules, refer to the following documentation:
            https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork
        """
        # Between 1 and 80 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork

        return AzureUtils.subnetName(name)

    @staticmethod
    def virtualNetworkPeeringName(name: str) -> str:
        """
        Generates a valid virtual network peering name based on the given input name.

        Args:
            name (str): The input name to generate the virtual network peering name from.

        Returns:
            str: The generated virtual network peering name.

        Raises:
            None

        Notes:
            The generated virtual network peering name follows the following rules:
            - Between 1 and 80 characters long.
            - Alphanumerics, underscores, periods, and hyphens are allowed.
            - Must start with an alphanumeric character.
            - Must end with an alphanumeric character or underscore.

        References:
            - Azure Resource Manager documentation:
              https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork
        """
        # Between 1 and 80 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork

        return AzureUtils.subnetName(name)

    @staticmethod
    def publicIPName(name: str) -> str:
        """
        Generate a valid name for a public IP address in Azure.

        Args:
            name (str): The desired name for the public IP address.

        Returns:
            str: A valid name for a public IP address in Azure.

        Raises:
            None
        """
        # Between 1 and 80 characters long.
        # Alphanumerics, underscores, periods, and hyphens.
        # Start with alphanumeric. End alphanumeric or underscore.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftnetwork

        return AzureUtils.subnetName(name)

    @staticmethod
    def keyVaultName(name: str) -> str:
        """
        Cleans and formats the given name to meet the requirements for a Key Vault name in Azure.

        Args:
            name (str): The name to be cleaned and formatted.

        Returns:
            str: The cleaned and formatted name.

        Raises:
            None
        """
        # Between 3 and 24 characters long.
        # Alphanumerics and hyphens.
        # Start with letter. End with letter or digit. Can't contain consecutive hyphens.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftkeyvault

        name = re.sub(r"[^A-Za-z0-9-]+", "", name)
        name = re.sub(r"-{2,}", "-", name).rjust(3, "0")[:24]
        if re.search(r"^[^A-Za-z]", name):
            name = "a" + name[1:]
        if re.search(r"[^0-9A-Za-z]$", name):
            name = name[:-1] + "0"
        return name

    @staticmethod
    def keyVaultSecretName(name: str) -> str:
        """
        Cleans up the given name and returns a valid Key Vault secret name.

        Args:
            name (str): The name to be cleaned up.

        Returns:
            str: The cleaned up name, which is a valid Key Vault secret name.

        Raises:
            None

        Notes:
            - The name should be between 1 and 127 characters long.
            - Only alphanumeric characters and hyphens are allowed.
            - For more information, refer to the Microsoft documentation on resource name rules for Key Vault.
              (https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftkeyvault)
        """
        # Between 1 and 127 characters long.
        # Alphanumerics and hyphens.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftkeyvault

        return re.sub(r"[^A-Za-z0-9-]+", "", name).rjust(1, "0")[:127]

    @staticmethod
    def storageShareName(name: str) -> str:
        """ """
        # Between 3 and 63 characters long.
        # Lowercase letters, numbers, and hyphens.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftstorage

        return re.sub(r"[^a-z0-9_]+", "", name).rjust(3, "0")[:63]

    @staticmethod
    def storageContainerName(name: str) -> str:
        """ """
        # Between 3 and 63 characters long.
        # Lowercase letters, numbers, and hyphens.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftstorage

        return re.sub(r"[^a-z0-9_]+", "", name).rjust(3, "0")[:63]

    @staticmethod
    def containerRegistryName(name: str) -> str:
        """ """
        # Between 5 and 50 characters long.
        # Lowercase letters, numbers.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftcontainerregistry

        return re.sub(r"[^a-z0-9]+", "", name).rjust(5, "0")[:50]

    @staticmethod
    def managedIdentityName(name: str) -> str:
        # Between 3 and 128 characters long.
        # Alphanumerics, hyphens, and underscores
        # Start with letter or number.
        # https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-name-rules#microsoftmanagedidentity

        name = re.sub(r"[^A-Za-z0-9_-]+", "", name).rjust(3, "0")[:128]
        if re.search(r"^[^0-9A-Za-z]", name):
            name = "0" + name[1:]
        return name
