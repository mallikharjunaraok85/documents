from ipaddress import IPv4Network
from typing import Dict, List, Optional

from cdktf_cdktf_provider_azurerm.private_dns_zone import PrivateDnsZone
from cdktf_cdktf_provider_azurerm.resource_group import ResourceGroup
from cdktf_cdktf_provider_azurerm.storage_account import StorageAccount
from cdktf_cdktf_provider_azurerm.subnet import Subnet
from cdktf_cdktf_provider_azurerm.virtual_network import VirtualNetwork

from sdvcf.interface import IPrivateCloud, PrivateCloudProps
from sdvcf.tags import Tags

from .enums import StorageSKUType, SubnetType
from .provider import AzureProvider
from .utils import AzureUtils


class AzureRg(IPrivateCloud):
    """
    Represents an Azure resource group in a private cloud.

    Attributes:
        provider (AzureProvider): The Azure provider associated with the resource group.
        primary_subnet (Optional[Subnet]): The primary subnet of the resource group.
        _resource_group (Optional[ResourceGroup]): The underlying Azure resource group object.
        _virtual_network (Optional[VirtualNetwork]): The underlying Azure virtual network object.
        _storage_accounts (Dict[StorageSKUType, StorageAccount]): The dictionary of storage accounts associated with
                                                                  the resource group.
    """

    provider: AzureProvider

    primary_subnet: Optional[Subnet]
    app_gateway_subnet: Optional[Subnet]
    _resource_group: Optional[ResourceGroup]
    _virtual_network: Optional[VirtualNetwork]
    _storage_accounts: Dict[StorageSKUType, StorageAccount]
    _private_dns_zone: Optional[PrivateDnsZone]

    def __init__(self, ns: str, props: PrivateCloudProps):
        super().__init__(AzureProvider.Instance(), ns, props)

        self.primary_subnet = None
        self.app_gateway_subnet = None
        self._resource_group = None
        self._virtual_network = None
        self._storage_accounts = dict()
        self._private_dns_zone = None

    @property
    def resource_group(self) -> ResourceGroup:
        """
        Returns the resource group associated with the current object.

        If the resource group is not already initialized, it creates a new resource group
        with the specified name, location, and tags.

        Returns:
            ResourceGroup: The resource group object.
        """

        name = AzureUtils.resourceGroupName(f"{self.name}-rg")

        if self._resource_group is None:
            self._resource_group = ResourceGroup(
                self,
                f"{self.name}-rg",
                name=name,
                location=self.props.region,
                tags=Tags(self, self.name).to_dict,
            )
        return self._resource_group

    @property
    def private_dns_zone(self) -> PrivateDnsZone:
        if self._private_dns_zone is None:
            self._private_dns_zone = PrivateDnsZone(
                self,
                f"{self.name}-private-dns-zone",
                name="privatelink.blob.core.windows.net",
                resource_group_name=self.resource_group.name,
            )
        return self._private_dns_zone

    @property
    def virtual_network(self) -> VirtualNetwork:
        """
        Returns the virtual network associated with the resource group.

        Returns:
            VirtualNetwork: The virtual network object.
        """
        if self._virtual_network is None:
            self._virtual_network = VirtualNetwork(
                self,
                f"{self.name}-virtual-network",
                name=AzureUtils.virtualNetworkName(f"{self.name}-vnet"),
                location=self.resource_group.location,
                resource_group_name=self.resource_group.name,
                address_space=[self.cidr],
                tags=Tags(self, f"{self.name}-vnet").to_dict,
            )
        return self._virtual_network

    @property
    def subnets(self) -> Dict[str, Subnet]:
        """
        Retrieves the subnets associated with the resource group.
        The address_prefixes of the subnets are automatically deducted from the CIDR of the resource group.

        Returns:
            A dictionary containing the subnets, where the keys are the subnet types and the values are the Subnet
            objects.
        """
        cidr_network = IPv4Network(self.cidr)
        subnets_cidr_blocks = list(cidr_network.subnets(prefixlen_diff=4))
        subnets_cidr_used: List[IPv4Network] = []

        subnets_cidr_blocks.sort()

        def CreateSubnet(name: str) -> Subnet:
            """
            Creates a subnet with the given name.

            Args:
                name (str): The name of the subnet.

            Returns:
                Subnet: The created subnet object.

            Raises:
                RuntimeError: If failed to deduct the CIDR for the subnet or if the subnet CIDR is out of the VPC CIDR.
            """
            name = f"{name}_subnet"

            subnet_cidr: Optional[IPv4Network] = None
            if f"{name}_cidr" in self.props.network:
                subnet_cidr = IPv4Network(self.props.network[f"{name}_cidr"])
            else:
                for cidr in subnets_cidr_blocks:
                    if not any([cidr.overlaps(used) for used in subnets_cidr_used]):
                        subnet_cidr = cidr
                        break

            if subnet_cidr is None:
                raise RuntimeError(f"Failed to deduct `{name}` CIDR")
            elif not subnet_cidr.subnet_of(cidr_network):
                raise RuntimeError(f"Subnet CIDR `{subnet_cidr}` is out of VPC CIDR `{cidr_network}`")
            elif subnet_cidr in subnets_cidr_blocks:
                subnets_cidr_blocks.remove(subnet_cidr)
            subnets_cidr_used.append(subnet_cidr)

            # subnets_cidr_blocks.remove(subnet_cidr)

            return Subnet(
                self,
                name,
                name=AzureUtils.subnetName(name),
                resource_group_name=self.resource_group.name,
                virtual_network_name=self.virtual_network.name,
                address_prefixes=[str(subnet_cidr)],
            )

        if self.primary_subnet is None:
            self.primary_subnet = CreateSubnet(SubnetType.Primary)

        if self.app_gateway_subnet is None:
            self.app_gateway_subnet = CreateSubnet(SubnetType.AppGateway)

        return {SubnetType.Primary: self.primary_subnet, SubnetType.AppGateway: self.app_gateway_subnet}

    def GetStorageAccount(self, sku_type: StorageSKUType = StorageSKUType.StandardLRS) -> StorageAccount:
        """
        Retrieves or creates a storage account with the specified SKU type.

        Args:
            sku_type (StorageSKUType, optional): The SKU type of the storage account.
            Defaults to StorageSKUType.StandardLRS.

        Returns:
            StorageAccount: The storage account object.

        """
        name = AzureUtils.storageAccountName(f"{self.name}-{sku_type.name}")
        if sku_type not in self._storage_accounts:
            self._storage_accounts[sku_type] = StorageAccount(
                self,
                f"{self.name}-{sku_type.name}-storage-account",
                name=name,
                resource_group_name=self.resource_group.name,
                location=self.resource_group.location,
                account_tier=sku_type.tier,
                account_replication_type=sku_type.redundancy,
                tags=Tags(self, f"{self.name}-{sku_type.name}").to_dict,
            )
        return self._storage_accounts[sku_type]
