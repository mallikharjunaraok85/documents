import os
from enum import Enum
from ipaddress import IPv4Network
from typing import Any, List, NamedTuple, Optional, Union

from cdktf_cdktf_provider_azurerm.data_azurerm_resource_group import (
    DataAzurermResourceGroup,
)
from cdktf_cdktf_provider_azurerm.data_azurerm_subnet import DataAzurermSubnet
from cdktf_cdktf_provider_azurerm.data_azurerm_virtual_network import (
    DataAzurermVirtualNetwork,
)
from cdktf_cdktf_provider_azurerm.data_azurerm_virtual_network_gateway import (
    DataAzurermVirtualNetworkGateway,
)
from cdktf_cdktf_provider_azurerm.local_network_gateway import LocalNetworkGateway
from cdktf_cdktf_provider_azurerm.public_ip import PublicIp
from cdktf_cdktf_provider_azurerm.resource_group import ResourceGroup
from cdktf_cdktf_provider_azurerm.subnet import Subnet
from cdktf_cdktf_provider_azurerm.virtual_network import VirtualNetwork
from cdktf_cdktf_provider_azurerm.virtual_network_gateway import VirtualNetworkGateway
from cdktf_cdktf_provider_azurerm.virtual_network_gateway_connection import (
    VirtualNetworkGatewayConnection,
)
from cdktf_cdktf_provider_azurerm.virtual_network_peering import VirtualNetworkPeering

from sdvcf.interface import IVPN, IPrivateCloud, VpnProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .provider import AzureProvider
from .rg import AzureRg
from .utils import AzureUtils


class VNetGatewayType(str, Enum):
    """
    Represents the types of virtual network gateways in Azure.

    References:
        - https://learn.microsoft.com/en-us/azure/expressroute/expressroute-about-virtual-network-gateways#gateway-types
    """

    Vpn = "Vpn"
    ExpressRoute = "ExpressRoute"


class VPNGatewayType(NamedTuple("VPNGateway", [("generation", str), ("sku", str)]), Enum):
    """https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-gateway-settings#gwsku"""

    Basic = ("Generation1", "Basic")

    Gen1Gw1 = ("Generation1", "VpnGw1")
    Gen1Gw2 = ("Generation1", "VpnGw2")
    Gen1Gw3 = ("Generation1", "VpnGw3")
    Gen1Gw1AZ = ("Generation1", "VpnGw1AZ")
    Gen1Gw2AZ = ("Generation1", "VpnGw2AZ")
    Gen1Gw3AZ = ("Generation1", "VpnGw3AZ")

    Gen2Gw2 = ("Generation2", "VpnGw2")
    Gen2Gw3 = ("Generation2", "VpnGw3")
    # Gen2Gw4 = ('Generation2', 'VpnGw4')
    # Gen2Gw5 = ('Generation2', 'VpnGw5')
    Gen2Gw2AZ = ("Generation2", "VpnGw2AZ")
    Gen2Gw3AZ = ("Generation2", "VpnGw3AZ")
    # Gen2Gw4AZ = ('Generation2', 'VpnGw4AZ')
    # Gen2Gw5AZ = ('Generation2', 'VpnGw5AZ')


class VPNType(str, Enum):
    """https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-gateway-settings#vpntype"""

    PolicyBased = "PolicyBased"
    RouteBased = "RouteBased"


class VNetGatewayConnectionType(str, Enum):
    """https://learn.microsoft.com/en-us/rest/api/network-gateway/virtual-network-gateway-connections/create-or-update#virtualnetworkgatewayconnectiontype"""  # noqa: E501

    ExpressRoute = "ExpressRoute"
    IPsec = "IPsec"
    Vnet2Vnet = "Vnet2Vnet"


class VNetGatewayConnectionProtocol(str, Enum):
    """https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-compliance-crypto#about-ikev1-and-ikev2-for-azure-vpn-connections"""  # noqa: E501

    IKEv1 = "IKEv1"
    IKEv2 = "IKEv2"


class AzureVpnProps(VpnProps):
    vnet_gw_type: VNetGatewayType
    vpn_gw_type: VPNGatewayType
    vpn_type: VPNType

    dpd_timeout_seconds: int
    """ https://learn.microsoft.com/en-us/azure/vpn-gateway/ipsec-ike-policy-howto#cryptographic-algorithms--key-strengths """  # noqa: E501

    vnet_gw_con_type: VNetGatewayConnectionType
    vnet_gw_con_protocol: VNetGatewayConnectionProtocol
    cidr_nat: IPv4Network

    def __init__(
        self,
        vnet_gw_type: Optional[VNetGatewayType] = None,
        vpn_gw_type: Optional[VPNGatewayType] = None,
        vpn_type: Optional[VPNType] = None,
        dpd_timeout_seconds: Optional[int] = None,
        vnet_gw_con_type: Optional[VNetGatewayConnectionType] = None,
        vnet_gw_con_protocol: Optional[VNetGatewayConnectionProtocol] = None,
        cidr_nat: Optional[str] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self.vnet_gw_type = (
            vnet_gw_type or VNetGatewayType[os.getenv("AZURE_VNET_GATEWAY_TYPE", VNetGatewayType.Vpn.name)]
        )
        self.vpn_gw_type = vpn_gw_type or VPNGatewayType[os.getenv("AZURE_VPN_GATEWAY_TYPE", VPNGatewayType.Basic.name)]
        self.vpn_type = vpn_type or VPNType[os.getenv("AZURE_VPN_TYPE", VPNType.RouteBased.name)]
        self.dpd_timeout_seconds = dpd_timeout_seconds or int(os.getenv("AZURE_DPD_TIMEOUT", 45))
        self.vnet_gw_con_type = (
            vnet_gw_con_type
            or VNetGatewayConnectionType[
                os.getenv("AZURE_VNET_GATEWAY_CONNECTION_TYPE", VNetGatewayConnectionType.IPsec.name)
            ]
        )
        self.vnet_gw_con_protocol = (
            vnet_gw_con_protocol
            or VNetGatewayConnectionProtocol[
                os.getenv("AZURE_VNET_GATEWAY_CONNECTION_PROTOCOL", VNetGatewayConnectionProtocol.IKEv2.name)
            ]
        )
        self.cidr_nat = IPv4Network(cidr_nat or "10.255.255.0/24")


class AzureVpn(IVPN):
    RG_NAME = "common-vpn-rg"
    VNET_NAME = "common-vpn-vnet"
    VNET_GW_NAME = "common-vpn-vgw"
    GW_SUBNET_NAME = "GatewaySubnet"

    provider: AzureProvider
    props: AzureVpnProps

    # Static Class Attributes
    _resource_group: Optional[Union[DataAzurermResourceGroup, ResourceGroup]] = None
    _vnet: Optional[Union[DataAzurermVirtualNetwork, VirtualNetwork]] = None
    _gw_subnet: Optional[Union[DataAzurermSubnet, Subnet]] = None
    _vnet_gtw: Optional[Union[DataAzurermVirtualNetworkGateway, VirtualNetworkGateway]] = None
    _vnet_peerings: List[AzureRg] = []

    __vnet_name: Optional[str]

    def __init__(self, ns: str, props: AzureVpnProps):
        super().__init__(AzureProvider.Instance(), ns, props)

        self._resource_group = None
        self.__vnet_name = None
        self._vnet = None
        self._gw_subnet = None

        self._public_ip = None
        self._vnet_gtw = None

    @property
    def resource_group(self) -> Union[DataAzurermResourceGroup, ResourceGroup]:
        if self._resource_group is None:
            self._resource_group = DataAzurermResourceGroup(
                self, f"{self.name}-{self.RG_NAME}", name=AzureUtils.resourceGroupName(self.RG_NAME)
            )
        return self._resource_group

    @property
    def _vnet_name(self) -> str:
        if self.__vnet_name is None:
            self.__vnet_name = AzureUtils.virtualNetworkName(self.VNET_NAME)
        return self.__vnet_name

    @property
    def vnet(self) -> Union[DataAzurermVirtualNetwork, VirtualNetwork]:
        if self._vnet is None:
            self._vnet = DataAzurermVirtualNetwork(
                self,
                self._vnet_name,
                resource_group_name=self.resource_group.name,
                name=self._vnet_name,
            )
        return self._vnet

    @property
    def gw_subnet(self) -> Union[DataAzurermSubnet, Subnet]:
        if self._gw_subnet is None:
            self._gw_subnet = DataAzurermSubnet(
                self,
                f"{self.name}-{self.GW_SUBNET_NAME}",
                virtual_network_name=self.vnet.name,
                resource_group_name=self.resource_group.name,
                name=AzureUtils.subnetName(self.GW_SUBNET_NAME),
            )
        return self._gw_subnet

    @property
    def vnet_gtw(self) -> Union[DataAzurermVirtualNetworkGateway, VirtualNetworkGateway]:
        if self._vnet_gtw is None:
            vnet_gtw_name = AzureUtils.virtualNetworkGatewayName(self.VNET_GW_NAME)
            self._vnet_gtw = DataAzurermVirtualNetworkGateway(
                self,
                f"{self.name}-{self.VNET_GW_NAME}",
                name=vnet_gtw_name,
                resource_group_name=self.resource_group.name,
            )
        return self._vnet_gtw

    def Establish(
        self,
        device_ip_address: str,
        device_name: str = "",
    ) -> None:
        cidr_blocks = self.GetCidrBlocks()

        self._SetupEnvironment()

        local_network_gw = LocalNetworkGateway(
            self,
            f"{self.name}-{device_ip_address}-local-network-gw",
            name=AzureUtils.localNetworkGatewayName(f"{self.name}-{device_ip_address}-lgw"),
            location=self.resource_group.location,
            resource_group_name=self.resource_group.name,
            gateway_address=device_ip_address,
            address_space=cidr_blocks,
            tags=Tags(self, f"{device_ip_address}-lan-gw", {"Connection": self.name, "Device": device_name}).to_dict,
        )

        connection = VirtualNetworkGatewayConnection(
            self,
            f"{self.name}-{device_ip_address}-common-vgw-connection",
            name=AzureUtils.virtualNetworkGatewayConnectionName(f"{self.name}-{device_ip_address}-vgw-con"),
            location=self.resource_group.location,
            resource_group_name=self.resource_group.name,
            dpd_timeout_seconds=self.props.dpd_timeout_seconds,
            type=self.props.vnet_gw_con_type.value,
            connection_protocol=self.props.vnet_gw_con_protocol.value,
            enable_bgp=False,
            local_azure_ip_address_enabled=False,
            virtual_network_gateway_id=self.vnet_gtw.id,
            local_network_gateway_id=local_network_gw.id,
            tags=Tags(
                self, f"{device_ip_address}-vgw-connection", {"Connection": self.name, "Device": device_name}
            ).to_dict,
        )

        Output(
            self,
            id="vpn_connection_id",
            value=connection.id,
            resource_id=connection.id,
        )

    def _Attach(self, cloud: IPrivateCloud) -> None:
        assert isinstance(cloud, AzureRg)

        if cloud not in self.__class__._vnet_peerings:
            VirtualNetworkPeering(
                self,
                f"{cloud.name}-p2v_peering",
                name=AzureUtils.virtualNetworkPeeringName(f"{self.VNET_NAME}-to-{cloud.name}"),
                resource_group_name=cloud.resource_group.name,
                virtual_network_name=cloud.virtual_network.name,
                remote_virtual_network_id=self.vnet.id,
                allow_virtual_network_access=True,
                allow_forwarded_traffic=True,
                allow_gateway_transit=False,
                use_remote_gateways=True,
            )

            VirtualNetworkPeering(
                self,
                f"{cloud.name}-v2p_peering",
                name=AzureUtils.virtualNetworkPeeringName(f"{cloud.name}-to-{self.VNET_NAME}"),
                resource_group_name=self.resource_group.name,
                virtual_network_name=self.vnet.name,
                remote_virtual_network_id=cloud.virtual_network.id,
                allow_virtual_network_access=True,
                allow_forwarded_traffic=True,
                allow_gateway_transit=True,
                use_remote_gateways=False,
            )

            self.__class__._vnet_peerings.append(cloud)

    def _SetupEnvironment(self) -> None:
        if self.__class__._resource_group is None:
            self.__class__._resource_group = ResourceGroup(
                self.provider,
                self.RG_NAME,
                name=AzureUtils.resourceGroupName(self.RG_NAME),
                location=self.provider.location,
                tags=Tags(self.provider, self.RG_NAME).to_dict,
            )

        if self.__class__._vnet is None:
            self.__class__._vnet = VirtualNetwork(
                self.provider,
                self._vnet_name,
                name=self._vnet_name,
                location=self.resource_group.location,
                resource_group_name=self.resource_group.name,
                address_space=[str(self.props.cidr_nat)],
                tags=Tags(self, self._vnet_name).to_dict,
            )

        if self.__class__._gw_subnet is None:
            self.__class__._gw_subnet = Subnet(
                self.provider,
                f"{self.name}-{self.GW_SUBNET_NAME}",
                name=AzureUtils.subnetName(self.GW_SUBNET_NAME),
                resource_group_name=self.resource_group.name,
                virtual_network_name=self.vnet.name,
                address_prefixes=self.vnet.address_space,
            )

        if self.__class__._vnet_gtw is None:
            public_ip_name = AzureUtils.publicIPName(f"{self.name}-vgw-pip")
            public_ip = PublicIp(
                self.provider,
                public_ip_name,
                name=public_ip_name,
                location=self.resource_group.location,
                resource_group_name=self.resource_group.name,
                allocation_method="Dynamic",
                sku="Basic",
                tags=Tags(self, public_ip_name).to_dict,
            )

            vnet_gtw_name = AzureUtils.virtualNetworkGatewayName(self.VNET_GW_NAME)
            self.__class__._vnet_gtw = VirtualNetworkGateway(
                self.provider,
                vnet_gtw_name,
                name=vnet_gtw_name,
                location=self.resource_group.location,
                resource_group_name=self.resource_group.name,
                type=self.props.vnet_gw_type.value,
                vpn_type=self.props.vpn_type.value,
                active_active=False,
                enable_bgp=False,
                sku=self.props.vpn_gw_type.sku,
                generation=self.props.vpn_gw_type.generation,
                ip_configuration=[
                    {
                        "name": "default",
                        "publicIpAddressId": public_ip.id,
                        "privateIpAddressAllocation": "Dynamic",
                        "subnetId": self.gw_subnet.id,
                    }
                ],
                tags=Tags(self, vnet_gtw_name).to_dict,
            )
