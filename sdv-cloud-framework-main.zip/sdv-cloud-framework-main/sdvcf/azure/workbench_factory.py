from copy import deepcopy
from pathlib import Path
from re import match
from string import Template
from typing import Any, Dict, List, Optional

from croniter import (
    CroniterBadCronError,
    CroniterBadDateError,
    CroniterBadTypeRangeError,
    CroniterNotAlphaError,
    CroniterUnsupportedSyntaxError,
    croniter,
)

from sdvcf.interface import (
    IUser,
    IWorkbench,
    IWorkbenchFactory,
    WorkbenchCPUArch,
    WorkbenchCreationProps,
    WorkbenchType,
)

from .base_workbench import AzureWorkbenchProps
from .code_server import AzureCodeServer
from .compute_server import AzureComputeServer
from .provider import AzureProvider
from .user import AzureUser
from .virtual_desktop import AzureVirtualDesktop


class AzureVMRegexBuilder:
    """
    AzureVMRegexBuilder is a class for constructing regular expressions based on config input
    used to match Azure VM types.

    Attributes:
        SUPPORTED_VM_FAMILIES (List[str]): A list of supported VM families.

    Methods:
        build_regex: Constructs and returns the final regex pattern for Azure VM type.

    Private Methods:
        _generate_family_regex: Generates a regex pattern for supported VM families.
        _generate_cpu_count_regex: Generates a regex pattern for CPU count.
        _generate_cpu_arch_regex: Generates a regex pattern for CPU architecture.
    """

    SUPPORTED_VM_FAMILIES: List[str] = ["D"]
    AZURE_VM_TIER: str = "^Standard_"
    AZURE_VM_VERSION: str = "_v[0-9]+$"

    def __init__(self, props: WorkbenchCreationProps):
        self.props = props

    def _generate_family_regex(self) -> str:
        family_regex = "|".join(family for family in self.SUPPORTED_VM_FAMILIES)
        return f"[{family_regex}]"

    def _generate_cpu_count_regex(self) -> str:
        return f"[{self.props.vcpu}]"

    def _generate_cpu_arch_regex(self) -> str:
        cpu_arch_regex = "p[s]?" if self.props.cpu_arch == WorkbenchCPUArch.ARM64 else ""
        return f"{cpu_arch_regex}"

    def build_regex(self) -> str:
        regex_parts = [
            self.AZURE_VM_TIER,
            self._generate_family_regex(),
            self._generate_cpu_count_regex(),
            self._generate_cpu_arch_regex(),
            self.AZURE_VM_VERSION,
        ]
        return r"".join(regex_parts)


class AzureWorkbenchFactory(IWorkbenchFactory):
    """Factory for Azure Workbenches creation"""

    @classmethod
    def GetInstanceType(cls, user: IUser, props: WorkbenchCreationProps) -> str:
        """
        Determines the appropriate instance type for a workbench based on its configuration properties.

        Parameters:
            user (IUser):
                A User to obtain provider information
            props (WorkbenchCreationProps):
                An object containing the configuration properties of the workbench.

        Returns:
            str:
                Type of an instance which suits workbench properties.
        """

        assert isinstance(user.provider, AzureProvider)

        azure_vm_regex_builder = AzureVMRegexBuilder(props)
        instance_type_regex_pattern = azure_vm_regex_builder.build_regex()

        specified_instance_types = sorted(
            [
                vm_size.name
                for vm_size in user.provider.instance_types
                if match(instance_type_regex_pattern, vm_size.name) and vm_size.memory_in_mb == props.ram_gib * 1024
            ],
            key=lambda x: int(x.split("_v")[1]),
            reverse=True,
        )

        if not specified_instance_types:
            raise RuntimeError("Failed to find VM Sizes according to specification")

        return specified_instance_types[0]

    @classmethod
    def Create(cls, user: IUser, props: WorkbenchCreationProps) -> IWorkbench:
        assert isinstance(user, AzureUser)

        # TODO fix when backup introduced
        props.backup = cls.processBackupData(**props.backup)

        workbench: Optional[IWorkbench] = None
        if props.type == WorkbenchType.ComputeServer:
            workbench = AzureComputeServer(
                user=user,
                props=AzureWorkbenchProps(username=user.name, itype=cls.GetInstanceType(user, props), os=props.os),
            )
        elif props.type == WorkbenchType.VirtualDesktop:
            workbench = AzureVirtualDesktop(
                user=user,
                props=AzureWorkbenchProps(username=user.name, itype=cls.GetInstanceType(user, props), os=props.os),
            )
        elif props.type == WorkbenchType.WebIDE:
            workbench = AzureCodeServer(
                user=user,
                props=AzureWorkbenchProps(
                    username=user.name,
                    itype=cls.GetInstanceType(user, props),
                    os=props.os,
                    cpu_arch=props.cpu_arch.name,
                ),
            )
        else:
            raise NotImplementedError(f"`{props.type}` Workbench type is not supported yet")

        user_data_options = {
            "sdvcf_user": workbench.posix_username,
            "sdvcf_region": workbench.provider.location,
        }

        for script, parameters in props.blueprints.items():
            parameters_copy = deepcopy(parameters)
            if isinstance(parameters_copy, dict):
                for key, param in parameters_copy.items():
                    parameters_copy[key] = Template(param).safe_substitute(user_data_options)

            workbench.AddUserDataFile(Path(script), parameters_copy)

        # Initiate the VWorkbench cloud VM instance creation
        workbench.virtual_machine

        return workbench

    # TODO fix when backup introduced
    @staticmethod
    def processBackupData(
        schedule: str = "0 0 * * * *",
        retention_days: int = 30,
    ) -> Dict[str, Any]:
        """
        Configures a backup schedule for a specified workbench.

        Parameters:
            schedule (str):
                A CRON expression as a string that defines the backup schedule.
            retention_days (int):
                The number of days to retain the backups of the workbench.

        Returns:
            Dict: processed backup data dictionary
        """

        schedule_splitted = schedule.split(" ")
        schedule_splitted = ["0"] + schedule_splitted
        if len(schedule_splitted) == 7:
            schedule_splitted.pop()

        schedule = " ".join(schedule_splitted)

        try:
            croniter(schedule)
        except (
            CroniterBadCronError,
            CroniterBadDateError,
            CroniterBadTypeRangeError,
            CroniterNotAlphaError,
            CroniterUnsupportedSyntaxError,
        ) as error:
            raise ValueError(f"Invalid cron expression: {error}") from error

        return {
            "schedule": schedule,
            "retention_days": retention_days,
        }
