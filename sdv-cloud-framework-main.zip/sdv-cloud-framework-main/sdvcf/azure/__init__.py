"""
Azure SDVCF Provider

The AzurermManagedBackend class inherits from the AzurermBackend class and provides methods for creating and managing
the Azure storage account and container used for storing Terraform state.

Example usage:
    from sdvcf.azure.azurerm_managed_backend import AzurermManagedBackend

    backend = AzurermManagedBackend(
        scope=construct,
        resource_group_name="my-resource-group",
        container_name="my-container",
        key="my-storage-account-key",
        storage_account_name="my-storage-account",
        location="westus2"
    )

"""

from .azurerm_managed_backend import AzurermManagedBackend
from .base_workbench import AzureBaseWorkbench
from .code_server import AzureCodeServer
from .compute_server import AzureComputeServer
from .provider import AzureProvider
from .registry import AzureRegistry
from .rg import AzureRg
from .user import AzureUser, AzureUserProps
from .utils import AzureUtils
from .virtual_desktop import AzureVirtualDesktop
from .vpn import AzureVpn, AzureVpnProps
from .workbench_factory import AzureWorkbenchFactory

__all__ = [
    "AzureProvider",
    "AzurermManagedBackend",
    "AzureBaseWorkbench",
    "AzureComputeServer",
    "AzureVpnProps",
    "AzureVpn",
    "AzureRg",
    "AzureRegistry",
    "AzureUser",
    "AzureUserProps",
    "AzureUtils",
    "AzureVirtualDesktop",
    "AzureWorkbenchFactory",
    "AzureCodeServer",
]
