import os
from typing import Any, Dict, List, Optional

from cdktf import Fn
from cdktf_cdktf_provider_azurerm.linux_virtual_machine import LinuxVirtualMachine
from cdktf_cdktf_provider_azurerm.network_interface import NetworkInterface
from cdktf_cdktf_provider_azurerm.network_interface_security_group_association import (
    NetworkInterfaceSecurityGroupAssociation,
)
from cdktf_cdktf_provider_azurerm.network_security_group import NetworkSecurityGroup
from cdktf_cdktf_provider_azurerm.role_assignment import RoleAssignment
from cdktf_cdktf_provider_azurerm.user_assigned_identity import UserAssignedIdentity

from sdvcf.interface import IUser, IWorkbench, WorkbenchProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .enums import OsDiskCachingType, SecurityRule, StorageSKUType, SubnetType
from .provider import AzureProvider
from .rg import AzureRg
from .user import AzureUser
from .utils import AzureUtils


class AzureWorkbenchProps(WorkbenchProps):
    username: str
    cpu_arch: str
    subnet_type: SubnetType
    os_disk_caching: OsDiskCachingType
    os_disk_storage_account_type: StorageSKUType

    def __init__(
        self,
        username: Optional[str] = None,
        cpu_arch: Optional[str] = None,
        subnet_type: Optional[SubnetType] = None,
        os_disk_caching: Optional[OsDiskCachingType] = None,
        os_disk_storage_account_type: Optional[StorageSKUType] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self.username = username if username is not None else os.getenv("AZURE_WB_DEFAULT_USER_NAME", default="ubuntu")
        self.cpu_arch = cpu_arch if cpu_arch is not None else os.getenv("AZURE_WB_DEFAULT_CPU_ARCH", default="AMD64")
        self.subnet_type = subnet_type or SubnetType[os.getenv("AZURE_WB_DEFAULT_SUBNET_TYPE", SubnetType.Primary.name)]
        self.os_disk_caching = (
            os_disk_caching
            or OsDiskCachingType[os.getenv("AZURE_WB_STORAGE_CACHING_TYPE", OsDiskCachingType.ReadWrite.name)]
        )
        self.os_disk_storage_account_type = (
            os_disk_storage_account_type
            or StorageSKUType[os.getenv("AZURE_WB_STORAGE_ACCOUNT_TYPE", StorageSKUType.StandardLRS.name)]
        )


class AzureBaseWorkbench(IWorkbench):
    """Class that contains base resources for all Azure Workbench types"""

    # Public static class constants
    DEFAULT_WB_PASSWORD: str = "password"
    SKU_22_04_LTS_GEN2: str = "22_04-lts-gen2"
    SKU_22_04_LTS_ARM64: str = "22_04-lts-arm64"

    # Public class constants
    NAME_PREFIX: str
    SCRIPTS_MODULE: str
    SCRIPTS_PATH_PREFIX: str

    provider: AzureProvider
    cloud: AzureRg
    props: AzureWorkbenchProps
    user: AzureUser

    _network_security_group: Optional[NetworkSecurityGroup]
    _network_interface: Optional[NetworkInterface]
    _security_group_association: Optional[NetworkInterfaceSecurityGroupAssociation]
    _managed_identity: Optional[UserAssignedIdentity]
    _virtual_machine: Optional[LinuxVirtualMachine]
    _registry_policy_info: List[Dict[str, str]]

    def __init__(self, user: IUser, props: AzureWorkbenchProps):
        assert isinstance(user, AzureUser)
        super().__init__(user.cloud, f"{user.name}-{self.__class__.__name__.lower()}", props)

        self.NAME_PREFIX = f"{self.provider.name}-{self.name}"

        self.user = user

        self._network_security_group = None
        self._network_interface = None
        self._security_group_association = None
        self._managed_identity = None
        self._virtual_machine = None
        self._registry_policy_info = self.props.registry_policy_info

        self.SCRIPTS_MODULE = "sdvcf.azure.resources"
        self.SCRIPTS_PATH_PREFIX = "workbench/scripts/"

    @property
    def endpoint(self) -> str:
        """
        Get the endpoint URL of the virtual workbench.

        Returns:
            str: The endpoint URL.
        """
        return self.virtual_machine.private_ip_address

    @property
    def network_security_group(self) -> NetworkSecurityGroup:
        if self._network_security_group is None:
            name = AzureUtils.securityGroupName(f"{self.NAME_PREFIX}-network-security-group")
            self._network_security_group = NetworkSecurityGroup(
                self,
                name,
                name=name,
                location=self.cloud.region,
                resource_group_name=self.cloud.resource_group.name,
                security_rule=self._GetWBSecurityRules(self.props.ports, ingress_cidr_blocks=[self.cloud.cidr]),
                tags=Tags(self, name).to_dict,
            )
        return self._network_security_group

    @property
    def network_interface(self) -> NetworkInterface:
        if self._network_interface is None:
            name = AzureUtils.networkInterfaceName(f"{self.NAME_PREFIX}-network-interface")
            self._network_interface = NetworkInterface(
                self,
                name,
                name=name,
                location=self.cloud.region,
                resource_group_name=self.cloud.resource_group.name,
                ip_configuration=[
                    {
                        "name": f"{self.NAME_PREFIX}-ip",
                        "subnetId": self.cloud.subnets[self.props.subnet_type].id,
                        "privateIpAddressAllocation": "Dynamic",
                    }
                ],
                tags=Tags(self, name).to_dict,
            )
        return self._network_interface

    @property
    def security_group_association(self) -> NetworkInterfaceSecurityGroupAssociation:
        if self._security_group_association is None:
            self._security_group_association = NetworkInterfaceSecurityGroupAssociation(
                self,
                f"{self.NAME_PREFIX}-network-security-group-assosiation",
                network_interface_id=self.network_interface.id,
                network_security_group_id=self.network_security_group.id,
            )
        return self._security_group_association

    @property
    def managed_identity(self) -> UserAssignedIdentity:
        managed_identity_name = AzureUtils.managedIdentityName(f"{self.name}-managed-identity")
        if self._managed_identity is None:
            self._managed_identity = UserAssignedIdentity(
                self,
                managed_identity_name,
                name=managed_identity_name,
                resource_group_name=self.cloud.resource_group.name,
                location=self.cloud.resource_group.location,
            )
        return self._managed_identity

    @property
    def virtual_machine(self) -> LinuxVirtualMachine:
        if self._virtual_machine is None:
            name = AzureUtils.linuxVirtualMachineName(self.NAME_PREFIX)
            self._virtual_machine = LinuxVirtualMachine(
                self,
                name,
                name=name,
                location=self.cloud.region,
                resource_group_name=self.cloud.resource_group.name,
                network_interface_ids=[self.network_interface.id],
                size=self.props.itype,
                identity={"type": "UserAssigned", "identity_ids": [self.managed_identity.id]},
                os_disk={
                    "name": f"{self.NAME_PREFIX}-root-fs",
                    "caching": self.props.os_disk_caching.value,
                    "storage_account_type": (
                        f"{self.props.os_disk_storage_account_type.tier}"
                        "_"
                        f"{self.props.os_disk_storage_account_type.redundancy}"
                    ),
                    "disk_size_gb": self.props.disk_size,
                },
                source_image_reference={
                    "publisher": "Canonical",
                    "offer": "0001-com-ubuntu-server-jammy",
                    "sku": self.SKU_22_04_LTS_GEN2 if self.props.cpu_arch == "AMD64" else self.SKU_22_04_LTS_ARM64,
                    "version": "latest",
                },
                admin_username=self.props.username,
                disable_password_authentication=True,
                admin_ssh_key=[
                    {
                        "username": self.props.username,
                        "publicKey": self.user.GetSSHPublicKey(),
                    }
                ],
                custom_data=Fn.base64encode(self.user_data),
                tags=Tags(self, name).to_dict,
                depends_on=[self.security_group_association],
            )

            for reg in self._registry_policy_info:
                self._AttachRole(reg["policy_name"], reg["policy_id"])

            Output(
                self,
                id="username",
                value=self.virtual_machine.admin_username,
                resource_id=self._virtual_machine.id,
                user_name=self.user.user.display_name,
            )
            Output(
                self,
                id="password",
                value=self.DEFAULT_WB_PASSWORD,
                resource_id=self._virtual_machine.id,
                user_name=self.user.user.display_name,
            )
            Output(
                self,
                id="endpoint",
                value=self.endpoint,
                resource_id=self._virtual_machine.id,
                user_name=self.user.user.display_name,
            )
        return self._virtual_machine

    @property
    def id(self) -> str:
        return self.virtual_machine.id

    @staticmethod
    def _GetWBSecurityRules(
        ports: List[int],
        ingress_cidr_blocks: List[str],
        source_port_range: List[int] = [],
        destination_address_prefix: List[int] = [],
        direction: SecurityRule.Direction = SecurityRule.Direction.Inbound,
        access: SecurityRule.Access = SecurityRule.Access.Allow,
        protocol: SecurityRule.Protocol = SecurityRule.Protocol.TCP,
    ) -> List[Dict[str, Any]]:
        """Creates a list with security rules for workbench network interface ports
        https://learn.microsoft.com/en-us/azure/virtual-network/network-security-groups-overview#security-rules"""
        security_rules = []
        for idx, port in enumerate(ports):
            security_rules.append(
                {
                    "name": f"tcp-port-rule-{port}",
                    "priority": 4096 - idx,
                    "direction": direction.value,
                    "access": access.value,
                    "protocol": protocol.value,
                    "sourcePortRange": source_port_range or "*",
                    "destinationPortRange": str(port),
                    "sourceAddressPrefixes": ingress_cidr_blocks,
                    "destinationAddressPrefix": destination_address_prefix or "*",
                }
            )
        return security_rules

    def _AttachRole(self, name: str, role_id: str) -> None:
        """
        Attaches an IAM Role to the User Assigned Identity.

        Parameters:
            name (`str`):
                The name of the role.
            role_id (`str`):
                The id of the role.

        Returns:
            None:
                This method does not return any value.
        """
        RoleAssignment(
            self,
            f"{self.NAME_PREFIX}-{name}-policy-att",
            principal_id=self.managed_identity.principal_id,
            scope=self.cloud.GetStorageAccount().id,
            role_definition_id=role_id,
        )

        RoleAssignment(
            self,
            f"{self.NAME_PREFIX}-{name}-acr-policy-att",
            principal_id=self.managed_identity.principal_id,
            scope=self.cloud.resource_group.id,
            role_definition_name="ACR Repository Reader",
        )
