from enum import Enum
from typing import NamedTuple


class SubnetType(str, Enum):
    """Represents subnet type from the Azure Resource Group"""

    Primary = "primary"
    AppGateway = "appGateway"


class OsDiskCachingType(str, Enum):
    """https://learn.microsoft.com/en-us/powershell/module/servicemanagement/azure/set-azurevmimageosdiskconfig?view=azuresmps-4.0.0"""  # noqa: E501

    ReadWrite = "ReadWrite"
    ReadOnly = "ReadOnly"


class StorageSKUType(NamedTuple("SKUType", [("tier", str), ("redundancy", str)]), Enum):
    """https://learn.microsoft.com/en-us/rest/api/storagerp/srp_sku_types"""

    StandardLRS = ("Standard", "LRS")
    StandardGRS = ("Standard", "GRS")
    StandardRAGRS = ("Standard", "RAGRS")
    StandardZRS = ("Standard", "ZRS")
    StandardGZRS = ("Standard", "GZRS")
    StandardRAGZRS = ("Standard", "RAGZRS")
    PremiumLRS = ("Premium", "LRS")
    PremiumZRS = ("Premium", "ZRS")


class SecurityRule:
    """
    Represents a security rule in Azure Virtual Network.

    For more information, refer to the official documentation:
    https://learn.microsoft.com/en-us/azure/virtual-network/network-security-groups-overview#security-rules
    """

    class Direction(str, Enum):
        Inbound = "Inbound"
        Outbound = "Outbound"

    class Access(str, Enum):
        Allow = "Allow"
        Deny = "Deny"

    class Protocol(str, Enum):
        TCP = "Tcp"
        UDP = "Udp"
        ICMP = "Icmp"
        ANY = "Any"

        #  ESP and AH protocols aren't currently available via the Azure portal
        #  but can be used via ARM templates.
        ESP = "Esp"
        AH = "Ah"


class KeyVaultSkuName(str, Enum):
    """https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/key_vault#sku_name"""

    Standard = "standard"
