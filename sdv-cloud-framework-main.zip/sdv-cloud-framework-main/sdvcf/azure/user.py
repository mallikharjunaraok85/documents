import os
from enum import Enum
from typing import Any, Dict, NamedTuple, Optional, Union

from cdktf_cdktf_provider_azuread.data_azuread_user import DataAzureadUser
from cdktf_cdktf_provider_azuread.user import User
from cdktf_cdktf_provider_azurerm.key_vault import KeyVault, KeyVaultAccessPolicy
from cdktf_cdktf_provider_azurerm.key_vault_certificate import (
    KeyVaultCertificate,
    KeyVaultCertificateCertificatePolicy,
    KeyVaultCertificateCertificatePolicyKeyProperties,
    KeyVaultCertificateCertificatePolicyLifetimeAction,
    KeyVaultCertificateCertificatePolicySecretProperties,
    KeyVaultCertificateCertificatePolicyX509CertificateProperties,
)
from cdktf_cdktf_provider_azurerm.key_vault_secret import KeyVaultSecret
from cdktf_cdktf_provider_azurerm.ssh_public_key import SshPublicKey
from cdktf_cdktf_provider_azurerm.storage_share import StorageShare
from cdktf_cdktf_provider_azurerm.user_assigned_identity import UserAssignedIdentity
from cdktf_cdktf_provider_tls.private_key import PrivateKey

from sdvcf.interface import IPrivateCloud, IUser, UserProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .enums import KeyVaultSkuName
from .provider import AzureProvider
from .rg import AzureRg
from .utils import AzureUtils


class SSHKeyType(NamedTuple("SSHKey", [("algorithm", str), ("key_size", int)]), Enum):
    """
    Represents the type of SSH key.

    The SSHKeyType class is used to define different types of SSH keys.
    Each SSH key type is represented by an algorithm and a key size.

    Check the official documentation
    https://registry.terraform.io/providers/hashicorp/tls/latest/docs/resources/private_key#algorithm

    Attributes:
        algorithm (str): The algorithm used for the SSH key.
        key_size (int): The size of the SSH key in bits.
    """

    RSA4096 = ("RSA", 4096)


class AzureUserProps(UserProps):
    """
    Represents the properties of an Azure user.

    Attributes:
        ssh_key_type (SSHKeyType): The type of SSH key.
        key_vault_sku_name (KeyVaultSkuName): The SKU name of the key vault.
        key_vault_retention_days (int): The number of days to retain the key vault.
    """

    ssh_key_type: SSHKeyType
    key_vault_sku_name: KeyVaultSkuName
    key_vault_retention_days: int

    def __init__(
        self,
        key_vault_sku_name: Optional[KeyVaultSkuName] = None,
        key_vault_retention_days: Optional[int] = None,
        ssh_key_type: Optional[SSHKeyType] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)

        self.key_vault_sku_name = (
            key_vault_sku_name or KeyVaultSkuName[os.getenv("AZURE_KEY_VAULT_SKU_NAME", KeyVaultSkuName.Standard.name)]
        )
        self.key_vault_retention_days = key_vault_retention_days or int(os.getenv("AZURE_KEY_VAULT_RETENTION_DAYS", 7))
        self.ssh_key_type = ssh_key_type or SSHKeyType[os.getenv("AZURE_USER_SSH_KEY_TYPE", SSHKeyType.RSA4096.name)]


class AzureUser(IUser):
    """
    Represents a user in Azure.

    Args:
        cloud (IPrivateCloud): The private cloud associated with the user.
        name (str): The name of the user.
        props (AzureUserProps): The properties of the user.
        tags (Dict[str, str], optional): The tags associated with the user. Defaults to {}.
    """

    provider: AzureProvider
    cloud: AzureRg
    props: AzureUserProps

    _key_vault: Optional[KeyVault]
    _private_ssh_key: Optional[PrivateKey]
    _public_ssh_key: Optional[SshPublicKey]
    _user: Optional[Union[User, DataAzureadUser]]
    _storage_share: Optional[StorageShare]
    _managed_identity: Optional[UserAssignedIdentity]
    _ssl_certificate: Optional[KeyVaultCertificate]

    def __init__(self, cloud: IPrivateCloud, name: str, props: AzureUserProps, tags: Dict[str, str] = {}):
        assert isinstance(cloud.provider, AzureProvider)
        assert isinstance(cloud, AzureRg)
        super().__init__(cloud.provider, name, props)

        self._tags = tags
        self.cloud = cloud

        self._key_vault = None
        self._private_ssh_key = None
        self._public_ssh_key = None
        self._user = None
        self._storage_share = None
        self._managed_identity = None
        self._ssl_certificate = None

        self.public_ssh_key
        self.ssl_certificate

    def GetSSHPublicKey(self) -> str:
        """
        Returns the SSH public key associated with the user.

        Returns:
            str: The SSH public key.
        """
        return self.public_ssh_key.public_key

    def GetUniqueID(self) -> str:
        """
        Returns the unique ID of the user.

        Returns:
            str: The unique ID of the user.
        """
        return self.user.id

    @property
    def user(self) -> Union[User, DataAzureadUser]:
        """
        Returns the user object associated with this instance.

        If the user object is not already created, it will be created based on the provided properties.

        Returns:
            Union[User, DataAzureadUser]: The user object.
        """
        if self._user is None:
            self._user = (
                DataAzureadUser(self, f"{self.name}-user-ds", mail=self.email)
                if self.props.external
                else User(
                    self,
                    f"{self.name}-user",
                    display_name=self.full_name,
                    user_principal_name=self.email,
                    mail_nickname=self.name,
                    mail=self.email,
                )
            )
        return self._user

    @property
    def managed_identity(self) -> UserAssignedIdentity:
        managed_identity_name = AzureUtils.managedIdentityName(f"{self.name}-managed-identity")
        if self._managed_identity is None:
            self._managed_identity = UserAssignedIdentity(
                self,
                managed_identity_name,
                name=managed_identity_name,
                resource_group_name=self.cloud.resource_group.name,
                location=self.cloud.resource_group.location,
            )
        return self._managed_identity

    @property
    def key_vault(self) -> KeyVault:
        """
        Retrieves or creates a KeyVault instance for the user.

        Returns:
            KeyVault: The KeyVault instance associated with the user.
        """
        if self._key_vault is None:
            kv_name = AzureUtils.keyVaultName(f"{self.provider.name}-{self.name}")
            self._key_vault = KeyVault(
                self,
                f"{self.name}-key-vault",
                name=kv_name,
                location=self.cloud.resource_group.location,
                resource_group_name=self.cloud.resource_group.name,
                enabled_for_disk_encryption=False,
                tenant_id=self.provider.client_config.tenant_id,
                soft_delete_retention_days=self.props.key_vault_retention_days,
                purge_protection_enabled=False,
                sku_name=self.props.key_vault_sku_name.value,
                tags=Tags(self, kv_name).to_dict,
                access_policy=[
                    KeyVaultAccessPolicy(
                        tenant_id=self.provider.client_config.tenant_id,
                        object_id=self.user.object_id,
                        secret_permissions=["Get"],
                    ),
                    KeyVaultAccessPolicy(
                        tenant_id=self.provider.client_config.tenant_id,
                        object_id=self.provider.client_config.object_id,
                        secret_permissions=["Get", "Delete", "List", "Purge", "Set"],
                        certificate_permissions=["Create", "Get", "Delete", "List", "Purge"],
                    ),
                    KeyVaultAccessPolicy(
                        tenant_id=self.provider.client_config.tenant_id,
                        object_id=self.managed_identity.principal_id,
                        secret_permissions=["Get"],
                        certificate_permissions=["Get", "Delete", "List", "Purge"],
                    ),
                ],
            )
        return self._key_vault

    @property
    def private_ssh_key(self) -> PrivateKey:
        """
        Retrieves or generates the private SSH key for the user.

        Returns:
            PrivateKey: The private SSH key.
        """
        if self._private_ssh_key is None:
            self._private_ssh_key = PrivateKey(
                self,
                f"{self.name}-tls-key",
                algorithm=self.props.ssh_key_type.algorithm,
                rsa_bits=self.props.ssh_key_type.key_size,
            )

            secret_name = AzureUtils.keyVaultSecretName(f"{self.name}-ssh-private-key")
            key_vault_secret = KeyVaultSecret(
                self,
                f"{self.name}-ssk-key-vault-secret",
                name=secret_name,
                value=self._private_ssh_key.private_key_pem,
                key_vault_id=self.key_vault.id,
                tags=Tags(self, secret_name, self._tags).to_dict,
            )
            Output(
                self,
                id="ssh_private_key",
                value=f"Vault: {self.key_vault.name}, Secret: {key_vault_secret.name}",
                resource_id=self._private_ssh_key.id,
                user_name=self.user.display_name,
            )
        return self._private_ssh_key

    @property
    def public_ssh_key(self) -> SshPublicKey:
        """
        Retrieves the public SSH key associated with the user.

        Returns:
            SshPublicKey: The public SSH key object.
        """
        if self._public_ssh_key is None:
            self._public_ssh_key = SshPublicKey(
                self,
                f"{self.name}-ssh-public-key",
                name=f"{self.name}-public-key",
                resource_group_name=self.cloud.resource_group.name,
                location=self.cloud.resource_group.location,
                public_key=self.private_ssh_key.public_key_openssh,
                tags=Tags(self, f"{self.name}-primary-ssh-key", self._tags).to_dict,
            )
        return self._public_ssh_key

    @property
    def ssl_certificate(self) -> KeyVaultCertificate:
        ssl_certificate_name = AzureUtils.keyVaultSecretName(f"{self.name}-ssl-certificate")
        if self._ssl_certificate is None:
            self._ssl_certificate = KeyVaultCertificate(
                self,
                ssl_certificate_name,
                name=ssl_certificate_name,
                key_vault_id=self.key_vault.id,
                certificate_policy=KeyVaultCertificateCertificatePolicy(
                    issuer_parameters={"name": "Self"},
                    key_properties=KeyVaultCertificateCertificatePolicyKeyProperties(
                        exportable=True, key_type="RSA", key_size=2048, reuse_key=False
                    ),
                    secret_properties=KeyVaultCertificateCertificatePolicySecretProperties(
                        content_type="application/x-pkcs12"
                    ),
                    x509_certificate_properties=KeyVaultCertificateCertificatePolicyX509CertificateProperties(
                        extended_key_usage=["1.3.6.1.5.5.7.3.1", "1.3.6.1.5.5.7.3.2"],
                        key_usage=["keyEncipherment", "dataEncipherment", "digitalSignature"],
                        subject="CN=sdv-poc.globallogic.com",
                        validity_in_months=12,
                    ),
                    lifetime_action=[
                        KeyVaultCertificateCertificatePolicyLifetimeAction(
                            action={"action_type": "AutoRenew"}, trigger={"days_before_expiry": 30}
                        )
                    ],
                ),
            )
        return self._ssl_certificate

    @property
    def storage_share(self) -> StorageShare:
        if self._storage_share is None:
            self._storage_share = StorageShare(
                self,
                f"{self.name}-storage-share",
                name=AzureUtils.storageShareName(f"{self.name}-storage-share"),
                storage_account_id=self.cloud.GetStorageAccount().id,
                quota=300,
            )
        return self._storage_share

    @property
    def id(self) -> str:
        return self.GetUniqueID()
