from typing import Dict, Optional

from cdktf import Fn
from cdktf_cdktf_provider_azurerm.container_registry import (
    ContainerRegistry,
    ContainerRegistryNetworkRuleSet,
)
from cdktf_cdktf_provider_azurerm.private_dns_zone_virtual_network_link import (
    PrivateDnsZoneVirtualNetworkLink,
)
from cdktf_cdktf_provider_azurerm.private_endpoint import (
    PrivateEndpoint,
    PrivateEndpointPrivateDnsZoneGroup,
    PrivateEndpointPrivateServiceConnection,
)
from cdktf_cdktf_provider_azurerm.role_definition import (
    RoleDefinition,
    RoleDefinitionPermissions,
)
from cdktf_cdktf_provider_azurerm.storage_account import StorageAccount
from cdktf_cdktf_provider_azurerm.user_assigned_identity import UserAssignedIdentity

from sdvcf.interface import IPrivateCloud, IRegistry, RegistryProps
from sdvcf.output import Output
from sdvcf.tags import Tags

from .enums import SubnetType
from .provider import AzureProvider
from .rg import AzureRg
from .submodules.azapi.resource import Resource
from .utils import AzureUtils


class AzureRegistry(IRegistry):

    cloud: AzureRg
    provider: AzureProvider

    _storage_account: Optional[StorageAccount]
    _storage_container: Optional[Resource]
    _container_registry: Optional[ContainerRegistry]
    _sa_role: Optional[RoleDefinition]
    _managed_identity: Optional[UserAssignedIdentity]
    _private_dns_zone_link: Optional[PrivateDnsZoneVirtualNetworkLink]

    def __init__(self, cloud: IPrivateCloud, ns: str, props: RegistryProps, tags: Dict[str, str] = {}):
        super().__init__(cloud.provider, ns, props=props)

        assert isinstance(cloud, AzureRg)
        self.cloud = cloud

        self._storage_account = None
        self._storage_container = None
        self._container_registry = None
        self._sa_role = None
        self._managed_identity = None
        self._private_dns_zone_link = None

        self._tags = tags

        self.container_registry.name

    @property
    def storage_account(self) -> StorageAccount:
        name = AzureUtils.storageAccountName(f"{self.name}-sa")
        if self._storage_account is None:
            self._storage_account = StorageAccount(
                self,
                f"{self.name}-storage-account",
                name=name,
                resource_group_name=self.cloud.resource_group.name,
                location=self.cloud.resource_group.location,
                account_tier="Standard",
                account_replication_type="LRS",
                public_network_access_enabled=False if not self.props.is_public else True,
                tags=Tags(self, self.name).to_dict,
            )

            if not self.props.is_public:
                self.GetPrivateEndpoint("blob", self._storage_account.id)

        return self._storage_account

    @property
    def sa_role(self) -> RoleDefinition:
        if self._sa_role is None:
            self._sa_role = RoleDefinition(
                self,
                f"{self.name}-sa-role-definition",
                name=f"{self.name}-sa-role-definition",
                scope=self.cloud.provider.subscription.id,
                permissions=[
                    RoleDefinitionPermissions(
                        actions=[
                            "Microsoft.Storage/storageAccounts/blobServices/read",
                            "Microsoft.Storage/storageAccounts/blobServices/containers/read",
                        ],
                        data_actions=["Microsoft.Storage/storageAccounts/blobServices/containers/blobs/read"],
                    )
                ],
            )
        return self._sa_role

    @property
    def storage_container(self) -> Resource:

        name = AzureUtils.blobContainerName(f"{self.name}-sc")

        if self._storage_container is None:

            self._storage_container = Resource(
                self,
                name,
                type="Microsoft.Storage/storageAccounts/blobServices/containers@2021-04-01",
                name=name,
                parent_id=f"{self.storage_account.id}/blobServices/default",
                body={"properties": {"publicAccess": "Blob"}},
            )

            Output(
                self,
                id="registry_id",
                value=self._storage_container.id,
                resource_id=self._storage_container.id,
            )

        return self._storage_container

    @property
    def managed_identity(self) -> UserAssignedIdentity:
        managed_identity_name = AzureUtils.managedIdentityName(f"{self.name}-managed-identity")
        if self._managed_identity is None:
            self._managed_identity = UserAssignedIdentity(
                self,
                managed_identity_name,
                name=managed_identity_name,
                resource_group_name=self.cloud.resource_group.name,
                location=self.cloud.resource_group.location,
            )
        return self._managed_identity

    @property
    def container_registry(self) -> ContainerRegistry:

        name = AzureUtils.containerRegistryName(f"{self.provider.name}-{self.name}-acr")

        if self._container_registry is None:
            self._container_registry = ContainerRegistry(
                self,
                name,
                name=name,
                resource_group_name=self.cloud.resource_group.name,
                location=self.cloud.resource_group.location,
                sku="Premium" if not self.props.is_public else "Basic",
                network_rule_set=(
                    [ContainerRegistryNetworkRuleSet(default_action="Deny")] if not self.props.is_public else []
                ),
                identity={"type": "UserAssigned", "identity_ids": [self.managed_identity.id]},
                public_network_access_enabled=False if not self.props.is_public else True,
                tags=Tags(self, self.name).to_dict,
            )

            if not self.props.is_public:
                self.GetPrivateEndpoint("registry", self._container_registry.id)

            Output(
                self,
                id="container_registry_id",
                value=self._container_registry.id,
                resource_id=self._container_registry.id,
            )

        return self._container_registry

    @property
    def private_dns_zone_link(self) -> PrivateDnsZoneVirtualNetworkLink:
        if self._private_dns_zone_link is None:
            self._private_dns_zone_link = PrivateDnsZoneVirtualNetworkLink(
                self,
                f"{self.name}-private-dns-zone-link",
                name=f"{self.name}-private-dns-zone-link",
                resource_group_name=self.cloud.resource_group.name,
                private_dns_zone_name=self.cloud.private_dns_zone.name,
                virtual_network_id=self.cloud.virtual_network.id,
            )
        return self._private_dns_zone_link

    def GetPrivateEndpoint(self, resource_type: str, resource_id: str) -> PrivateEndpoint:
        private_endpoint = PrivateEndpoint(
            self,
            f"{self.name}-{resource_type}-private-endpoint",
            name=f"{self.name}-{resource_type}-private-endpoint",
            resource_group_name=self.cloud.resource_group.name,
            location=self.cloud.resource_group.location,
            subnet_id=self.cloud.subnets[SubnetType.Primary].id,
            private_service_connection=PrivateEndpointPrivateServiceConnection(
                name=f"{self.name}-{resource_type}-private-service-connection",
                is_manual_connection=False,
                private_connection_resource_id=resource_id,
                subresource_names=[resource_type],
            ),
            private_dns_zone_group=(
                PrivateEndpointPrivateDnsZoneGroup(
                    name=f"{self.name}-{resource_type}-private-dns-zone-group",
                    private_dns_zone_ids=[self.cloud.private_dns_zone.id],
                )
                if not self.props.is_public
                else None
            ),
        )
        return private_endpoint

    def GetUniqueID(self) -> str:
        """
        Get an ARN of the registry.

        Returns:
            str: A unique identifier as a string.
        """
        return self.storage_container.id

    def GetURL(self) -> str:
        """
        Get a URL of the registry.

        Returns:
            str: A URL as a string.
        """
        return Fn.join(
            "", ["https://", self.storage_account.name, ".blob.core.windows.net", self.storage_container.name]
        )

    def GetPolicyInfo(self) -> Dict[str, str]:
        """
        Abstract method to get an information about the registry's IAM policy.

        Returns:
            Dict: A dictionary of policy's info.
        """
        return {"id": self.sa_role.id, "name": f"{self.name}-sa-role-definition"}
