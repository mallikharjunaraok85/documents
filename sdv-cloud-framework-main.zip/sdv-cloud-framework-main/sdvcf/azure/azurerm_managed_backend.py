from azure.identity import DefaultAzureCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.subscription import SubscriptionClient
from cdktf import AzurermBackend
from constructs import Construct

from sdvcf.tags import Tags


class AzurermManagedBackend(AzurermBackend):
    """
    Represents a managed Azure backend for storing Terraform state in Azure Storage.

    Args:
        scope (Construct): The scope of the construct.
        resource_group_name (str): The name of the resource group.
        container_name (str): The name of the container in the storage account.
        key (str): The name of the Blob used to retrieve/store Terraform's State file inside the Storage Container.
        storage_account_name (str): The name of the storage account.
        location (str): The location of the resource group.

    Raises:
        RuntimeError: If the storage account name is already in use.
    """

    def __init__(
        self,
        scope: Construct,
        resource_group_name: str,
        container_name: str,
        key: str,
        storage_account_name: str,
        location: str,
    ):
        tags = Tags(scope, "backend").to_dict
        credential = DefaultAzureCredential()
        sub_client = SubscriptionClient(credential)
        subscription_id = str(
            [sub.subscription_id for sub in sub_client.subscriptions.list() if sub.state == "Enabled"][0]
        )
        resource_client = ResourceManagementClient(credential, subscription_id)

        resource_client.resource_groups.create_or_update(
            resource_group_name,
            {"location": location, "tags": tags},  # type: ignore
        )
        storage_client = StorageManagementClient(credential, subscription_id)

        storage_accounts = [
            acc.name for acc in storage_client.storage_accounts.list_by_resource_group(resource_group_name)
        ]
        if storage_account_name not in storage_accounts:
            availability_result = storage_client.storage_accounts.check_name_availability(
                {"name": storage_account_name}  # type: ignore
            )

            if not availability_result.name_available:
                raise RuntimeError(f"Storage name {storage_account_name} is already in use. Try another name.")

            poller = storage_client.storage_accounts.begin_create(
                resource_group_name,
                storage_account_name,
                {  # type: ignore
                    "location": location,
                    "kind": "StorageV2",
                    "sku": {"name": "Standard_LRS"},
                    "tags": tags,
                },
            )
            poller.result()

        blob_containers = [
            blob.name
            for blob in storage_client.blob_containers.list(resource_group_name, storage_account_name)  # type: ignore
        ]
        if container_name not in blob_containers:
            storage_client.blob_containers.create(
                resource_group_name,
                storage_account_name,
                container_name,
                {},  # type: ignore
            )

        super().__init__(
            scope,
            container_name=container_name,
            key=key,
            storage_account_name=storage_account_name,
            resource_group_name=resource_group_name,
        )
