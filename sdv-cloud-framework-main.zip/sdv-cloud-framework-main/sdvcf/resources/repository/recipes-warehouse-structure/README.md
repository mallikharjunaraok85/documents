# SDV Virtual Machine Configure Scenarios

This repository contains of Ansible playbooks used by SDV Cloud Framework to configure various virtual machines.  
Supported apps are described in `manifest.yaml` file.
