from copy import deepcopy
from typing import Dict

from constructs import Construct

from .interface import IComponent, IProvider


class Tags:
    SDVCF: str
    Name: str
    Stack: str

    def __init__(self, scope: Construct, ns: str, user_data: Dict[str, str] = {}):
        self._user_data = user_data

        self.SDVCF = "True"
        self.Name = ns

        if isinstance(scope, IComponent):
            self.Stack = scope.provider.name
            self.Type = scope.type
            self.Component = type(scope).__name__
            self.ComponentName = scope.name
        elif isinstance(scope, IProvider):
            self.Stack = scope.name

    @property
    def to_dict(self) -> Dict[str, str]:
        tags = self._user_data
        props = vars(self)
        keys = list(props.keys())
        for key in keys:
            if key.startswith("_"):
                props.pop(key)
        tags.update(props)

        return deepcopy(tags)
