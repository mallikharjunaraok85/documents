from abc import abstractmethod
from os import getenv
from typing import Any, List, Optional

from .i_private_cloud import IPrivateCloud
from .i_service_machine import IServiceMachine, ServiceMachineProps

__all__ = [
    "WorkbenchProps",
    "IWorkbench",
]


class WorkbenchProps(ServiceMachineProps):
    """
    Properties for a workbench.

    Expands ServiceMachineProps

    Attributes:
        auto_stop_minutes (int): Amount of time to stop inactive Workbench
    """

    auto_stop_minutes: int

    def __init__(self, auto_stop_minutes: Optional[int] = None, **kwargs: Any):
        super().__init__(**kwargs)
        self.auto_stop_minutes = auto_stop_minutes or int(getenv("WB_AUTO_STOP_MINUTES", 120))


class IWorkbench(IServiceMachine):
    """
    Interface for the Workbench component.
    Used to be inherited by Workbench implementation classes.
    Expands IServiceMachine

    Args:
        cloud (IPrivateCloud): The cloud backend for the component.
        ns (str): the namespace of the provider.
        props ():
            An object containing the configuration properties of the Workbench.

    Attributes:
        props (WorkbenchProps):
            An object containing the configuration properties of the Workbench.

    """

    props: WorkbenchProps

    def __init__(self, cloud: IPrivateCloud, ns: str, props: WorkbenchProps):
        super().__init__(cloud, ns, props)

        self.props = props

    @property
    @abstractmethod
    def posix_username(self) -> str: ...

    @property
    @abstractmethod
    def exposed_ports(self) -> List[int]: ...

    @property
    def type(self) -> str:
        return "Workbench"
