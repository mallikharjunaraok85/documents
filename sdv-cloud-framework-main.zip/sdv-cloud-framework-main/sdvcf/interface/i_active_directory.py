from abc import abstractmethod
from enum import Enum
from typing import Tuple

from .i_cloud_component import ICloudComponent
from .i_private_cloud import IPrivateCloud

__all__ = [
    "ActiveDirectoryType",
    "ActiveDirectorySize",
    "ActiveDirectoryProps",
    "IActiveDirectory",
]


class ActiveDirectoryType(Enum):
    """
    Enumeration representing the type of Active Directory.
    """

    CONNECTOR = 1
    SIMPLE_AD = 2


class ActiveDirectorySize(Enum):
    """
    Enumeration representing the size of Active Directory.
    """

    SMALL = 1
    LARGE = 2


class ActiveDirectoryProps:
    """
    Class representing the properties of Active Directory.
    """

    ad_type: ActiveDirectoryType
    ad_size: ActiveDirectorySize

    def __init__(
        self,
        ad_type: ActiveDirectoryType = ActiveDirectoryType.SIMPLE_AD,
        ad_size: ActiveDirectorySize = ActiveDirectorySize.SMALL,
    ):
        self.ad_type = ad_type
        self.ad_size = ad_size


class IActiveDirectory(ICloudComponent):
    """
    Interface for Active Directory component.
    """

    props: ActiveDirectoryProps

    def __init__(self, cloud: IPrivateCloud, ns: str, props: ActiveDirectoryProps):
        super().__init__(cloud, ns)

        self.props = props

    @abstractmethod
    def GetEndpoint(self) -> str:
        """
        Abstract method to get the endpoint of the Active Directory.
        """
        ...

    @abstractmethod
    def GetAdminAccount(self) -> Tuple[str, str]:
        """
        Abstract method to get the admin account of the Active Directory.
        """
        ...

    @property
    def type(self) -> str:
        """
        Property to get the type of the Active Directory.
        """
        return "ActiveDirectory"

    def GetType(self) -> ActiveDirectoryType:
        """
        Method to get the type of the Active Directory.
        """
        return self.props.ad_type

    def GetSize(self) -> ActiveDirectorySize:
        """
        Method to get the size of the Active Directory.
        """
        return self.props.ad_size
