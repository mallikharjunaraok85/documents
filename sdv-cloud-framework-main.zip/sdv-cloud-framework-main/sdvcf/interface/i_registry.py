from abc import abstractmethod
from typing import Any, Dict

from .i_component import IComponent
from .i_provider import IProvider

__all__ = ["IRegistry", "RegistryProps"]


class RegistryProps:
    """
    Properties for a registry.

    Attributes:
        is_public (bool):
            A flag indicating whether registry is publicly available or not.
        retention (Dict[str, Any]):
            A dictionary containing information about retention rules.
    """

    is_public: bool
    retention: Dict[str, Any]

    def __init__(
        self,
        is_public: bool = False,
        retention: Dict[str, Any] = {},
        **_: Any,
    ):
        self.is_public = is_public
        self.retention = retention


class IRegistry(IComponent):
    """
    Interface for a registry in the SDV Cloud Framework.

    Inherits from IComponent.

    Methods:
        GetUniqueID:
            Get a unique ID of the registry.
        GetUrl:
            Get a URL of the registry.
        GetPolicyInfo:
            Get an information about policy of the registry.

    Attributes:
        props (RegistryProps):
            An object containing the configuration properties of the Registry.
    """

    props: RegistryProps

    def __init__(self, scope: IProvider, ns: str, props: RegistryProps):
        super().__init__(scope, ns)

        self.props = props

    @abstractmethod
    def GetUniqueID(self) -> str:
        """
        Abstract method to get a unique ID of the registry.

        Returns:
            str: A unique identifier as a string.
        """
        ...

    @abstractmethod
    def GetURL(self) -> str:
        """
        Abstract method to get a URL of the registry.

        Returns:
            str: A URL as a string.
        """
        ...

    @abstractmethod
    def GetPolicyInfo(self) -> Dict[str, Any]:
        """
        Abstract method to get an information about the registry's IAM policy.

        Returns:
            Dict: A dictionary of policy's info.
        """
        ...

    @property
    @abstractmethod
    def type(self) -> str:
        return "Registry"
