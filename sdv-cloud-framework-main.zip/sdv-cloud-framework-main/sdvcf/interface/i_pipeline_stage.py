from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .i_repository import IRepository

from .i_component import IComponent

__all__ = [
    "PipelineStageId",
    "PipelineStageProps",
    "IPipelineStage",
]


class PipelineStageId(Enum):
    """
    Enumeration representing the different pipeline stage IDs.
    """

    StaticAnalysis = "static-analysis"
    Build = "build"
    UnitTest = "unit-test"
    BuildImage = "build-image"
    IntegrationTest = "integration-test"
    SystemTest = "system-test"
    Release = "release"


class PipelineStageProps:
    """
    Class representing the properties of a pipeline stage.
    """

    name: PipelineStageId
    container: str
    timeout: str

    def __init__(self, name: PipelineStageId, container: str = "", timeout: str = "", provider_name: str = ""):
        """
        Initializes the PipelineStageProps object.

        Args:
            name (PipelineStageId): The ID of the pipeline stage.
            container (str, optional): The container associated with the pipeline stage. Defaults to "".
            timeout (str, optional): The timeout value for the pipeline stage. Defaults to "".
        """
        self.name = name
        self.container = container
        self.timeout = timeout
        self.provider_name = provider_name


class IPipelineStage(IComponent):
    """
    Interface representing a pipeline stage.
    """

    repo: "IRepository"
    props: PipelineStageProps

    def __init__(self, repo: "IRepository", ns: str, props: PipelineStageProps):
        """
        Initializes the IPipelineStage object.

        Args:
            repo (IRepository): The repository associated with the pipeline stage.
            ns (str): The namespace of the pipeline stage.
            props (PipelineStageProps): The properties of the pipeline stage.
        """
        super().__init__(repo.provider, ns)

        self.repo = repo
        self.props = props

    @property
    def type(self) -> str:
        return "PipelineStage"
