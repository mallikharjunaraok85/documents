from abc import abstractmethod
from typing import Any, List, Type

from constructs import Construct

from .i_provider import IProvider

__all__ = ["IComponent"]


class IComponent(Construct):
    """
    Interface for components in the SDV Cloud Framework.

    Attributes:
        name (str): The name of the component.
        provider (IProvider): The provider associated with the component.
        plugins (List[Type[Any]]): List of plugins registered with the component.
    """

    name: str
    provider: IProvider

    plugins: List[Type[Any]]

    def __init__(self, scope: IProvider, ns: str):
        super().__init__(scope, ns)

        self.name = ns
        self.provider = scope

        self.plugins = []

    def GetProvider(self) -> IProvider:
        """
        Get the provider associated with the component.

        Returns:
            IProvider: The provider associated with the component.
        """
        return self.provider

    def RegisterPlugin(self, plugin: Type["IComponent"]):
        """
        Register a plugin with the component.

        Args:
            plugin (Type[IComponent]): The plugin to register.
        """
        if plugin not in self.plugins:
            self.plugins.append(plugin)

    @property
    @abstractmethod
    def type(self) -> str: ...
