from abc import abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .i_repository import IRepository

from .i_component import IComponent
from .i_pipeline_stage import IPipelineStage, PipelineStageProps
from .i_stage_runner import IStageRunner

__all__ = ["IPipeline"]


class IPipeline(IComponent):
    repo: "IRepository"

    def __init__(self, repo: "IRepository", ns: str):
        super().__init__(repo.provider, ns)

        self.repo = repo

    @abstractmethod
    def CreateStage(self, runner: IStageRunner, props: PipelineStageProps) -> IPipelineStage: ...

    @abstractmethod
    def Commit(self) -> None: ...

    @property
    def type(self) -> str:
        return "Pipeline"
