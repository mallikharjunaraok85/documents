from .i_component import IComponent
from .i_provider import IProvider


class ILogger(IComponent):

    def __init__(self, scope: IProvider, ns: str):
        super().__init__(scope, ns)

    @property
    def type(self) -> str:
        return "Logger"
