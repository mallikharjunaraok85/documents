from abc import abstractmethod
from enum import Enum, auto
from os import getenv
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from cdktf import Fn

from sdvcf.interface.i_private_cloud import IPrivateCloud

from .i_cloud_component import ICloudComponent

__all__ = ["IServiceMachine", "ServiceMachineProps", "ServiceMachineOS"]


class ServiceMachineOS(Enum):
    """
    Enumeration of Service Machine OS types.

    Attributes:
        Ubuntu18_04:
            Represents Ubuntu 18.04 OS.
        Ubuntu20_04:
            Represents Ubuntu 20.04 OS.
        Ubuntu22_04:
            Represents Ubuntu 22.04 OS.

    """

    Ubuntu18_04 = auto()
    Ubuntu20_04 = auto()
    Ubuntu22_04 = auto()


class ServiceMachineProps:
    """
    Properties for a service machine.

    """

    itype: str
    os: ServiceMachineOS
    ingress_cidr_blocks: List[str]
    ports: List[int]
    disk_size: int
    registry_policy_info: List[Dict[str, Any]]

    os_mapping: Dict[str, ServiceMachineOS] = {
        "Ubuntu22.04": ServiceMachineOS.Ubuntu22_04,
        "Ubuntu20.04": ServiceMachineOS.Ubuntu20_04,
        "Ubuntu18.04": ServiceMachineOS.Ubuntu18_04,
    }

    ami_os_family_mapping = {
        ServiceMachineOS.Ubuntu22_04: "ubuntu",
        ServiceMachineOS.Ubuntu20_04: "ubuntu",
        ServiceMachineOS.Ubuntu18_04: "ubuntu",
    }

    ami_filter_mapping = {
        ServiceMachineOS.Ubuntu22_04: "ubuntu/images/*/ubuntu-*-22.04-*-server-*",
        ServiceMachineOS.Ubuntu20_04: "ubuntu/images/*/ubuntu-*-20.04-*-server-*",
        ServiceMachineOS.Ubuntu18_04: "ubuntu/images/*/ubuntu-*-18.04-*-server-*",
    }

    os_version_mapping = {
        ServiceMachineOS.Ubuntu22_04: "22_04",
        ServiceMachineOS.Ubuntu20_04: "20_04",
        ServiceMachineOS.Ubuntu18_04: "18_04",
    }

    def __init__(
        self,
        itype: str,
        os: str,
        ingress_cidr_blocks: List[str] = [],
        ports: List[int] = [],
        registry_policy_info: List[Dict[str, Any]] = [],
        disk_size: Optional[int] = None,
    ) -> None:
        """
        Initialize the ServiceMachineProps.

        Args:
            itype (str): CPU architecture for the service machine.
            os (ServiceMachineOS): OS of the service machine
            ingress_cidr_blocks (List[str]): A list of network CIDR blocks.
            ports (List[int]): List of ports to expose for service machine.
            disk_size (int): The size of the volume of the service machine in GB.

        """
        self.itype = itype
        self.os = self.os_mapping[os]
        self.ingress_cidr_blocks = ingress_cidr_blocks
        self.ports = ports
        self.registry_policy_info = registry_policy_info
        self.disk_size = disk_size or int(getenv("WB_DISK_SIZE", 128))


class IServiceMachine(ICloudComponent):
    """
    Interface for the Service Machine component.
    Used to be inherited by Service Machine implementation classes.

    Args:
        cloud (IPrivateCloud): The cloud backend for the component.
        ns (str): the namespace of the provider.
        props (ServiceMachineProps):
            An object containing the configuration properties of the Service Machine.

    Attributes:
        props (ServiceMachineProps):
            An object containing the configuration properties of the Service Machine.

    Private Attributes:
        _user_data_files (List[Tuple[Path, Optional[Dict[str, Any]]]]):
            List with user data files and parameters.

    Public Methods:
        AddUserDataFile:
            Adds user data file and its properties to _user_data_files.

    Properties:
        user_data:
            Returns compiled user data in string format.

    Abstract Methods:
        type:
            Abstract property that is supposed to be defined it inherited classes.
            Returns cloud component type in str.
        posix_username:
            Abstract property that is supposed to be defined it inherited classes.
            Returns user name of the Service Machine OS user.
        exposed ports:
            Abstract property that is supposed to be defined it inherited classes.
            Returns list on Service Machine exposed ports.

    """

    props: ServiceMachineProps

    _user_data_files: List[Tuple[Path, Optional[Dict[str, Any]]]]

    def __init__(self, cloud: IPrivateCloud, ns: str, props: ServiceMachineProps):
        super().__init__(cloud, ns)

        props.ports.extend(self.exposed_ports)
        props.ports = list(set(props.ports))

        self.props = props

        self._user_data_files = []

    def AddUserDataFile(self, path: Path, parameters: Optional[Dict[str, Any]] = None):
        """
        Adds user data entity to the _user_data_files list.

        This method takes path of the user data file and parameters Dict to append _user_data_files.

        Parameters:
            path (Path):
                Path object with the path to the user data file.
            parameters (Dict[str, Any]):
                Optional parameter with Dict of parameter name as key and parameter value..

        Returns:
            None:
                This method doesn't return anything.
        """
        self._user_data_files.append((path, parameters))

    @property
    def user_data(self) -> str:
        """
        Generates and returns user data in string formant.

        This method takes all user data files and parameters from _user_data_files and generates
        result string with user data.

        Parameters:
            None:
                This method does not have any parameters.

        Returns:
            (str):
                User data in string format.
        """
        result = ""
        for path, parameters in self._user_data_files:
            result += Fn.templatefile(str(path), parameters) if parameters else Fn.file(str(path))
        return result

    @property
    @abstractmethod
    def posix_username(self) -> str: ...

    @property
    @abstractmethod
    def exposed_ports(self) -> List[int]: ...

    @property
    @abstractmethod
    def type(self) -> str: ...
