from abc import abstractmethod
from typing import Any, List

from .i_component import IComponent
from .i_private_cloud import IPrivateCloud
from .i_provider import IProvider

__all__ = [
    "VpnProps",
    "IVPN",
]


class VpnProps:
    cidr_blocks: List[str]

    def __init__(
        self,
        cidr_blocks: List[str],
        **_: Any,
    ):
        self.cidr_blocks = cidr_blocks


class IVPN(IComponent):
    props: VpnProps

    def __init__(self, scope: IProvider, ns: str, props: VpnProps):
        super().__init__(scope, ns)

        self.props = props

    @abstractmethod
    def Establish(self, device_ip_address: str, device_name: str = "") -> None: ...

    def Attach(self, cloud: IPrivateCloud) -> None:
        self._Attach(cloud)
        cloud.AcceptVpn(self)

    @abstractmethod
    def _Attach(self, cloud: IPrivateCloud) -> None: ...

    @property
    def type(self) -> str:
        return "VPN"

    def GetCidrBlocks(self) -> List[str]:
        return self.props.cidr_blocks
