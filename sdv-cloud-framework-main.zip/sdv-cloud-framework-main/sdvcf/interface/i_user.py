from abc import abstractmethod
from typing import Any

from .i_component import IComponent
from .i_provider import IProvider

__all__ = ["IUser"]


class UserProps:
    display_name: str
    domain: str
    external: bool
    username_suffix: str

    def __init__(
        self,
        display_name: str = "",
        domain: str = "",
        external: bool = False,
        username_suffix: str = "",
        **_: Any,
    ):
        self.display_name = display_name
        self.domain = domain
        self.external = external
        self.username_suffix = username_suffix


class IUser(IComponent):
    props: UserProps

    def __init__(self, scope: IProvider, ns: str, props: UserProps):
        super().__init__(scope, ns)

        self.props = props

    @abstractmethod
    def GetSSHPublicKey(self) -> str:
        pass

    @abstractmethod
    def GetUniqueID(self) -> str:
        pass

    @property
    def type(self) -> str:
        return "User"

    @property
    def email(self) -> str:
        return f"{self.name}@{self.props.domain}" if self.props.domain else ""

    @property
    def full_name(self) -> str:
        if self.props.display_name:
            return f"{self.props.display_name} <{self.email}>" if self.email else self.props.display_name
        else:
            return self.name
