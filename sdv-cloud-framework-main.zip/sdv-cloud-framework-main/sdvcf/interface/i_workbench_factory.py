from abc import abstractmethod
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Union

from .i_user import IUser
from .i_workbench import IWorkbench

__all__ = [
    "WorkbenchType",
    "WorkbenchCPUArch",
    "WorkbenchCreationProps",
    "IWorkbenchFactory",
]


class WorkbenchType(Enum):
    ComputeServer = auto()
    VirtualDesktop = auto()
    WebIDE = auto()


class WorkbenchCPUArch(Enum):
    ARM64 = auto()
    AMD64 = auto()


class WorkbenchCreationProps:
    type: WorkbenchType
    cpu_arch: WorkbenchCPUArch
    vcpu: int
    ram_gib: float
    os: str
    blueprints: Dict[str, Optional[Dict[str, Any]]]
    backup: Dict[str, Any]
    registries: List[Dict[str, str]]
    registry_policies: List[Dict[str, Any]]

    def __init__(
        self,
        type: Union[WorkbenchType, str],
        cpu_arch: Union[WorkbenchCPUArch, str] = WorkbenchCPUArch.AMD64,
        vcpu: int = 2,
        ram_gib: float = 8,
        os: str = "Ubuntu22.04",
        blueprints: Dict[str, Optional[Dict[str, Any]]] = {},
        backup: Dict[str, Any] = {},
        registries: List[Dict[str, str]] = [],
        registry_policies: List[Dict[str, Any]] = [],
        **_: Any,
    ):
        self.type = WorkbenchType[type.name if isinstance(type, WorkbenchType) else type]
        self.cpu_arch = WorkbenchCPUArch[cpu_arch.name if isinstance(cpu_arch, WorkbenchCPUArch) else cpu_arch]
        self.vcpu = vcpu
        self.ram_gib = ram_gib
        self.os = os
        self.blueprints = blueprints
        self.backup = backup
        self.registries = registries
        self.registry_policies = registry_policies


class IWorkbenchFactory:
    @classmethod
    @abstractmethod
    def Create(cls, user: IUser, props: WorkbenchCreationProps) -> IWorkbench: ...
