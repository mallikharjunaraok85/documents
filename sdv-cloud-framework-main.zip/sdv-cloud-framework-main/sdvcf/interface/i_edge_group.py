from .i_component import IComponent
from .i_provider import IProvider

__all__ = ["IEdgeGroup"]


class IEdgeGroup(IComponent):
    def __init__(self, scope: IProvider, ns: str):
        super().__init__(scope, ns)

    @property
    def type(self) -> str:
        return "EdgeGroup"
