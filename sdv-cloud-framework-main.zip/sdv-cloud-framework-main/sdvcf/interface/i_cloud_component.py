from .i_component import IComponent
from .i_private_cloud import IPrivateCloud

__all__ = ["ICloudComponent"]


class ICloudComponent(IComponent):
    """
    Represents a cloud component that is part of a private cloud.

    Args:
        cloud (IPrivateCloud): The private cloud that this component belongs to.
        ns (str): The namespace of the component.

    Attributes:
        cloud (IPrivateCloud): The private cloud that this component belongs to.

    """

    cloud: IPrivateCloud

    def __init__(self, cloud: IPrivateCloud, ns: str):
        super().__init__(cloud.cloud_provider, ns)

        self.cloud = cloud

    def GetCloud(self) -> IPrivateCloud:
        """
        Returns the private cloud that this component belongs to.

        Returns:
            IPrivateCloud: The private cloud that this component belongs to.

        """
        return self.cloud
