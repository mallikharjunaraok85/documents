from .i_cloud_component import ICloudComponent
from .i_private_cloud import IPrivateCloud

__all__ = ["IDistributor"]


class IDistributor(ICloudComponent):
    def __init__(self, cloud: IPrivateCloud, ns: str):
        super().__init__(cloud, ns)

    @property
    def type(self) -> str:
        return "Distributor"
