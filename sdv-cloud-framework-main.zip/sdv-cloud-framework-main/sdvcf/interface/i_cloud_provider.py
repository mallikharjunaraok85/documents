from abc import abstractmethod

from constructs import Construct

from .i_provider import IProvider

__all__ = ["ICloudProvider"]


class ICloudProvider(IProvider):
    def __init__(self, scope: Construct, ns: str):
        super().__init__(scope, ns)

    @abstractmethod
    def CommitDashboard(self) -> None: ...
