from abc import abstractmethod
from enum import Enum
from typing import Any, Dict, List

from .i_component import IComponent
from .i_provider import IProvider

__all__ = [
    "StageRunnerComputeSize",
    "StageRunnerOS",
    "StageRunnerCPUArch",
    "StageRunnerProps",
    "IStageRunner",
]


class StageRunnerComputeSize(Enum):
    Small = "s"
    Medium = "m"
    Large = "l"


class StageRunnerOS(Enum):
    Windows = "windows"
    Linux = "linux"


class StageRunnerCPUArch(Enum):
    x86_64 = "amd64"
    Arm64 = "arm64"


class StageRunnerProps:
    compute_size: StageRunnerComputeSize
    os: StageRunnerOS
    arch: StageRunnerCPUArch
    registry_policy_info: List[Dict[str, Any]]

    def __init__(
        self,
        compute_size: StageRunnerComputeSize,
        os: StageRunnerOS,
        arch: StageRunnerCPUArch,
        registry_policy_info: List[Dict[str, Any]] = [],
        **_: Any,
    ):
        self.compute_size = compute_size
        self.os = os
        self.arch = arch
        self.registry_policy_info = registry_policy_info


class IStageRunner(IComponent):
    props: StageRunnerProps

    def __init__(self, scope: IProvider, ns: str, props: StageRunnerProps):
        super().__init__(scope, ns)

        self.props = props

    @property
    @abstractmethod
    def labels(self) -> List[str]: ...

    @property
    def type(self) -> str:
        return "StageRunner"
