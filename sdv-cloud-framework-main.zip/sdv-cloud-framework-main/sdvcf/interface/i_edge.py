from .i_component import IComponent
from .i_provider import IProvider

__all__ = [
    "EdgeProps",
    "IEdge",
]


class EdgeProps:
    part_number: str

    def __init__(self, part_number: str):
        self.part_number = part_number


class IEdge(IComponent):
    props: EdgeProps

    def __init__(self, scope: IProvider, ns: str, props: EdgeProps):
        super().__init__(scope, ns)

        self.props = props

    @property
    def type(self) -> str:
        return "Edge"
