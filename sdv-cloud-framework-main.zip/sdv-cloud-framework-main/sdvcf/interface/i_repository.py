from abc import abstractmethod
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from .i_component import IComponent
from .i_pipeline import IPipeline
from .i_provider import IProvider
from .i_user import IUser
from .i_user_group import IUserGroup

__all__ = [
    "RepositoryAccessType",
    "RepositoryProps",
    "IRepository",
]
__all__ = [
    "RepositoryAccessType",
    "RepositoryProps",
    "IRepository",
]


class RepositoryAccessType(Enum):
    VIEWER = 1
    CONTRIBUTOR = 2
    MAINTAINER = 3
    OWNER = 4


class RepositoryProps:

    class RepositoryMergeOptions:
        class MergeOptionsList(Enum):
            MERGE_COMMIT = "merge_commit"
            REBASE_MERGE = "rebase_merge"
            SQUASH_MERGE = "squash_merge"

        _DEFAULT_OPTIONS: Dict[MergeOptionsList, bool] = {
            MergeOptionsList.MERGE_COMMIT: True,
            MergeOptionsList.REBASE_MERGE: False,
            MergeOptionsList.SQUASH_MERGE: True,
        }

        merge_commit: bool
        rebase_merge: bool
        squash_merge: bool

        def __init__(self, options: List[str] = []) -> None:
            if not options:
                self.merge_commit = self._DEFAULT_OPTIONS[self.MergeOptionsList.MERGE_COMMIT]
                self.rebase_merge = self._DEFAULT_OPTIONS[self.MergeOptionsList.REBASE_MERGE]
                self.squash_merge = self._DEFAULT_OPTIONS[self.MergeOptionsList.SQUASH_MERGE]
            else:
                self.merge_commit = self.MergeOptionsList.MERGE_COMMIT.value in options
                self.rebase_merge = self.MergeOptionsList.REBASE_MERGE.value in options
                self.squash_merge = self.MergeOptionsList.SQUASH_MERGE.value in options

    auto_init: bool
    is_global: bool
    is_permanent: bool
    is_public: bool
    has_issues: bool
    artifacts_storage: Dict[str, str]
    default_branch: str
    dev_branch: str
    description: str
    autolink: Dict[str, str]
    key_prefix: str
    target_url_template: str
    allow_reuse_actions: bool
    merge_options: RepositoryMergeOptions
    protection_rule: Dict[Any, Any]

    def __init__(
        self,
        auto_init: bool = True,
        is_global: bool = False,
        is_permanent: bool = True,
        is_public: bool = False,
        has_issues: bool = False,
        artifacts_storage: Dict[str, str] = {"storage_type": "", "storage_name": "", "artifact_collector": ""},
        default_branch: str = "main",
        dev_branch: str = "dev",
        description: str = "",
        autolink: Dict[str, str] = {},
        key_prefix: str = "",
        target_url_template: str = "",
        allow_reuse_pipeline: bool = False,
        merge_options: List[str] = [],
        protection_rule: Dict[Any, Any] = {},
        **_: Any,
    ):
        self.auto_init = auto_init
        self.is_global = is_global
        self.is_permanent = is_permanent
        self.is_public = is_public
        self.has_issues = has_issues
        self.artifacts_storage = artifacts_storage
        self.default_branch = default_branch
        self.dev_branch = dev_branch
        self.description = description
        self.autolink = autolink
        self.key_prefix = key_prefix
        self.target_url_template = target_url_template
        self.allow_reuse_pipeline = allow_reuse_pipeline
        self.merge_options = self.RepositoryMergeOptions(merge_options)
        self.protection_rule = protection_rule


class IRepository(IComponent):
    props: RepositoryProps

    def __init__(self, scope: IProvider, ns: str, props: RepositoryProps):
        super().__init__(scope, ns)

        self.props = props

    @abstractmethod
    def AddUser(self, user: IUser, atype: RepositoryAccessType, expire: Optional[datetime] = None) -> None: ...

    @abstractmethod
    def AddGroup(self, group: IUserGroup, atype: RepositoryAccessType, expire: Optional[datetime] = None) -> None: ...

    @abstractmethod
    def CreatePipeline(self) -> IPipeline: ...

    @abstractmethod
    def AddProtectionRule(self) -> None: ...

    @abstractmethod
    def Commit(self) -> None: ...

    @property
    def type(self) -> str:
        return "Repository"
