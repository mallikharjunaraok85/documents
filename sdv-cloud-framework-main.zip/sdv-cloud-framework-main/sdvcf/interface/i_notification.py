from abc import ABC
from typing import List


class INotification(ABC):
    _subscribers: List[str] = []

    @classmethod
    def Subscribe(cls, email: str) -> None:
        if email not in cls._subscribers:
            cls._subscribers.append(email)
