from abc import abstractmethod
from typing import Any, Dict, Optional, Type, TypeVar, cast

from cdktf import TerraformBackend, TerraformStack
from constructs import Construct

from .i_dashboard import IDashboard

__all__ = ["IProvider"]

_PT = TypeVar("_PT", bound="IProvider")


class MiscProps:
    uri: str
    path: str
    name: str

    def __init__(self, uri: Optional[str] = None, path: Optional[str] = None, name: Optional[str] = None) -> None:
        self.uri = uri or ""
        self.path = path or ""
        self.name = name or ""


class IProvider(TerraformStack):
    """
    Interface for a provider in the SDV Cloud Framework.
    This interface is designed for singleton object usage.

    Args:
        scope (Construct): The scope of the provider.
        ns (str): The namespace of the provider.

    Attributes:
        scope (Construct): The scope of the provider.
        name (str): The name of the provider.
        backend (TerraformBackend): The backend configuration for the provider.
        misc_items (Dict[str, str]): Additional miscellaneous items for the provider.

    Methods:
        Setup: Set up the provider instance.
        Instance: Get the instance of the provider.
        _SetupBackend: Set up the backend configuration for the provider.
        CommitDashboard: Commit the dashboard changes.
        dashboard: Get the dashboard instance.
        AddMiscItem: Add a miscellaneous item to the provider.

    """

    scope: Construct
    name: str
    backend: TerraformBackend
    misc_items: Dict[str, str]

    _instance = None

    def __init__(self, scope: Construct, ns: str):
        nested_provider = issubclass(type(scope), IProvider)
        super().__init__(cast(IProvider, scope).scope if nested_provider else scope, ns)

        self.scope = scope
        self.name = ns
        self.backend = cast(IProvider, scope)._SetupBackend(self) if nested_provider else self._SetupBackend()
        self.misc_items = {}

    @classmethod
    def Setup(cls: Type[_PT], scope: Construct, ns: str, **kwargs: Any) -> _PT:
        """
        Set up the provider instance.

        Args:
            scope (Construct): The scope of the provider.
            ns (str): The namespace of the provider.
            **kwargs (Any): Additional keyword arguments.

        Returns:
            _PT: The instance of the provider.

        Raises:
            AssertionError: If the provider instance is already set up.

        """
        assert cls._instance is None, f"`{cls.__name__}` provider already was setup"
        cls._instance = cls(scope, ns, **kwargs)
        return cls._instance

    @classmethod
    def Instance(cls: Type[_PT]) -> _PT:
        """
        Get the instance of the provider.

        Returns:
            _PT: The instance of the provider.

        Raises:
            AssertionError: If the provider instance was not set up.

        """
        assert cls._instance is not None, f"`{cls.__name__}` provider was not setup"
        return cast(_PT, cls._instance)

    @abstractmethod
    def _SetupBackend(self, provider: Optional["IProvider"] = None) -> TerraformBackend: ...

    @abstractmethod
    def CommitDashboard(self) -> None: ...

    @property
    def dashboard(self) -> IDashboard: ...

    def AddMiscItem(self, props: MiscProps): ...
