from abc import ABC, abstractmethod
from enum import Enum, auto
from typing import Any


class IDashboard(ABC):
    class WigdetTypes(Enum):
        VPNTraffic = auto()
        SharedFSSize = auto()
        ProjectStorageSize = auto()

    @abstractmethod
    def Commit(self) -> None: ...

    @abstractmethod
    def EnableWidget(self, widget: Enum, **kwargs: Any) -> None: ...
