from abc import abstractmethod
from typing import List, Type

from .i_component import IComponent
from .i_provider import IProvider
from .i_user import IUser

__all__ = ["IUserGroup"]


class IUserGroup(IComponent):
    _users: List[IUser]

    def __init__(self, scope: IProvider, ns: str):
        super().__init__(scope, ns)

        self._users = []

    @abstractmethod
    def GetUniqueID(self) -> str:
        pass

    def RegisterPlugin(self, plugin: Type[IComponent]):
        super().RegisterPlugin(plugin)
        for user in self._users:
            user.RegisterPlugin(plugin)

    def AddUser(self, user: IUser) -> None:
        if user not in self._users:
            self._AddUser(user)
            self._users.append(user)

    @abstractmethod
    def AddGroup(self, group: "IUserGroup") -> None: ...

    @abstractmethod
    def _AddUser(self, user: IUser) -> None: ...

    @property
    def type(self) -> str:
        return "UserGroup"
