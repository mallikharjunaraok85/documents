from abc import abstractmethod
from typing import TYPE_CHECKING, Any, Dict, List

if TYPE_CHECKING:
    from .i_vpn import IVPN

from .i_cloud_provider import ICloudProvider
from .i_component import IComponent

__all__ = [
    "PrivateCloudProps",
    "IPrivateCloud",
]


class PrivateCloudProps:
    """
    Properties for a private cloud.
    """

    region: str
    network: Dict[str, Any]

    def __init__(
        self,
        region: str,
        network: Dict[str, Any],
    ):
        """
        Initialize the PrivateCloudProps.

        Args:
            region (str): The region of the private cloud.
            network (Dict[str, Any]): The network configuration of the private cloud.
        """
        self.region = region
        self.network = network


class IPrivateCloud(IComponent):
    """
    Interface for a private cloud.
    """

    props: PrivateCloudProps
    cloud_provider: ICloudProvider
    vpns: List["IVPN"]

    def __init__(self, scope: ICloudProvider, ns: str, props: PrivateCloudProps):
        """
        Initialize the IPrivateCloud.

        Args:
            scope (ICloudProvider): The cloud provider of the private cloud.
            ns (str): The namespace of the private cloud.
            props (PrivateCloudProps): The properties of the private cloud.
        """
        super().__init__(scope, ns)

        self.props = props
        self.cloud_provider = scope
        self.vpns = []

    @property
    @abstractmethod
    def subnets(self) -> Dict[str, Any]:
        """
        Get the subnets of the private cloud.

        Returns:
            Dict[str, Any]: The subnets of the private cloud.
        """
        ...

    @property
    def region(self) -> str:
        """
        Get the region of the private cloud.

        Returns:
            str: The region of the private cloud.
        """
        return self.props.region

    @property
    def cidr(self) -> str:
        """
        Get the CIDR of the private cloud.

        Returns:
            str: The CIDR of the private cloud.
        """
        return str(self.props.network["cidr"])

    def AcceptVpn(self, vpn: "IVPN"):
        """
        Accept a VPN connection.

        Args:
            vpn (IVPN): The VPN connection to accept.
        """
        self.vpns.append(vpn)

    @property
    def type(self) -> str:
        """
        Get the type of the private cloud.

        Returns:
            str: The type of the private cloud.
        """
        return "PrivateCloud"
