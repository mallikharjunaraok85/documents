"""
This module provides the interface definitions for various components and services in the SDV Cloud Framework.

The following classes and objects are defined:

- ICloudComponent: Interface for a cloud component.
- ICloudProvider: Interface for a cloud provider.
- PrivateCloudProps: Properties for a private cloud.
- IPrivateCloud: Interface for a private cloud.
- IComponent: Interface for a component.
- IEdgeGroup: Interface for an edge group.
- EdgeProps: Properties for an edge.
- IEdge: Interface for an edge.
- IServiceMachine: interface for the service machine.
- ServiceMachineProps: service machine properties.
- ServiceMachineOS: Operating system for a ServiceMachine.
- IPipeline: Interface for a pipeline.
- PipelineStageId: Identifier for a pipeline stage.
- PipelineStageProps: Properties for a pipeline stage.
- IPipelineStage: Interface for a pipeline stage.
- StageRunnerComputeSize: Compute size for a stage runner.
- StageRunnerOS: Operating system for a stage runner.
- StageRunnerCPUArch: CPU architecture for a stage runner.
- StageRunnerProps: Properties for a stage runner.
- IStageRunner: Interface for a stage runner.
- IProvider: Interface for a provider.
- MiscProps: Miscellaneous properties.
- RepositoryAccessType: Access type for a repository.
- RepositoryProps: Properties for a repository.
- IRepository: Interface for a repository.
- IUserGroup: Interface for a user group.
- UserProps: Properties for a user.
- IUser: Interface for a user.
- VpnProps: Properties for a VPN.
- IVPN: Interface for a VPN.
- WorkbenchType: Type of a workbench.
- WorkbenchCPUArch: CPU architecture for a workbench.
- WorkbenchCreationProps: Properties for creating a workbench.
- IWorkbenchFactory: Interface for a workbench factory.
- WorkbenchProps: Properties for a workbench.
- IWorkbench: Interface for a workbench.
- ActiveDirectoryType: Type of an Active Directory.
- ActiveDirectorySize: Size of an Active Directory.
- ActiveDirectoryProps: Properties for an Active Directory.
- IActiveDirectory: Interface for an Active Directory.
- INotification: Interface for a notification.
- IRegistry: Interface for a registry.
"""

from .i_active_directory import (
    ActiveDirectoryProps,
    ActiveDirectorySize,
    ActiveDirectoryType,
    IActiveDirectory,
)
from .i_cloud_component import ICloudComponent
from .i_cloud_provider import ICloudProvider
from .i_component import IComponent
from .i_edge import EdgeProps, IEdge
from .i_edge_group import IEdgeGroup
from .i_logger import ILogger
from .i_notification import INotification
from .i_pipeline import IPipeline
from .i_pipeline_stage import IPipelineStage, PipelineStageId, PipelineStageProps
from .i_private_cloud import IPrivateCloud, PrivateCloudProps
from .i_provider import IProvider, MiscProps
from .i_registry import IRegistry, RegistryProps
from .i_repository import IRepository, RepositoryAccessType, RepositoryProps
from .i_service_machine import IServiceMachine, ServiceMachineOS, ServiceMachineProps
from .i_stage_runner import (
    IStageRunner,
    StageRunnerComputeSize,
    StageRunnerCPUArch,
    StageRunnerOS,
    StageRunnerProps,
)
from .i_user import IUser, UserProps
from .i_user_group import IUserGroup
from .i_vpn import IVPN, VpnProps
from .i_workbench import IWorkbench, WorkbenchProps
from .i_workbench_factory import (
    IWorkbenchFactory,
    WorkbenchCPUArch,
    WorkbenchCreationProps,
    WorkbenchType,
)

__all__ = [
    "ICloudComponent",
    "ICloudProvider",
    "PrivateCloudProps",
    "IPrivateCloud",
    "IComponent",
    "IEdgeGroup",
    "EdgeProps",
    "IEdge",
    "ILogger",
    "IServiceMachine",
    "ServiceMachineProps",
    "ServiceMachineOS",
    "IPipeline",
    "PipelineStageId",
    "PipelineStageProps",
    "IPipelineStage",
    "StageRunnerComputeSize",
    "StageRunnerOS",
    "StageRunnerCPUArch",
    "StageRunnerProps",
    "IStageRunner",
    "IProvider",
    "MiscProps",
    "RepositoryAccessType",
    "RepositoryProps",
    "IRepository",
    "IUserGroup",
    "UserProps",
    "IUser",
    "VpnProps",
    "IVPN",
    "WorkbenchType",
    "WorkbenchCPUArch",
    "WorkbenchCreationProps",
    "IWorkbenchFactory",
    "WorkbenchProps",
    "IWorkbench",
    "ActiveDirectoryType",
    "ActiveDirectorySize",
    "ActiveDirectoryProps",
    "IActiveDirectory",
    "INotification",
    "IRegistry",
    "RegistryProps",
]
