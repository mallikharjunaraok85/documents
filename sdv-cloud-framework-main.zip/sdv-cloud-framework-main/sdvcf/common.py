from typing import Any, Dict, Optional

from constructs import Construct

from .aws import AWSCloudtrail, AWSProvider, AWSVpn, AWSVpnProps
from .azure import AzureVpn, AzureVpnProps
from .enums import ProviderAlias
from .interface import IVPN


class Common:
    def __init__(self, scope: Construct, config: Dict[str, Any]):
        self.scope = scope

        common_provider = config["common_provider"]

        common_provider = ProviderAlias[config["common_provider"]]
        for p_name, p_config in config["providers"].items():
            provider = ProviderAlias[p_name].value.Setup(self.scope, f"{p_name}-common", **p_config)
            if isinstance(provider, AWSProvider):
                logger = AWSCloudtrail(f"{provider.account_prefix}-{p_name}-logger")
                logger.cloudtrail

        # vpns creation
        for v_name, vpn in config["vpns"].items() if "vpns" in config else []:
            for p in vpn.get("providers", [common_provider.name]):
                provider = p if isinstance(p, dict) else {"name": p}
                cloud_vpn: Optional[IVPN] = None
                if provider["name"] == "aws":
                    cloud_vpn = AWSVpn(f"{v_name}-vpn", AWSVpnProps(cidr_blocks=vpn["cidr_blocks"]))
                elif provider["name"] == "azure":
                    cloud_vpn = AzureVpn(
                        f"{v_name}-vpn",
                        AzureVpnProps(
                            cidr_blocks=vpn["cidr_blocks"],
                            cidr_nat=config["providers"]["azure"].get("vpn_cidr_nat", None),
                        ),
                    )

                if cloud_vpn is not None:
                    cloud_vpn.Establish(vpn["device_ip_address"], vpn.get("device_name", None))
