# File: argparse_ext.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: Fr/12/2023 15:20:28
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

import argparse

# Workaround to override the entire module
from argparse import *  # NOQA # pyright: ignore [reportWildcardImportFromLibrary]
from typing import Any, List, Union


class _SubParsersAction(argparse._SubParsersAction):  # pyright: ignore [reportPrivateUsage, reportMissingTypeArgument]
    class _PseudoGroup(argparse.Action):
        def __init__(
            self,
            container: Union[
                argparse._SubParsersAction,  # pyright: ignore [reportPrivateUsage, reportMissingTypeArgument]
                "_SubParsersAction._PseudoGroup",
            ],
            title: str,
        ):
            super().__init__(option_strings=[], dest=f"{title}:")
            self.container = container
            self._choices_actions: List[argparse.Action] = []

        def add_parser(self, name: str, **kwargs: Any) -> Any:
            # Add the parser to the main Action, but move the pseudo action in the group's own list
            parser = self.container.add_parser(name, **kwargs)
            choice_action = self.container._choices_actions.pop()
            self._choices_actions.append(choice_action)
            return parser

        def _get_subactions(self) -> List[argparse.Action]:
            return self._choices_actions

        def add_parser_group(self, title: str) -> "_SubParsersAction._PseudoGroup":
            # The formatter can handle recursive subgroups
            grp = _SubParsersAction._PseudoGroup(self, title)
            self._choices_actions.append(grp)
            return grp

    def add_parser_group(self, title: str) -> "_SubParsersAction._PseudoGroup":
        grp = _SubParsersAction._PseudoGroup(self, title)
        self._choices_actions.append(grp)
        return grp


class ArgumentParserExt(argparse.ArgumentParser):
    def __init__(self, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self.register("action", "parsers", _SubParsersAction)
