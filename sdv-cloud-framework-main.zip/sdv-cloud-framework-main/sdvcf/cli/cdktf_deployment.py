# File: cdktf_deployment.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: Tu/11/2024 02:36:37
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import defaultdict
from enum import Enum, auto
from importlib.resources import as_file, files
from pathlib import Path
from typing import IO, Any, Callable, Dict, List, Optional, Tuple, Union

import yaml
from cdktf import App
from rich.console import Console
from yaml.representer import Representer

from sdvcf.utils import DomainType

from .interface import DeploymentEngineProps, IDeploymentEngine
from .prompt import Prompt

yaml.add_representer(defaultdict, Representer.represent_dict)


class ChangeType(Enum):
    Create = auto()
    Delete = auto()
    Change = auto()
    ReCreate = auto()


class CdktfProps(DeploymentEngineProps):
    skip_synth: bool

    def __init__(self, skip_synth: bool, **kwargs: Any) -> None:
        super().__init__(**kwargs)

        self.skip_synth = skip_synth


class CdktfDeploymentEngine(IDeploymentEngine):
    OUT_DIR = "sdvcf.out"
    OUTPUTS_FILE = "outputs.json"

    props: CdktfProps

    _console: Console
    _prompt: Prompt
    _log_file: str

    def __init__(self, props: CdktfProps) -> None:
        super().__init__(props)

        self._console = Console(log_path=False, width=sys.maxsize)
        self._prompt = Prompt()
        self._log_file = "cdktf-logs-%d.txt" % time.time()

    def Apply(self, config: Dict[str, Any], conf_dir: Path, work_dir: Path) -> bool:
        out_dir = (work_dir / self.OUT_DIR).absolute()
        if not self.props.skip_synth:
            self._Synth(config, conf_dir, out_dir)

        success: bool = self.props.dry_run
        if not self.props.dry_run:
            success = self._Deploy(work_dir, out_dir)
        return success

    def Destroy(self, config: Dict[str, Any], conf_dir: Path, work_dir: Path) -> bool:
        out_dir = (work_dir / self.OUT_DIR).absolute()
        if not self.props.skip_synth:
            self._Synth(config, conf_dir, out_dir)

        success: bool = False
        if self.props.auto_approve or self._prompt.yes_no(
            "Do you want to destroy the infrastructure described in the provided config?"
        ):
            # TODO: Implement interractive destruction
            with self._console.status("[bold green]Destroying SDV infrastructure...", spinner="aesthetic"):
                success = self._CDKTFDestroy("*", work_dir, out_dir)
        return success

    def _Synth(self, config: Dict[str, Any], conf_dir: Path, out_dir: Path) -> None:
        with self._console.status("[bold green]Synthesizing deployment scripts...", spinner="aesthetic") as status:
            app = App(outdir=str(out_dir))
            if self.props.domain == DomainType.common:
                from sdvcf.common import Common

                Common(app, config)
            elif self.props.domain == DomainType.project:
                from sdvcf.project import Project

                Project(app, config, conf_dir)
            app.synth()

            status.console.log("Deployment scripts have been synthesized")

    def _DisplayChanges(self, changes: Dict[ChangeType, Dict[str, List[str]]]) -> None:
        color_mapping = {
            ChangeType.Create: ("green", "Create", None),
            ChangeType.Change: ("yellow", "Change", None),
            ChangeType.Delete: ("red", "Destroy", None),
            ChangeType.ReCreate: ("orange3", "Re-Create", "(Destroy and then Create replacement)"),
        }
        status: str = "Plan: "
        for type, resources in changes.items():
            if not resources:
                continue

            count: int = 0
            self._console.log(
                f"[bold {color_mapping[type][0]}]{color_mapping[type][1]} the following"
                f" resources{color_mapping[type][2] or ''}:"
            )
            for category, elements in resources.items():
                self._console.log(f"[bold {color_mapping[type][0]}]{category}:")
                self._console.log(f"[{color_mapping[type][0]}]{yaml.dump(elements)}", emoji=False)
                count += len(elements)

            status += f"{count} to {color_mapping[type][1]}, "
        self._console.log(status.strip(", ") + ".")

    def _Deploy(self, work_dir: Path, out_dir: Path) -> bool:
        success: bool = False
        with self._console.status("[bold green]Deploying SDV infrastructure...", spinner="aesthetic") as status:
            if self.props.auto_approve:
                success = self._CDKTFDeploy("*", work_dir, out_dir)
            else:
                ordered_stacks, stack_dependencies = self._GetOrderedStacks(out_dir)
                for stack in ordered_stacks:
                    changes = self._CDKTFDiff(stack, work_dir, out_dir)
                    if changes is None:
                        self._console.log("[bold red]Abort: Failed during infrastructure check")
                        success = False
                        break

                    if all(not value for value in changes.values()):
                        self._console.log(f"`{stack}` stack has no changes. Infrastructure matches the configuration.")
                        continue
                    self._console.log(f"`{stack}` stack will be modified. Please, review the following changes:")
                    self._DisplayChanges(changes)

                    status.stop()
                    success = self._prompt.yes_no(f"Do you want to apply the changes to `{stack}` stack?")
                    if not success:
                        self._console.log(f"[bold red]Abort: Changes to `{stack}` stack have been discarded")
                        break
                    status.start()

                    success = self._CDKTFDeploy(stack, work_dir, out_dir, dependencies=stack_dependencies[stack])
                    if not success:
                        self._console.log(f"[bold red]Abort: Failed to apply `{stack}` stack changes")
                        break
        if success:
            self._console.log("All infrastructure changes have been successfully made")
            self._console.log(yaml.dump(self._FormatOutput(work_dir, out_dir)), emoji=False)

        return success

    def _FormatOutput(self, work_dir: Path, out_dir: Path) -> Dict[str, Dict[str, Dict[str, Any]]]:
        with self._console.status("[bold green]Genereting infrastructure description...", spinner="aesthetic"):
            out = self._CDKTFRunCommand(
                "output",
                ["--outputs-file", self.OUTPUTS_FILE, "*"],
                work_dir,
                out_dir,
            )
            if out is None:
                self._console.log("[bold red]Error: Failed to get deployment outputs")

            ret: Dict[str, Dict[str, Dict[str, Any]]] = defaultdict(lambda: defaultdict(dict))
            with open(f"{str(work_dir / self.OUTPUTS_FILE)}", "r") as stream:
                outputs: Dict[str, Dict[str, Any]] = json.load(stream)
                for stack_output in outputs.values():
                    for item in stack_output.values():
                        if (
                            "Type" not in item
                            or "ComponentName" not in item
                            or "Name" not in item
                            or "Value" not in item
                        ):
                            continue

                        ret[item["Type"]][item["ComponentName"]][item["Name"]] = item["Value"]
            return ret

    def _TransformResources(self, resources: List[str]) -> Dict[str, List[str]]:
        transformed_resources: Dict[str, List[str]] = {}
        for resource in resources:
            extracted_resources = self._ExtractQuotedWords(resource)
            if extracted_resources[0] not in transformed_resources:
                transformed_resources[extracted_resources[0]] = []
            transformed_resources[extracted_resources[0]].append(extracted_resources[1])
        return transformed_resources

    def _ExtractQuotedWords(self, text: str) -> List[str]:
        pattern = r'"([^"]+)"|\'([^\']+)\''
        matches = re.findall(pattern, text)
        return [word for match in matches for word in match if word]

    def _GetOrderedStacks(self, out_dir: Path) -> Tuple[List[str], Dict[str, List[str]]]:
        deps: Dict[str, List[str]] = {}
        ret: List[str] = []
        with open(f"{str(out_dir / 'manifest.json')}", "r") as stream:
            manifest: Dict[str, Any] = json.load(stream)
            stacks: Dict[str, Any] = manifest.get("stacks", {})

            def AddStack(cur_idx: int, stack: str) -> int:
                dependencies: List[str] = stacks[stack].get("dependencies", [])

                max_idx = 0
                for dep in dependencies:
                    idx = AddStack(cur_idx, dep)
                    if idx > max_idx:
                        max_idx = idx

                if stack not in ret:
                    deps[stack] = dependencies
                    ret.insert(max_idx, stack)
                else:
                    max_idx = ret.index(stack)
                    ret.insert(max_idx, ret.pop(max_idx))
                return max_idx + 1

            i: int = 0
            for stack in stacks:
                i = AddStack(i, stack)
        return (ret, deps)

    def _CDKTFDiff(self, stack: str, work_dir: Path, out_dir: Path) -> Optional[Dict[ChangeType, Dict[str, List[str]]]]:
        return self._CDKTFRunCommand("diff", [stack], work_dir, out_dir)

    def _CDKTFDeploy(self, stack: str, work_dir: Path, out_dir: Path, dependencies: List[str] = []) -> bool:
        success = (
            self._CDKTFRunCommand("deploy", ["--auto-approve", stack] + dependencies, work_dir, out_dir) is not None
        )
        if success:
            stack_message = f"`{stack}` stack has" if stack != "*" else "All stacks have"
            self._console.log(f"{stack_message} been successfully deployed")
        return success

    def _CDKTFDestroy(self, stack: str, work_dir: Path, out_dir: Path) -> bool:
        success = self._CDKTFRunCommand("destroy", ["--auto-approve", stack], work_dir, out_dir) is not None
        if success:
            stack_message = f"`{stack}` stack has" if stack != "*" else "All stacks have"
            self._console.log(f"{stack_message} been successfully destroyed")
        return success

    def _ParseCDKTFOutput(
        self, stream: Union[IO[str], str], work_dir: Path, callback: Optional[Callable[[str], None]] = None
    ) -> None:
        with open(work_dir / self._log_file, "a") as fp:
            for line in stream.splitlines() if isinstance(stream, str) else stream:
                line = line.strip()
                if line:
                    fp.write(f"{line}\n")
                    if callback is not None:
                        callback(line)
                    is_error = bool(re.match(r"^.*[Ee]rror(?: \[[0-9]+\])?: ", line))
                    if self.props.verbose or is_error:
                        self._console.log(f"[bold red]{line}" if is_error else line)

    def _CDKTFRunCommand(
        self, cmd: str, args: List[str], work_dir: Path, out_dir: Path
    ) -> Optional[Dict[ChangeType, Dict[str, List[str]]]]:
        with as_file(files("sdvcf.cli.resources").joinpath("cdktf.json")) as cdktf_json_template_path:
            cdktf_json_project_path = work_dir / "cdktf.json"
            if not cdktf_json_project_path.is_file():
                shutil.copyfile(cdktf_json_template_path, cdktf_json_project_path)
                self._console.log(f"Created missing file `{str(cdktf_json_project_path)}`")

        changes: Dict[ChangeType, List[str]] = defaultdict(list)

        def StoreChanges(line: str) -> None:
            changes[ChangeType.Create].extend(re.findall(r"^\+ resource \".*\" \".*\" \{$", line))
            changes[ChangeType.Delete].extend(re.findall(r"^\- resource \".*\" \".*\" \{$", line))
            changes[ChangeType.Change].extend(re.findall(r"^\~ resource \".*\" \".*\" \{$", line))
            changes[ChangeType.ReCreate].extend(re.findall(r"^\-/\+ resource \".*\" \".*\" \{$", line))

        with tempfile.NamedTemporaryFile() as buffer_file:
            with open(buffer_file.name, "w") as w_fp:
                with subprocess.Popen(
                    [
                        "cdktf",
                        cmd,
                        "--no-color",
                        "--output",
                        str(out_dir),
                        "--skip-synth",
                    ]
                    + args,
                    env={
                        "CHECKPOINT_DISABLE": "1",
                        "FORCE_COLOR": "0",
                        "CI": "1",
                        **os.environ,
                    },
                    cwd=work_dir,
                    stdin=subprocess.DEVNULL,
                    stdout=w_fp,
                    stderr=subprocess.PIPE,
                    bufsize=1,
                    universal_newlines=True,
                ) as p:
                    with open(buffer_file.name, "r") as r_fp:
                        while p.poll() is None:
                            self._ParseCDKTFOutput(r_fp, work_dir, StoreChanges)
                    _, err = p.communicate()
                    if p.returncode != 0:
                        self._ParseCDKTFOutput(f"Error [{p.returncode}]: {err.strip()}", work_dir)
                        return None

        transformed_changes: Dict[ChangeType, Dict[str, List[str]]] = {}
        for type, resources in changes.items():
            transformed_changes[type] = self._TransformResources(resources)
        return transformed_changes
