# File: prompt.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: Fr/12/2023 15:08:19
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

import ipaddress
from typing import List, Optional

from prompt_toolkit import prompt
from prompt_toolkit.application.current import get_app
from prompt_toolkit.auto_suggest import AutoSuggest, Suggestion
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.document import Document
from prompt_toolkit.validation import Validator


class AutoSuggestIPAddress(AutoSuggest):
    def __init__(self, pattern: str = ""):
        self._pattern = pattern or "10.20.10.42"

    def get_suggestion(self, buffer: Buffer, document: Document) -> Optional[Suggestion]:
        text = document.text_before_cursor

        if len(text) < 1:
            return Suggestion(self._pattern)

        parts = text.split(".")
        pparts = self._pattern.split(".")

        suggestion = ""
        parts_count = len(parts)
        if parts_count < 5 and text[-1] == ".":
            suggestion += pparts[max(parts_count - 1, 0)]
        if parts_count < 4:
            suggestion += "."
        suggestion += ".".join(pparts[parts_count:])

        return Suggestion(suggestion)


class AutoSuggestIPNetwork(AutoSuggestIPAddress):
    def __init__(self, pattern: str = ""):
        super().__init__()

        self._pattern, sep, self._pmask = (pattern or "10.0.0.0/16").partition("/")
        if not sep:
            raise ValueError(f"Invalid network pattern provided: {pattern}")

    def get_suggestion(self, buffer: Buffer, document: Document) -> Optional[Suggestion]:
        suggestion = super().get_suggestion(buffer, document)
        if suggestion:
            suggestion_text = suggestion.text
            _ip, mask_sep, mask = document.text_before_cursor.partition("/")

            if not mask_sep:
                suggestion_text += "/"
            if not mask:
                suggestion_text += self._pmask

            suggestion = Suggestion(suggestion_text)

        return suggestion


class Prompt:
    def non_empty(self, message: str) -> str:
        return prompt(message, validator=Prompt._non_empty_validator())

    def from_options(self, message: str, options: List[str], restrict: bool = True) -> str:
        return prompt(
            f"{message} ",
            completer=WordCompleter(options, True),
            validator=Prompt._options_validator(options) if restrict else Prompt._non_empty_validator(),
        )

    def ip(self, message: str, subnet: str = "") -> str:
        return prompt(
            message,
            validator=Prompt._ip_validator(subnet),
            auto_suggest=AutoSuggestIPAddress(subnet),
            pre_run=lambda: get_app().current_buffer.insert_text("", move_cursor=False),
        )

    def cidr(self, message: str, subnet: str = "") -> str:
        return prompt(
            message,
            validator=Prompt._cidr_validator(subnet),
            auto_suggest=AutoSuggestIPNetwork(subnet),
            pre_run=lambda: get_app().current_buffer.insert_text("", move_cursor=False),
        )

    def yes_no(self, message: str) -> bool:
        return self.from_options(message, ["Yes", "No"]).lower() == "yes"

    def provider(self, message: str, options: List[str]) -> str:
        return prompt(message, completer=WordCompleter(options, True), validator=Prompt._options_validator(options))

    @staticmethod
    def _non_empty_validator() -> Validator:
        return Validator.from_callable(lambda s: len(s) > 0, "The value can not be an empty string")

    @staticmethod
    def _options_validator(options: List[str]) -> Validator:
        return Validator.from_callable(
            lambda s: s.lower() in map(str.lower, options), "Value should be from the options list"
        )

    @staticmethod
    def _ip_validator(subnet: str = "") -> Validator:
        def _callable(value: str) -> bool:
            try:
                ip = ipaddress.IPv4Address(value)
                if subnet:
                    subnet_cidr = ipaddress.IPv4Network(subnet)
                    return ip in subnet_cidr
                return True
            except ValueError:
                return False

        return Validator.from_callable(
            _callable,
            f"IP Address is out of the subnet `{subnet}`" if subnet else "IP Address has invalid format",
        )

    @staticmethod
    def _cidr_validator(subnet: str = "") -> Validator:
        def _callable(value: str) -> bool:
            try:
                _address, net_sep, net_str = value.partition("/")
                net = int(net_str)
                if not net_sep or net < 16 or net > 28:
                    return False

                cidr = ipaddress.IPv4Network(value)
                if subnet:
                    subnet_cidr = ipaddress.IPv4Network(subnet)
                    return cidr != subnet_cidr and subnet_cidr.supernet_of(cidr)
                return True
            except ValueError:
                return False

        return Validator.from_callable(
            _callable,
            f"CIDR is out of the subnet `{subnet}`" if subnet else "CIDR has invalid format",
        )
