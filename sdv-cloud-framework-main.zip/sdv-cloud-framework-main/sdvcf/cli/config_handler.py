# File: config_handler.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: Th/03/2024 13:23:35
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

import argparse
import os
from functools import partial
from io import FileIO
from pathlib import Path
from typing import Any, Callable

import azure.identity
import boto3
import botocore

from sdvcf.utils import DeployConfigUtils

from .interface import IActionContext, IActionHandler


class ConfigAction(argparse.Action):
    def __init__(self, handler: Callable[..., IActionHandler], *argv: Any, **kargv: Any):
        super().__init__(*argv, **kargv)

        self.handler = handler

    def __call__(self, _parser: Any, namespace: argparse.Namespace, value: Any, _option_string: Any = None) -> None:
        setattr(namespace, "handler", partial(self.handler, value))


class ConfigHandler(IActionHandler):
    def __init__(self, config: FileIO, context: IActionContext) -> None:
        super().__init__(context)

        self.conf_dir = Path(str(config.name)).parent.absolute()
        self.config = DeployConfigUtils.load(self.context.d_engine.props.domain, config)

        self.verify_credentials()

    def verify_credentials(self) -> None:
        for p_name in sorted(self.config["providers"].keys()):

            if p_name == "aws":
                sts = boto3.client("sts")
                try:
                    sts.get_caller_identity()
                except botocore.exceptions.ClientError as e:  # pyright: ignore
                    raise e

            elif p_name == "azure":
                try:
                    credential = azure.identity.DefaultAzureCredential()
                    credential.get_token("https://management.azure.com/.default")
                except Exception as e:
                    raise e
            elif p_name == "github":
                try:
                    os.environ["GITHUB_TOKEN"]
                except KeyError:
                    raise OSError("Please, define environment variable GITHUB_TOKEN")

        for ls_config in self.config["license_servers"].values() if "license_servers" in self.config else {}:
            ls_type = ls_config["type"]
            if ls_type == "qnx":
                details = ls_config.get("details", {})
                if not (details.get("user_email", "") or os.getenv("QNX_LICENCE_SERVER_USER_EMAIL", "")):
                    raise OSError("Please, define environment variable QNX_LICENCE_SERVER_USER_EMAIL")
                if not (details.get("user_password", "") or os.getenv("QNX_LICENCE_SERVER_USER_PASSWORD", "")):
                    raise OSError("Please, define environment variable QNX_LICENCE_SERVER_USER_PASSWORD")
                if not (details.get("license", "") or os.getenv("QNX_LICENCE_SERVER_LICENSE", "")):
                    raise OSError("Please, define environment variable QNX_LICENCE_SERVER_LICENSE")

    def handle(self, args: argparse.Namespace) -> None:
        success = False
        if args.destroy:
            success = self.context.d_engine.Destroy(self.config, self.conf_dir, args.work_dir)
        else:
            success = self.context.d_engine.Apply(self.config, self.conf_dir, args.work_dir)

        exit(not success)
