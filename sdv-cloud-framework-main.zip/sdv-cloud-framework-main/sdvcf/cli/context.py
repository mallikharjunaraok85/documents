# File: context.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: We/12/2023 22:36:30
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

from typing import Any

from .cdktf_deployment import CdktfDeploymentEngine, CdktfProps
from .interface import IActionContext, IDeploymentEngine


class Context(IActionContext):
    _d_engine: CdktfDeploymentEngine

    def __init__(self, **kwargs: Any) -> None:
        self._d_engine = CdktfDeploymentEngine(CdktfProps(**kwargs))

    @property
    def d_engine(self) -> IDeploymentEngine:
        return self._d_engine
