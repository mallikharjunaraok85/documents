# File: i_action_handler.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: Mo/12/2023 20:19:04
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

from abc import ABC, abstractmethod
from argparse import Namespace
from typing import Any, Dict

from .i_deployment_engine import IDeploymentEngine


class IActionContext(ABC):
    @property
    @abstractmethod
    def d_engine(self) -> IDeploymentEngine: ...


class IActionHandler(ABC):
    config: Dict[str, Any]
    context: IActionContext

    def __init__(self, context: IActionContext) -> None:
        self.config = {}
        self.context = context

    @abstractmethod
    def handle(self, args: Namespace) -> None:
        """Apply the parsed parameters to the deployment"""
        ...
