# File: i_deployment_engine.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: Th/12/2023 12:55:33
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict

from sdvcf.utils import DomainType


class DeploymentEngineProps:
    domain: DomainType
    dry_run: bool
    auto_approve: bool
    verbose: bool

    def __init__(
        self, domain: str, dry_run: bool = False, auto_approve: bool = False, verbose: bool = True, **_: Any
    ) -> None:
        self.domain = DomainType[domain]
        self.dry_run = dry_run
        self.auto_approve = auto_approve
        self.verbose = verbose


class IDeploymentEngine(ABC):
    props: DeploymentEngineProps

    def __init__(self, props: DeploymentEngineProps) -> None:
        self.props = props

    @abstractmethod
    def Apply(self, config: Dict[str, Any], conf_dir: Path, work_dir: Path) -> bool: ...

    @abstractmethod
    def Destroy(self, config: Dict[str, Any], conf_dir: Path, work_dir: Path) -> bool: ...
