#!/usr/bin/env python3
# PYTHON_ARGCOMPLETE_OK
# `eval "$(register-python-argcomplete sdvcf-cli)"` to enable autocompletion

# File: cli.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: Th/03/2024 13:33:00
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

import os
import signal
import sys
import traceback
from sys import stderr
from types import FrameType
from typing import Optional

import argcomplete

from .context import Context
from .parser import Parser


def cancel_handler(signum: int, frame: Optional[FrameType] = None) -> None:
    print("\nCanceled by the User\n", file=stderr)
    exit(signum)


def cli() -> None:
    signal.signal(signal.SIGINT, cancel_handler)

    parser = Parser(os.path.basename(sys.argv[0]))
    argcomplete.autocomplete(parser.parser)

    args = parser.parse_args()
    try:
        if not hasattr(args, "handler"):
            args.help() if hasattr(args, "help") else parser.print_help()
        else:
            args.handler(Context(**args.__dict__)).handle(args)
    except Exception as e:
        print(f"Error: {e}", file=stderr)
        if hasattr(args, "verbose"):
            traceback.print_tb(e.__traceback__)
        exit(1)
    except KeyboardInterrupt:
        cancel_handler(1)


if __name__ == "__main__":
    cli()
