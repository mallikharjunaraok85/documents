# File: parser.py
# Project: sdv-cloud-framework
# Created Date: Mo/12/2023
# -----
# Last Modified: Th/12/2023 02:48:34
# -----
# Copyright (c) 2023 GlobalLogic, a Hitachi Group Company

from pathlib import Path
from typing import Optional

import pkg_resources

from .argparse_ext import Action, ArgumentParserExt, FileType, HelpFormatter, Namespace
from .config_handler import ConfigAction, ConfigHandler


class Parser:
    def __init__(self, prog: str):
        def formatter_class(prog: str) -> HelpFormatter:
            return HelpFormatter(prog, max_help_position=40, width=120)

        self.parser = ArgumentParserExt(
            formatter_class=formatter_class,
            prog=prog,
            conflict_handler="resolve",
            epilog='to enable autocomplete, execute:\n`eval "$(register-python-argcomplete sdvcf-cli)"`',
        )
        self.parser.add_argument(
            "--version",
            help="show cli and framework version number and exit",
            action="version",
            version=pkg_resources.require(__name__.split(".")[0])[0].version,
        )
        self.parser.add_argument(
            "--work-dir",
            help="specify the path to the directory to store deployment cache files",
            action="store",
            type=lambda x: Path(x),
            default=Path.cwd(),
        )
        self.parser.add_argument(
            "--dry-run",
            action="store_true",
            default=False,
            help="check whether infrastructure configuration is valid for deployment",
        )
        self.parser.add_argument(
            "--skip-synth",
            action="store_true",
            default=False,
            help="skip synthesis of the application, assume the synthesized scripts is already present and up to date",
        )
        self.parser.add_argument(
            "--verbose",
            action="store_true",
            default=False,
            help="print debug information to the standard output",
        )
        self.parser.add_argument(
            "-y",
            dest="auto_approve",
            action="store_true",
            default=False,
            help=(
                "automatically approve the deployment of the desired configuration "
                "without requiring any further confirmation. use this command with caution, "
                "as it can lead to unintended deployments if used incorrectly."
            ),
        )

        self.main_sub_parser = self.parser.add_subparsers(title="Business Unit Management", dest="domain")
        self._apply_init_subparser_branch()
        self._apply_common_subparser_branch()
        self._apply_project_subparser_branch()

    def print_help(self) -> None:
        self.parser.print_help()

    def parse_args(
        self,
        args: Optional[str] = None,
        namespace: Optional[Namespace] = None,
    ) -> Namespace:
        return self.parser.parse_args(args, namespace)  # type: ignore

    def _config_argument(self, parser: ArgumentParserExt) -> Action:
        config_metavar = Path("path/to/config.yaml")
        return parser.add_argument(
            "--config",
            metavar=str(config_metavar),
            help=f'replace "{config_metavar}" with the desired configuration file path to deploy infrastructure',
            action=ConfigAction,
            handler=ConfigHandler,
            type=FileType("r"),
        )

    def _destroy_argument(self, parser: ArgumentParserExt) -> Action:
        return parser.add_argument(
            "--destroy",
            action="store_true",
            default=False,
            help="destroy the entire infrastructure defined in the configuration file",
        )

    def _apply_init_subparser_branch(self) -> None:
        init = self.main_sub_parser.add_parser(
            "init",
            help=(
                "initialize the essential infrastructure required to configure the specific business unit's cloud "
                "infrastructure using the sdv cloud framework (Currently not implemented)"
            ),
            formatter_class=self.parser.formatter_class,
        )
        init.set_defaults(help=init.print_help)

    def _apply_common_subparser_branch(self) -> None:
        common = self.main_sub_parser.add_parser(
            "common",
            help="initialize common resources required to set up and manage the entire business unit environment",
            formatter_class=self.parser.formatter_class,
        )
        common.set_defaults(help=common.print_help)

        self._config_argument(common)
        self._destroy_argument(common)

    def _apply_project_subparser_branch(self) -> None:
        project = self.main_sub_parser.add_parser(
            "project",
            help="maintain project-specific infrastructure resources",
            formatter_class=self.parser.formatter_class,
        )
        project.set_defaults(help=project.print_help)

        self._config_argument(project)
        self._destroy_argument(project)
