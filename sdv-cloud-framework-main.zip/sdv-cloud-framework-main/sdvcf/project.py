import re
from collections import defaultdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, cast

from cdktf_cdktf_provider_archive.provider import ArchiveProvider
from cdktf_cdktf_provider_time.provider import TimeProvider
from cdktf_cdktf_provider_tls.provider import TlsProvider
from constructs import Construct

from .aws import (
    AWSCodeCommit,
    AWSEcr,
    AwsEksRunner,
    AwsEksRunnerProps,
    AwsQNXLicenseServer,
    AwsQNXLicenseServerProps,
    AWSRegistry,
    AWSUser,
    AwsUserGroup,
    AWSUserProps,
    AWSVpc,
    AWSVpn,
    AWSVpnProps,
    AWSWorkbenchFactory,
)
from .azure import (
    AzureRegistry,
    AzureRg,
    AzureUser,
    AzureUserProps,
    AzureVpn,
    AzureVpnProps,
    AzureWorkbenchFactory,
)
from .enums import ProviderAlias
from .github import GitHubHostedRunner, GitHubRepository, GitHubUser, GitHubUserGroup
from .interface import (
    IVPN,
    IPrivateCloud,
    IProvider,
    IRegistry,
    IRepository,
    IServiceMachine,
    IStageRunner,
    IUser,
    IUserGroup,
    IWorkbench,
    MiscProps,
    PipelineStageId,
    PipelineStageProps,
    PrivateCloudProps,
    RegistryProps,
    RepositoryAccessType,
    RepositoryProps,
    StageRunnerComputeSize,
    StageRunnerCPUArch,
    StageRunnerOS,
    StageRunnerProps,
    UserProps,
    WorkbenchCreationProps,
)


class Project:
    private_clouds: Dict[str, IPrivateCloud]

    def __init__(self, scope: Construct, config: Dict[str, Any], conf_dir: Path) -> None:
        self.scope = scope
        self.conf_dir = conf_dir

        self.private_clouds = {}

        common_provider = ProviderAlias[config["common_provider"]]

        for p_name, p_config in sorted(config["providers"].items(), key=lambda x: x[0] != common_provider.name):
            p_scope = common_provider.value.Instance() if p_config.get("backend", "") == "common" else self.scope
            provider = ProviderAlias[p_name].value.Setup(p_scope, f'{p_name}-{config["project"]}', **p_config)

            if p_name == "aws":
                self._ConfigureTlsProviderForStack(provider)
                self._ConfigureArchiveProviderForStack(provider)
                self._ConfigureTimeProviderForStack(provider)
                self.private_clouds[p_name] = AWSVpc(
                    f"{provider.name}-primary", PrivateCloudProps(p_config["region"], p_config["network"])
                )
            elif p_name == "azure":
                self._ConfigureTlsProviderForStack(provider)
                self.private_clouds[p_name] = AzureRg(
                    f"{provider.name}-primary", PrivateCloudProps(p_config["region"], p_config["network"])
                )

        # misc items creation
        for i_name, item in config["misc"].items() if "misc" in config else []:
            providers = item.get("providers", [common_provider.name])
            props = MiscProps(item["uri"], item["path"], i_name)
            if "aws" in providers:
                self.private_clouds["aws"].cloud_provider.AddMiscItem(props)

        # vpns creation
        for v_name, vpn in config["vpns"].items() if "vpns" in config else []:
            for p in vpn.get("providers", [common_provider.name]):
                provider = p if isinstance(p, dict) else {"name": p}
                p_name = provider["name"]
                cloud_vpn: Optional[IVPN] = None
                if p_name == "aws":
                    cloud_vpn = AWSVpn(f"{v_name}-vpn", AWSVpnProps(**{**vpn, **provider}))
                elif p_name == "azure":
                    cloud_vpn = AzureVpn(f"{v_name}-vpn", AzureVpnProps(**{**vpn, **provider}))

                if cloud_vpn is not None:
                    cloud_vpn.Attach(self.private_clouds[p_name])

        # registries creation
        registries: Dict[str, Dict[str, List[IRegistry]]] = defaultdict(dict)
        registry_policies = {}
        for p_storage in config["registries"] if "registries" in config else []:
            providers = p_storage.get("providers", [common_provider.name])
            if "aws" in providers:
                registries[p_storage["name"]]["aws"] = [
                    AWSRegistry(self.private_clouds["aws"], f'{p_storage["name"]}-1', props=RegistryProps(**p_storage)),
                    AWSEcr(self.private_clouds["aws"], f'{p_storage["name"]}-2', props=RegistryProps(**p_storage)),
                ]
                rp = registry_policies.get("aws", [])
                rp.extend([val.GetPolicyInfo() for val in registries[p_storage["name"]]["aws"]])
                registry_policies.update({"aws": rp})
            if "azure" in providers:
                registries[p_storage["name"]]["azure"] = [
                    AzureRegistry(self.private_clouds["azure"], p_storage["name"], props=RegistryProps(**p_storage))
                ]
                rp = registry_policies.get("azure", [])
                rp.extend([val.GetPolicyInfo() for val in registries[p_storage["name"]]["azure"]])
                registry_policies.update({"azure": rp})

        # groups creation
        groups: Dict[str, Dict[str, IUserGroup]] = defaultdict(dict)
        for g_name, group in config["groups"].items() if "groups" in config else []:
            providers = group.get("providers", [common_provider.name])
            if "github" in providers:
                groups[g_name]["github"] = GitHubUserGroup(g_name)
            if "aws" in providers:
                groups[g_name]["aws"] = AwsUserGroup(g_name)

        # users creation
        users: Dict[str, Dict[str, IUser]] = defaultdict(dict)
        for u_name, user in config["users"].items() if "users" in config else []:
            for p in user.get("providers", [common_provider.name]):
                if isinstance(p, dict):
                    provider = p
                    user.update({"username_suffix": p.get("username_suffix", "")})
                else:
                    provider = {"name": p}
                p_name = provider["name"]
                if p_name == "aws":
                    users[u_name][p_name] = AWSUser(self.private_clouds[p_name], u_name, AWSUserProps(**user))
                elif p_name == "azure":
                    assert "domain" in user, f"Missing required `domain` attribute for Azure User `{u_name}`"
                    users[u_name][p_name] = AzureUser(self.private_clouds[p_name], u_name, AzureUserProps(**user))
                elif p_name == "github":
                    users[u_name][p_name] = GitHubUser(u_name, UserProps(**user))

                # Adding users to groups
                for group in user["groups"] if "groups" in user else []:
                    assert group in groups, f"`{u_name}` user could not be assigned to missing group: `{group}`"
                    if p_name in groups[group]:
                        groups[group][p_name].AddUser(users[u_name][p_name])

        # repositories creation
        repos: Dict[str, Dict[str, IRepository]] = defaultdict(dict)
        for r_name, repo in config["repositories"].items() if "repositories" in config else []:
            access_type_mapping = {
                "owners": RepositoryAccessType.OWNER,
                "maintainers": RepositoryAccessType.MAINTAINER,
                "contributors": RepositoryAccessType.CONTRIBUTOR,
                "viewers": RepositoryAccessType.VIEWER,
            }
            provider_mapping = {
                "github": "github",
                "codecommit": "aws",
            }

            repo_type = repo["type"]

            if repo_type == "github":
                repos[r_name][repo_type] = GitHubRepository(r_name, RepositoryProps(**repo))
            elif repo_type == "codecommit":
                repos[r_name][repo_type] = AWSCodeCommit(r_name, RepositoryProps(**repo))

            for ug_type in repo["user_groups"] if "user_groups" in repo else []:
                assert ug_type in access_type_mapping, f"Unknown group of members specified: `{ug_type}`"
                for group in repo["user_groups"][ug_type]:
                    assert ("user" in group) ^ ("group" in group), (
                        f"Wrong `{r_name}` repository access configuration. "
                        "Either the `user` or `group` attribute should be specified."
                    )
                    repo_handler_f = getattr(repos[r_name][repo_type], "AddUser" if "user" in group else "AddGroup")
                    principal = cast(
                        Dict[str, Union[IUser, IUserGroup]],
                        users[group["user"]] if "user" in group else groups[group["group"]],
                    )
                    if "user" in group and not users[group["user"]]:
                        raise AttributeError(
                            f"Attempted to create {repo_type} repository with non-existent user {group['user']}"
                        )
                    if "group" in group and not groups[group["group"]]:
                        raise AttributeError(
                            f"Attempted to create {repo_type} repository with non-existent group {group['group']}"
                        )
                    repo_handler_f(
                        principal[provider_mapping[repo_type]],
                        access_type_mapping[ug_type],
                        group.get("expiry_date", None),
                    )

            if "pipeline" in repo:
                pipeline = repos[r_name][repo_type].CreatePipeline()
                for s_name, s_config in repo["pipeline"].items():
                    s_id = PipelineStageId[re.sub(r"[-_.]+", " ", s_name).title().replace(" ", "")]
                    s_config = defaultdict(dict) if s_config is None else s_config
                    pipeline.CreateStage(
                        self._CreateRunnerForStage(
                            repo["type"], repos[r_name][repo["type"]], s_id, s_config, registry_policies
                        ),
                        PipelineStageProps(
                            name=s_id,
                            container=str(s_config.get("container", None)),
                            timeout=str(s_config.get("timeout", None)),
                            provider_name=(
                                f'aws-{config["project"]}'
                                if repo.get("artifacts_storage", {}).get("storage_type") == "s3"
                                else ""
                            ),
                        ),
                    )
                pipeline.Commit()

            repos[r_name][repo_type].Commit()

        # workbenches creation
        workbenches: Dict[str, List[Tuple[str, IWorkbench]]] = defaultdict(list)
        for workbench in config["workbenches"] if "workbenches" in config else []:
            for p in workbench.get("providers", [common_provider.name]):
                provider = p if isinstance(p, dict) else {"name": p}
                p_name = provider["name"]

                class FactoryType(Enum):
                    aws = AWSWorkbenchFactory
                    azure = AzureWorkbenchFactory

                for u_name in workbench["users"]:
                    if not users[u_name]:
                        raise AttributeError(f"Attempted to create {p_name} workbench with non-existent user {u_name}")
                    rp = registry_policies.get(p_name, [])
                    props = WorkbenchCreationProps(**workbench, registry_policies=rp)
                    # add registry to WB dist.info
                    for wb_registry in props.registries:
                        if (
                            wb_registry["name"] in registries.keys()
                            and registries[wb_registry["name"]][p_name] is not None
                        ):
                            wb_registry.update(
                                {
                                    # hardcoded first element AWSRegistry as we omit AWSEcr here
                                    "url": registries[wb_registry["name"]][p_name][0].GetURL(),
                                    "release": "stable",
                                    "components": "main",
                                }
                            )
                        elif isinstance(wb_registry["components"], list):
                            wb_registry["components"] = " ".join(wb_registry["components"])
                    props.blueprints = {
                        str((self.conf_dir / script).absolute()): params for script, params in props.blueprints.items()
                    }
                    workbenches[u_name].append((p_name, FactoryType[p_name].value.Create(users[u_name][p_name], props)))

        # license servers creation
        license_servers: Dict[str, List[Tuple[str, IServiceMachine]]] = defaultdict(list)
        for ls_name, ls_config in config["license_servers"].items() if "license_servers" in config else {}:
            ls_type = ls_config["type"]
            for p in ls_config.get("providers", [common_provider.name]):
                provider = p if isinstance(p, dict) else {"name": p}
                p_name = provider["name"]
                if p_name == "aws":
                    if ls_type == "qnx":
                        license_servers[ls_type].append(
                            (
                                p_name,
                                AwsQNXLicenseServer(
                                    self.private_clouds[p_name],
                                    ls_name,
                                    AwsQNXLicenseServerProps(**ls_config.get("details", {})),
                                    acl=ls_config.get("acl", []),
                                ),
                            )
                        )

        for cloud in self.private_clouds.values():
            cloud.provider.CommitDashboard()

    def _ConfigureTlsProviderForStack(self, stack: IProvider) -> None:
        TlsProvider(stack, f"tls-{stack.name}")

    def _ConfigureArchiveProviderForStack(self, stack: IProvider) -> None:
        ArchiveProvider(stack, f"archive-{stack.name}")

    def _ConfigureTimeProviderForStack(self, stack: IProvider) -> None:
        TimeProvider(stack, f"time-{stack.name}")

    def _CreateRunnerForStage(
        self,
        repo_type: str,
        repo: IRepository,
        s_id: PipelineStageId,
        s_config: Any,
        registry_policy_info: Dict[str, List[Any]] = {},
    ) -> IStageRunner:
        runner_type = s_config.get("runner", repo_type)
        runner_name = f"{repo.name}-{s_id.value}"

        compute_size = StageRunnerComputeSize[s_config.get("compute_size", StageRunnerComputeSize.Small.name)]
        os = StageRunnerOS[s_config.get("os", StageRunnerOS.Linux.name)]
        arch = StageRunnerCPUArch[s_config.get("arch", StageRunnerCPUArch.x86_64.name)]

        props = {
            **s_config,
            "compute_size": compute_size,
            "os": os,
            "arch": arch,
        }
        if runner_type == "github":
            return GitHubHostedRunner(runner_name, StageRunnerProps(**props))
        elif runner_type == "eks":
            return AwsEksRunner(
                self.private_clouds["aws"],
                runner_name,
                repo,
                AwsEksRunnerProps(**props, registry_policy_info=registry_policy_info["aws"]),
            )
        else:
            raise NotImplementedError(f"`{runner_type}` runner support not implemented yet")
