# QuickStart

## 1. Configure AWS credentials

 1. Verify that your AWS account has sufficient access. You can create a policy with the required permissions using
    [minimal_aws_iam_access.yaml](files/minimal_aws_iam_access.yaml) file contents.

 2. Create AWS Authentication Credentials:

    Follow the steps outlined in the [AWS guide](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_access-keys.html#Using_CreateAccessKey) to create AWS access keys.

 3. Set Environment Variables:

    Once you have obtained the access key ID and secret access key, set them as environment variables on your local machine.
    Open your terminal or command prompt and execute the following commands:
    ```sh
    export AWS_ACCESS_KEY_ID=<your_access_key_id>
    export AWS_SECRET_ACCESS_KEY=<your_secret_access_key>
    ```
    Replace ```<your_access_key_id>``` and ```<your_secret_access_key>``` with the values you obtained when creating the AWS access keys.

    Setting these environment variables allows the **sdvcf-cli** tool to authenticate with AWS using the provided credentials.

With AWS credentials configured, you are now ready to proceed to the next steps in setting up and deploying your infrastructure.

## 2. Create configuration file

Create a YAML file to define the infrastructure configurations for your project.
Let's name the project **sdvcf** and set the AWS provider as common_provider.
Configure the AWS provider with the desired region and network CIDR for the Virtual Private Cloud (VPC).
Detailed information about variables.yaml file usage can be found following the [link](VariablesYAMLUsage.md).

Here's an example YAML configuration file:
```yaml
project: sdvcf

common_provider: aws
providers:
  aws:
    region: eu-west-1
    network:
      cidr: 10.0.0.0/16
```
Create user with name **sdv-user**
```yaml
users:
  sdvcf-user:
    providers: ["aws"]
```
Create **ComputeServer** workbench for **sdv-user**
```yaml
workbenches:
  - providers: ["aws"]
    users: ["sdvcf-user"]
    type: ComputeServer
    cpu_arch: ARM64
    vcpu: 2
    ram_gib: 2
    backup:
      retention_days: 1
```

## 3. Check whether infrastructure configuration is valid

Before proceeding with the actual deployment, it is crucial to ensure that your infrastructure configuration is valid.
This dry-run mode will simulate the deployment process without making any actual changes to your infrastructure.
Review the output to confirm that all the specified configurations are correct and that there are no errors or misconfigurations.
Taking this precautionary step helps catch any potential issues before the actual deployment, ensuring a smoother and error-free setup process.
Once you've confirmed the validity of your configuration in dry-run mode, proceed to the next step to deploy the infrastructure.

To do this, run the following command in dry-run mode using **sdvcf-cli**:

```sh
$> sdvcf-cli --dry-run project --config variables.yaml
[21:50:12] Deployment scripts have been synthesized
```


## 4. Deploy infrastructure

Once the successful checks are complete, proceed with deploying the infrastructure using the following command:

```sh
$> sdvcf-cli project --config variables.yaml
```
Review the output to confirm the resources that will be deployed. If everything looks correct, type **Yes** and patiently wait for the resources to be provisioned.

![sdvcf-cli resources](./images/sdvcf-cli_resources.png)

After the deployment is complete, you will receive important information as outputs.
This includes credentials for the **sdvcf-user** user and the IP address of the ComputeServer workbench along with login credentials.

![sdvcf-cli deploy outputs](./images/sdvcf-cli_deploy_outputs.png)

Use these credentials to access the deployed infrastructure.
This marks the successful deployment of your environment, and you are now ready to utilize the resources for your project.

## 5. Destroy deployed infrastructure

To destroy the deployed resources, use the following command:

```sh
$> sdvcf-cli project --destroy --config variables.yaml
```

You will be prompted to confirm the destruction of resources.
Type **Yes** to approve the destruction, and wait for the resources to be terminated.

This step is crucial if you want to free up resources and avoid unnecessary costs once your project is completed.

**Always exercise caution when performing destructive actions to avoid unintended consequences.**

After the destruction process is complete, your infrastructure will be successfully torn down, and resources will be released.

![sdvcf-cli destroy output](./images/sdvcf-cli_destroy_output.png)