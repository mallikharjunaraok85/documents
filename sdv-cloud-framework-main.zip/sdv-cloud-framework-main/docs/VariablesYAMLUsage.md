# The Usage of `variables.yaml`

## Introduction
Welcome to the SDV Cloud Framework `variables.yaml` usage description. This document provides overview of the `variables.yaml` structure, description of all its elements, and best practices to help you set up necessary cloud infrastructure within SDV Cloud Framework.

## Getting Started

### Brief Overview
The `variables.yaml` file is essential in the SDV Cloud Framework, acting as the blueprint for your infrastructure. Written in [YAML format](https://yaml.org/spec/1.2.2), it details the infrastructure for specific projects or common resources. Modifications in this file are dynamically reflected by the SDV Cloud Framework utilities in the specified providers.

### Basic Example

- **Purpose:** Demonstrates setting up a basic SDVCF Workbench in the AWS environment for a single user.
- **Example `variables.yaml`:**
  ```yaml
  ---
  project: project-example

  providers:
    aws:
      region: eu-west-1
      network:
        cidr: 10.42.0.0/22

  common_provider: aws

  users:
    example-user: {}

  workbenches:
    - users:
        - example-user
      type: VirtualDesktop
      cpu_arch: ARM64
  ```
- **Functionality:**
  - Sets up an AWS Provider.
  - Creates a user account `example-user`.
  - Deploys a workbench with a graphical interface.


### Explanation of Example Objects
- `project`: Identifies all deployed resources under the project name.
- `common_provider`: Defaults to `AWS` for deploying resources.
- `users`: Defines `example-user` for AWS Console access and workbench usage.
- `workbenches`: Establishes a `Virtual Desktop` accessible with `example-user` credentials.

The example illustrates the minimal configuration required to establish SDVCF Workbenches, highlighting the simplicity and flexibility of the SDV Cloud Framework.

## Specification to `variables.yaml` Entities

The `variables.yaml` can be used in two domains:
- **Common Resources Domain:** Configures resources shared across all projects within a business unit or company.
- **Project Resources Domain:** Manages resources for specific projects, allowing multiple `variables.yaml` files for different projects within the same business unit or company.

Both domains follow similar concepts, but their configuration blocks differ.

### Essential Entities

- **Principles:** Both common and project resources adhere to the same definition and configuration principles.
- **`providers` Property**:
  - **Omitted:** If not specified, resources deploy within the `common_provider`.
  - **Specified:** Lists multiple providers. Resources deploy in each mentioned provider.
    ```yaml
    ---
    # Example
    resource:
      resource-name:
        providers:
          - aws
          - azure
    ```
- **Provider Specific Parameters**: Can include unique parameters for each resource type and provider.
  ```yaml
  ---
  # Example
  resource:
    resource-name:
      providers:
        - name: aws
          external_gateway: <TGW_ID>
  ```


*`providers`

#### AWS Provider Configuration
- `region`: Specifies a [valid AWS region](https://aws.amazon.com/about-aws/global-infrastructure/regional-product-services) for deployment *(e.g. `eu-west-1`, `us-east-1`, etc.)*.
```yaml
---
# Example
providers:
  aws:
    region: eu-west-1
```

#### Azure Provider Configuration
- `region`: Specifies a [valid Azure region](https://azure.microsoft.com/explore/global-infrastructure/geographies) for deployment *(e.g. `West Europe`, `North Europe`, etc.)*.
```yaml
---
# Example
providers:
  azure:
    region: West Europe
```

#### GitHub Provider Configuration
- `organization`: Refers to the GitHub organization for resource allocation.
- `backend` *(Optional)*: Allows using another provider for deployed resources state management.
```yaml
---
# Example
providers:
  github:
    organization: Some-Org
    backend: aws
```

#### `common_provider`
Specifies the default provider for unspecified resources. Should be one of configured `providers`.
```yaml
---
# Example
common_provider: aws
```

### Common Domain Entities
The common domain is intended for resources shared across all projects within a business unit or company.

*`providers`
**Additional Properties** for specific providers:
- **Azure Provider Configuration:**
  - `vpn_cidr_nat`: Specifies a valid IPv4 CIDR for the VPN gateway subnet.
    ```yaml
    ---
    # Example
    providers:
      azure:
        vpn_cidr_nat: 10.248.255.0/24
        ... # Omitted configuration details
    ```

#### `vpns`
A dictionary with the VPN name as the key and its properties as the value.
- `cidr_blocks`: Lists valid IPv4 CIDRs for onsite IP ranges exposed to providers.
- `device_ip_address`: Specifies the IP address for VPN tunnel termination device onsite.
- `device_name` *(Optional)*: Describes the device used for the VPN tunnel, aiding future maintenance.
```yaml
---
# Example
vpns:
  primary: # VPN name is `primary`, can be used to identify all related resources
    providers: ["aws", "azure"]
    cidr_blocks: # Onsite subnets to be exposed to AWS and Azure private clouds
      - 1.2.3.4/24
    device_ip_address: 4.3.2.1
    device_name: "Cisco ASA 5555, SW Version 9.14(3)18"
```

### Project Domain Entities
The project domain is intended for resources that are supposed to be provisioned within one project or business unit of the company.

#### `project`
Specifies the name of the project. It is used in cloud resources names and tags.
```yaml
---
# Example
project: sdvcf-project
``` 

*`providers`
Configures base provider infrastructure needed for the project (network, project storage).

**Additional Properties** for specific providers:
- **AWS provider configuration:**
  - `network`: dictionary that contains provider network configuration:
    - `cidr`: project subnet IPv4 CIDR address
    - Optionally, 6 project subnets can be configured in this block (`primary`, `secondary`, `eks_primary`, `eks_secondary`, `public`, `nat`):
      - `<SUBNET_TYPE>_subnet_cidr`: IPV4 CIDR of the specified subnet
      - `<SUBNET_TYPE>_subnet_az`: [Availability zone](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/using-regions-availability-zones.html#az-ids) for the specified subnet
  - `notifications` *(Optional)*: Dictionary that specifies notifications subscriptions block. The key is subscription name, the value is list of emails which are supposed to be subscribed on specified notifications.
    - It is possible to subscribe to `workbenches`, `network`, `runners`.
```yaml
---
# Example
aws:
  region: eu-west-1
  network:
    cidr: 10.10.0.0/16
    primary_subnet_cidr: 10.10.1.0/24
    primary_subnet_az: eu-west-1a
    secondary_subnet_cidr: 10.10.2.0/24
    secondary_subnet_az: eu-west-1b
  notifications:
    workbenches: &notification-subscribers
      subscribers: ["administrator@company.com"]
    runners:
      <<: *notification-subscribers
    network:
      <<: *notification-subscribers
``` 

- **Azure provider configuration:**
  - `network`: dictionary that contains provider network configuration:
    - `cidr`: project subnet IPv4 CIDR address
    - `<SUBNET_TYPE>_subnet_cidr` *(Optional)*: IPV4 CIDR of the specified subnet (it is possible to configure only `primary` subnet in Azure).
```yaml
---
# Example
azure:
  region: "West Europe"
  network:
    cidr: 10.10.0.0/16
    primary_subnet_cidr: 10.10.1.0/24
```

#### `vpns` with providers
 A dictionary with the VPN name as the key and its properties dictionary as the value.  
 It is required to set up VPN for `Azure` and `AWS` providers.
 - `providers`: list of providers to setup VPN Transit Gateway.
   - Provider entry for `AWS`, optionally, can be described with external gateway using this scheme:
     - `name`: provider name.
     - `external_gateway`: ID of the `Transit Gateway` resource in AWS
 - `cidr_blocks`: List of IPv4 CIDR blocks. Could be a list of local subnets used for the project or specific address space to be exposed to the specified clouds.
```yaml
---
# Example
vpns:
  primary:
    providers:
      - name: aws
        external_gateway: tgw-xxx
      - azure
    cidr_blocks:
      - 10.10.1.0/24 # e.g subnet for developers
      - 10.10.2.0/24 # subnet for CI workers or test nodes
```

#### `groups`
In SDVCF, there is a possibility to embody users with similar characteristics into groups. It allows to manage infrastructure for all users it the specified group at one time, instead of specifying each user separately. It is a dictionary with a name of the group as a key and a list of providers, where to set up those groups as value:
```yaml
---
# Example
groups:
  contributor-team:
    providers: ["github", "aws"]
  maintainer-team:
    providers: ["github", "aws"]
```

#### `repositories`
Defines repositories within the project. Consists of the list of dictionaries with the name of the repository as key and properties dictionary as a value.
Repository does not manage GitHub Pages (ignore_changes).
- `type`: repository host (`github` or `codecommit`).
- `auto_init` *(Optional)*: Automatic repository initialization. Boolean value.
- `autolink` *(Optional)*: Add links to an external issue/task tracker. WARNING: Requires the GitHub Pro subscription. Dict[Dict[str, str]] value.
- `allow_reuse_pipeline` *(Optional)*: Allows to reuse GitHub Actions workflows within organization repositories.
- `is_global` *(Optional)*: Specifies if the repository is global. Boolean value.
- `is_permanent` *(Optional)*: Specifies if the repository is permanent. Archive the repository on destroy if true. Boolean value. Default true.
- `is_public` *(Optional)*: Specifies if the repository is public. Boolean value.
- `has_issues` *(Optional)*: Specifies if issues are enabled. Boolean value.
- `default_branch` *(Optional)*: Specifies the name of the default branch.
- `description` *(Optional)*: Description of the repository.
- `user_groups` *(Optional)*: Describes users of the repository and their access policies. Dictionary with one of keys that specify repository access mode (`maintainers`, `contributors`, `viewers`) and list as a value with dictionary of 2 properties: `user` or `group` (from `groups`) and, optionally, `expiry_date`.
- `merge_options` *(Optional)*: A list that describes allowed merge options:
  - Allowed values are:
    - `merge_commit`
    - `rebase_merge`
    - `squash_merge`
- `protection_rule` *(Optional)*: A dictionary that describes branch protection rule:
  - Properties of protection rule:
    - `branch_names`: List of branch name patterns to apply protection rules.
    - `reviewers` *(Optional)*: Describes required Pull Request reviewers users of the repository. List as a value with dictionary of 2 properties: `user` or `group` (from `groups`).
- `pipeline` *(Optional)*: A dictionary that describes pipelines setup for the repository.
  - Allowed key values are:
    - `static-analysis`
    - `build`
    - `unit-test`
    - `build-image`
    - `integration-test`
    - `system-test`
    - `release`
  - Properties of the specific pipeline:
    - `container`: The name of the container.
    - `timeout`: timeout in minutes.
    - `compute_size`: Compute node scale (`Small`, `Medium`, `Large`).
    - `arch`: Compute node architecture (`Arm64`, `x86_64`).
    - `os`: Compute node OS (`Linux`, `Windows`).
    - `runner`: the name of the runner (`eks`).
    - `scaling_max`: Maximum scaling number for eks pods. Integer value.
```yaml
---
# Example
repositories:
  github-repo:
    type: github
    is_global: true
    has_issues: true
    autolinks:
      key_prefix: PROJ-
       target_url_template: https://jira.com/<num>
    allow_reuse_pipeline: true
    user_groups:
      maintainers:
        - user: project-maintainer
        - group: maintainer-team
    protection_rule:
      branch_names:
        - "release/*"
      reviewers:
        - user: project-maintainer
        - group: maintainer-team
    pipeline:
      build:
        container: alpine:latest
        timeout: 240
        compute_size: Small
        arch: Arm64
        os: Linux
        runner: eks
  codecommit-repo:
    type: codecommit
    user_groups:
      maintainers:
        - user: project-maintainer
          expiry_date: 2025-01-01
```

#### `users`
Describes user accounts within the project. Manages a provider account within the scope of the project, sets up required accesses and permissions. Dictionary with username as a key and account properties as a value.
- `providers` *(Optional)*: The list of providers where to setup account for specified user.
     - `name`: provider name.
     - `username_suffix`: *(Optional)*: GitHub username suffix
- `display_name` *(Optional)*: The name of the user.
- `domain` *(Optional)*: email domain if user is external.
- `external` *(Optional)*: Specifies if user is external. Boolean value.
- `groups` *(Optional)*: The list of groups which are the user is part of.
```yaml
---
# Example
users:
  john.doe:
    providers: ["github"]
    groups:
      - contributor-team
      - maintainer-team

  john.doe:
    providers:
      - name: "github"
        username_suffix: -gl # turns into "john-doe-gl"
    groups:
      - contributor-team
      - maintainer-team

  jane.doe:
    providers: ["azure"]
    domain: gmail.com
    external: true
``` 

#### `misc`
Describes miscellaneous items (files) that can be used across the project (e.g Virtual Workbench blueprints). Upload files into project cloud storage.
Dictionary with item name as a key and its properties as a value.
- `providers`: The list or dict of providers where to upload item.
- `uri`: Source address of the file. Could be either local path or `S3` URI if `AWS` provider is specified,.
- `path`: Path, where the file would be stored in the misc cloud storage of the specified providers. Note, that this is not an absolute path and SDVCF may add additional prefixes to it.
```yaml
---
# Example
misc:
  item:
    providers: ["aws", "azure"]
    uri: s3://project-misc-storage/path/to/file
    path: /path/to/file
``` 

#### `workbenches`
Describes Virtual Workbenches setup for the project.
The Virtual Workbench, is a remote computing solution optimized for user tasks. It provides secure, scalable, and resource-efficient workspace, eliminating the need for physical hardware management. This feature enhances collaboration and streamlines development workflows in a cloud environment. 
List of a dictionaries of workbenches properties.
Each list entry describes one setup of the workbench for specified users.
- `users`: The list of users of the workbench. Separate dedicated Virtual Workbench will be set up for every user.
- `type`: The type of the workbench (`ComputeServer`, `VirtualDesktop`, `WebIDE`).
- `cpu_arch` *(Optional)*: Workbench CPU architecture (`ARM64`, `AMD64`).
- `vcpu` *(Optional)*: Quantity of vCPUs (threads) for the workbench.
- `ram_gib` *(Optional)*: RAM size for the workbench.
- `os` *(Optional)*: OS of the workbench (`Ubuntu22.04`, `Ubuntu20.04`, `Ubuntu18.04`)
- `registries` *(Optional)*: The list of registries to be included to the workbench environment. Can be one of the following:
  - Global registries:
    - `name`: the name of the global registry
    - `url`: the URL of the global registry
    - `release`: the release version of the global registry
    - `components`: the list of components of the global registry
  - SDVCF registries:
    - `name`: the name of the SDVCF registry. Note: Should match the corresponding name specified in the config.
- `backup` *(Optional)*: Dictionary with properties of the workbench backup policy:
  - `schedule` *(Optional)*: Backup schedule, using [Cron Expression](https://docs.oracle.com/cd/E12058_01/doc/doc.1014/e12030/cron_expressions.htm). For AWS, `Day of Week` parameter is omitted. For Azure, `Year` parameter is omitted.
  - `retention_days` *(Optional)*: Retention period of the backup
- `blueprints` *(Optional)*: Dictionary which describes attached workbench setup scripts with script path as a key and `parameters` dictionary as a value.
  - Parameters is a dictionary with script variable as a key (e.g `$(user)` in sh scripts) and a value which will replace that alias. There are reserved values that are processed during synth:
    - `$sdvcf_user`: username from `user` section.
    - `$sdvcf_region`: cloud region.
    - `$sdvcf_miscBucket`: Misc bucket id (for `AWS`).
    - Misc items can be used with blueprints using this option:
      - `$sdvcf_misc_{MISC_ITEM_KEY}`: Misc item key (from `misc` section).
```yaml
---
# Example
workbenches:
  - providers: ["aws", "azure"]
    users: ["john.doe", "jane.doe"]
    type: ComputeServer
    cpu_arch: ARM64
    vcpu: 2
    ram_gib: 2
    backup:
      retention_days: 1
    blueprints:
      "setup.sh":
        user: ubuntu

  - providers: ["aws"]
    users: ["john.doe"]
    type: VirtualDesktop
    backup:
      retention_days: 1

  - providers: ["aws"]
    users: ["sdv-user"]
    type: WebIDE
    vcpu: 2
    ram_gib: 8
``` 

#### `license_servers`
Describes license servers to set up within the project.
Dictionary with license server name as a key and its properties as a value.
- `providers`: The list of providers where to set up license server.
- `type`: Type of the license server (`qnx`).
- `details` *(Optional)*: the dictionary with license server details.
- `acl` *(Optional)*: The access control list. Dictionaries with `type` (can be only `subnet`) and `name` properties.
```yaml
---
# Example
license_servers:
  project-QNX:
    providers: ["aws"]
    type: qnx
    acl:
      - type: subnet
        name: ProjectEKS
```

#### `registries`
Describes registries that is used to store configuration of the development environment on Workbenches.

There are two type of registries created for each provider:
1) `Package repository`:
    - `AWS`: `S3 Bucket`.
    - `Azure`: `Blob Storage`.
2) `Container registry`:
     - `AWS`: `ECR`.
     - `Azure`: `ACR`.

Dictionary with item name as a key and its properties as a value.
- `providers`: A list of providers to which the item should be uploaded.
- `name`: The name of the registry
- `is_public` *(Optional)*: Specifies if the repository is publicly available. Boolean value. False by default.
- `retention` *(Optional)*: A dictionary that describes retention policies for the registry. This is applicable only for AWS S3 Buckets and includes the following keys:
  - `days`: An integer representing the number of days after which the objects will expire.
  - `tags`: A dictionary of key-value pairs representing tags used to identify the objects to which the retention policy will apply.
```yaml
---
# Example
registries:
  - providers: ["aws"]
    name: some-registry1
  - providers: ["aws"]
    name: some-registry2
    retention:
      days: 30
      tags:
        To: Delete

```

## Best practices

When configuring `variables.yaml`, following best practices can greatly enhance the file's readability and maintainability. Here are some key recommendations:

### Logical Order
Organizing the `variables.yaml` file in a logical sequence is crucial for readability and understanding.

- **Project-Wide Infrastructure First:** Begin with overarching configurations before delving into specifics. The recommended order is:
  - `project`: Define the project name first *(if it's applicable to domain)*.
  - `common_provider`: Specify the default provider.
  - `providers`: Detail the individual providers.
  - **Specific Infrastructure:** Follow this by defining specific infrastructures like `users`, `repositories`, `vpns`, etc.
- **Dependency Order:** Define infrastructure elements in the order of their dependency.
  - *Example:* Define `users` before `workbenches`, as the latter relies on the former.

### YAML Anchors and Aliases
Utilizing [YAML Anchors and Aliases](https://yaml.org/spec/1.2.2/#692-node-anchors) can significantly streamline the configuration process and reduce redundancy.

- **Purpose:** These YAML features allow you to reuse configurations and extend existing data nodes, minimizing repetitive syntax.
- **Advantages:**
  - Reduces boilerplate YAML configuration.
  - Enhances clarity and maintainability.
  - Simplifies updates and changes to similar resources.
- **Example Usage:**
  ```yaml
  ---
  # Example
  workbenches: &default_wb
    - providers: ["aws"]
      users:
        - user1
        - user2
        - user3
      type: ComputeServer
      cpu_arch: ARM64
      vcpu: 2
      ram_gib: 2
      backup:
        retention_days: 1
      blueprints:
        blueprint1.sh: {}
        blueprint2.sh: {}
        blueprint3.sh: {}

    - <<: *default_wb
      vcpu: 4
      ram_gib: 32
      type: VirtualDesktop

    - <<: *default_wb
      type: WebIDE
      cpu_arch: AMD64
  ```
  In this example, the `&default_wb` anchor defines a default configuration for workbenches. The `<<: *default_wb` syntax is then used to reuse this configuration while allowing for modifications specific to each workbench type, such as `VirtualDesktop` and `WebIDE`.
