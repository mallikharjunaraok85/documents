# GitHub Usage with the SDV Cloud Framework

This document provides an overview of the GitHub features brought by SDVCF.

## Source code access
To begin working with a repository, follow these steps:

1. **Retrieve GitHub Credentials**
   Obtain your GitHub credentials from your Manager. This is a crucial step to ensure you have the necessary permissions to access the repositories you'll be working with.

2. **Log in to Workbench**
   Access your development environment by logging in to Workbench. For a step-by-step guide on how to do this, refer to the [Workbench Guide](VirtualWorkbenchGuide).

3. **Clone a Repository**
   You can now securely clone the repository to which you have been granted access. For a step-by-step guide on how to clone a repository, refer to the [GitHub Cloning a Repository Guide](https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository).

## Branching strategy
To maintain consistency and streamline the development process, the GitHub repository follows the same branching strategy. Adhering to these guidelines ensures that all contributions are integrated smoothly and efficiently. SDVCF's strategy includes specifics on branch naming, commit practices, and merging policies.

**Learn More**: For an in-depth understanding of our branching strategy, refer to the [Branching Strategy Guide](GitBranching.mb).

## User Roles
Each role within the repository comes with a specific set of permissions. These roles are designed to manage the collaboration and workflow effectively. Below you'll find the roles and their associated permissions.

### Viewers
Viewers are organization members who wish to view or discuss the contents of the repository.

- **Permissions**: For a comprehensive list of viewer permissions, refer to the [Triage Permissions](https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories/managing-repository-roles/repository-roles-for-an-organization) section in the GitHub documentation.

### Contributors
Contributors are organization members who contribute code by pushing to the repository.

- **Permissions**: For a comprehensive list of contributor permissions, refer to the [Write Permissions](https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories/managing-repository-roles/repository-roles-for-an-organization) section in the GitHub documentation.

### Maintainers
Maintainers are organization members who manage the repository.

- **Permissions**: For a comprehensive list of maintainer permissions, refer to the [Maintain Permissions](https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories/managing-repository-roles/repository-roles-for-an-organization) section in the GitHub documentation.

## Manage GitHub Actions

Repositories can be pre-configured with GitHub Actions pipeline template files or can be created directly by users, these files are stored inside `./github/workflows/` directory. \
Users can manage and configure pipelines depending on their needs.
### Triggers
Workflows can be configured to be triggered on various events such as pushes to the repository, pull requests, issue comments, and more. This helps in automating tasks like testing, building, and deploying your code. \
For a complete list of events that can be used to trigger workflows, see [Events that trigger workflows](https://docs.github.com/en/actions/using-workflows/events-that-trigger-workflows).

### Jobs
A job represents a unit of work in a workflow. Jobs run sequentially on the same runner by default, and each job can consist of one or more [steps](#steps). Steps can include shell commands or [actions](#actions). \
Since all steps in a job run on the same runner, they can share data easily. You can set environment variables or use files to pass information between steps within the same job. \
By default, jobs run in parallel with each other. However, you can configure dependencies between jobs. When one job depends on another, the dependent job will wait for the completion of the job it depends on before starting. This allows you to create a workflow with a sequence of steps or jobs. \
If you have multiple jobs that don't have dependencies on each other, GitHub Actions can run them in parallel, which can significantly speed up your workflows. \
For more information about jobs, see [Using jobs](https://docs.github.com/en/actions/using-jobs).

### Actions
An action is a reusable and shareable piece of code that performs a specific task. Actions are designed to help automate common workflows by encapsulating complex processes into a single unit. They are particularly useful for reducing code duplication in workflow files and promoting code reusability. \
You can create custom actions designed to your specific needs. These actions can be written in various languages, and they can perform tasks like compiling code, running tests, deploying applications, and more. Custom actions are defined in separate repositories and can be referenced in your workflow files. \
[The GitHub Marketplace](https://github.com/marketplace?type=actions) is a centralized location where you can discover, share, and use actions created by the community. Actions available in the Marketplace cover a wide range of tasks, from code analysis to deployment to various cloud platforms. \
Actions are typically used within the steps section of a job in a workflow file. You can reference actions by their repository, and GitHub will automatically fetch and execute the specified action during the workflow run. \
For more information, see [Creating actions](https://docs.github.com/en/actions/creating-actions).

### Steps
In GitHub Actions, steps are individual units of work within a [job](#jobs). A job consists of one or more steps, and these steps are executed sequentially on the same runner. Each step represents a specific task or action that needs to be performed as part of the overall job. \
Steps within a job are executed in the order they are defined. This ensures that tasks are performed sequentially, and you can control the flow of your workflow. \
Steps can run commands, run setup tasks, or run an action in your repository, a public repository, or an action published in a Docker registry. Not all steps run actions, but all actions run as a step. Each step runs in its own process in the runner environment and has access to the workspace and filesystem. Because steps run in their own process, changes to environment variables are not preserved between steps. GitHub provides built-in steps to set up and complete a job. \
For more information, see [Workflow jobs steps](https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#jobsjob_idsteps).

### Workflow example
```yaml
# Optional - The name of the workflow as it will appear in the "Actions" tab of the GitHub repository. If this field is omitted, the name of the workflow file will be used instead.
name: Build

# Specifies the trigger for this workflow. This example uses the workflow_call event, this event used to define the inputs and outputs for a reusable workflow
# More information can be found here https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#on
on:
  workflow_call:

# Groups together all the jobs that run in the `Build` workflow.
jobs:

# Defines a job named `build`. The child keys will define properties of the job.
  build:
    name: Build

# Configures the job to run on the latest version of an Ubuntu Linux runner. This means that the job will execute on a fresh virtual machine hosted by GitHub.
    runs-on: ubuntu-latest

# Groups together all the steps that run in the `build` job. Each item nested under this section is a separate action or shell script.
    steps:

# The `uses` keyword specifies that this step will run `v3` of the `actions/checkout` action. This is an action that checks out your repository onto the runner, allowing you to run scripts or other actions against your code (such as build and test tools). You should use the checkout action any time your workflow will use the repository's code.
      - name: Checkout
        uses: actions/checkout@v3

# This step uses `run` keyword, that tells the job to execute command on the runner. In this case, we are using `echo` command to print text to the output.
      - name: Build
        id: build
        run: |

          echo "sdvcf-cli"
```

For more information, see [About workflows](https://docs.github.com/en/actions/using-workflows/about-workflows).

## Self-Hosted Agents*
*If configured, check with your repo manager. \
A self-hosted runner is a machine (physical, virtual, or in the cloud) that you set up and manage to run jobs in your GitHub Actions workflows. Unlike GitHub's hosted runners, which are provided and maintained by GitHub, self-hosted runners run on your infrastructure, giving you more control over the environment in which your workflows execute. \
`SDV Cloud Framework` provides the ability to configure GitHub repositories with self-hosted runners depending on the user's needs. \
More information about available configuration options can be found in [Variables YAML Usage repositories section](../VariablesYAMLUsage.md#repositories). \
Self-hosted agents can be chosen in workflows using labels in [runs-on option](https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#jobsjob_idruns-on) inside [jobs](#jobs) configuration. \
All self-hosted runners have the `self-hosted` label. Using only this label will select any self-hosted runner. To select runners that meet certain criteria, such as operating system or architecture, GitHub recommends providing an array of labels that begins with self-hosted (this must be listed first) and then includes additional labels as needed. When you specify an array of labels, jobs will be queued on runners that have all the labels that you specify. \
Although the self-hosted label is not required, GitHub strongly recommends specifying it when using self-hosted runners to ensure that your job does not unintentionally specify any current or future GitHub-hosted runners. \
Labels, that you can use can be found in Repository Settings -> Actions -> Runners. \
There are several self-hosted agents that can be set up using `SDV Cloud Framework`. \
Below is the listing:
### EKS Cluster
EKS cluster allows dynamically adjust computing resources by scaling down to zero nodes when idle and scaling up as needed.
`SDV Cloud Framework` provides EKS cluster setup to use as a GitHub runner. One of the key features is that the cluster is being set up inside the project network and has access to its resources, such as license servers or [local targets](#local-target). \
Here is example of the workflow part using EKS cluster as a runner:
```yaml
# Groups together all the jobs that run in the workflow.
jobs:

# Defines a job named `build`. The child keys will define properties of the job.
  build:
    name: Build

# Configures the job to run on the self-hosted runner. This means that job will run on self-hosted runner that has all of related labels 
    runs-on:
      - self-hosted # This label means that runner is self-hosted
      - k8s-api # This label means that runner is working on Kubernetes cluster
      - linux-arm64-s # This label means that runner has Linux OS, ARM64 type of architecture and size of node instance is Small
```

## Local target
Local target allows execute workflows and tasks directly on your hardware environment. 

Since self-hosted runners are being set up inside the project network, runners can access hardware within your project network and run workflows jobs directly on this hardware.

Here is an example of the workflow step:
```yaml
    steps:

# In this example we use 'matheusvanzan/sshpass-action@v2' action to create SSH connection with our hardware and run commands on it.
      - name: Run sshpass commands
        uses: matheusvanzan/sshpass-action@v2
        with:
        # Pass required configurations as 
          host: 172.22.187.21 # IP address of the local target 
          user: pi # Username
          pass: ${{ secrets.TARGET_PASSWORD }} # Password, more about secrets: https://docs.github.com/en/actions/security-guides/using-secrets-in-github-actions
          run: | # Commands that will be run on the target device
            uname -a
            lscpu
```
