# SDVCF-managed GitHub Actions repository

This repository contains common GitHub Actions workflows for SDVCF-managed code infrastructure

GitHub Actions makes it easy to automate all your software workflows. Build, test, and deploy your code right from GitHub.  
This repository provides reusable workflows and actions to streamline your development process.

## Actions

Add the description of added common actions here, e.g:

### Hello World Action  

A simple GitHub Action that prints "Hello World" and the message to the console.

Usage:

```yaml
- name: Run Hello World Action
  uses: <organization>/<common-action-repo>/actions/hello-world-action@main
  with:
    message: "Hello from other repo!"
```

### Tree Command Action
A GitHub Action that checks out the repository and prints the output of the tree command to the console.

Usage:

```yaml
- name: Run Tree Command Action
  uses: <organization>/<common-action-repo>/actions/tree-action@main
```

### Reusable configurable build action

This github action takes JSON config file which contains list of tools to install, repositories to clone, commands to execute, and artifacts paths to yield, and performs necessary build actions.

### Inputs

### build_config_path

**required** Relative path to JSON config file in repo.

Schema of config file:

```json
{
    "tools": [
        {"name": "tool1", "version": "1.0.0"},
        {"name": "tool2", "version": "*"}
    ],
    "repositories": [
        {
            "url": "https://github.com/Organization/repo1.git",
            "path": "repo1",
            "branch": "main"
        },
        {
            "url": "https://github.com/Organization/repo2.git",
            "path": "repo2/subrepo2",
            "branch": "develop"
        }
    ],
    "commands": ["command1", "command2"],
    "upload_paths": [
        "output/bin/",
        "output/test-results",
        "!output/**/*.tmp"
    ]
}
```

Here is detailed vies on each field:

#### tools

List of dictionaries with specified tools to install. Action can install any tool available in APT package manager:  

`name`: Name of the package.  
`version`: Version of the package. `"*"` can be specified to install latest version.

#### repositories

List of dictionaries with configuration for repositories to clone:

`url`: URL of the repository. **NOTE** That only HTTPS can be used.  
`path`: name of folder or path where to clone the repository.  
`branch`: Branch of the repository to clone.

#### commands

List of strings with `Bash` shell commands to execute.

#### upload_paths

List of paths to upload as artifact of the GitHub workflow. You can specify path using `Wildcard Pattern`.

**NOTE** That every field in config is **required**

### GITHUB_TOKEN

**required** The GitHub token used for authentication to access the organization and repositories.


### Example workflow
Example of step:
```yaml
    steps:
      - name: Customizable Build
        uses: <organization>/<common-actions-repo>/actions/reusable-build-action@main
        with:
          build_config_path: build_config.json
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

Note that `@main` is the name of the branch!

### Artifact retention

#### Description

> [!NOTE]
> To use this feature you have to configure `retention` in `registries` section of [VariablesYAML](../VariablesYAMLUsage.md#registries).

The artifact retention feature uses the following mechanism:
SDV CF configures a Lifecycle Policy Rule for AWS S3 Bucket. This rule filters objects in the bucket by tags and applies a retention policy to the matching objects.

To use the SDV CF Artifact Retention feature, ensure your AWS CLI credentials are properly configured.

#### Get a list of objects for configuration

Use the following command to generate a list of objects to be marked with tags. This command works for both applying and discarding retention rules:

```bash
aws s3api list-objects-v2 --bucket <BUCKET> --prefix <PREFIX> --query 'Contents[].Key' --output text
```

Where:

* `BUCKET`: The name of the bucket your artifacts are stored.

* `PREFIX`: The directory path in the bucket to get objects from.


#### Apply a retention rule to an object

To apply a retention rule, use the following command for each item retrieved in [this](#get-a-list-of-objects-for-configuration) section:

```bash
aws s3api put-object-tagging --bucket <BUCKET> --tagging 'TagSet=<TAGS>' --key <OBJECT_FULL_PATH>
```

Where:

* `BUCKET`: The name of the bucket your artifacts are stored.

* `TAGS`: The set of tags (separated by comma) to be applied to the objects, e.g: `[{Key=<KEY>,Value=<VALUE>}]` or `[{Key=<KEY>,Value=<VALUE>}, {Key=<KEY2>,Value=<VALUE2>}]`.

* `OBJECT_FULL_PATH`: The full path to the object in the bucket, e.g: `some/file`.

#### Discard a retention rule for object

To discard a retention rule, use the following command for each item retrieved in [this](#get-a-list-of-objects-for-configuration) section:

```bash
aws s3api delete-object-tagging --bucket <BUCKET> --key <OBJECT_FULL_PATH>
```

* `BUCKET`: The name of the bucket your artifacts are stored.

* `OBJECT_FULL_PATH`: The full path to the object in the bucket, e.g: `some/file`.

#### Example

##### Apply retention rule Github Action

The following GitHub Action applies retention rules to objects in an S3 bucket:

```yaml
name: Apply retention rule

on:
  workflow_dispatch:
    inputs:
      bucket-name:
        description: "The name of the S3 bucket"
        required: true
      prefix:
        description: "The prefix (directory path) in the S3 bucket"
        required: true
      tags:
        description: "Tags to apply in JSON format"
        required: true

jobs:
  apply-retention:
    runs-on: ubuntu-latest
    steps:
      - name: Configure AWS CLI
        uses: aws-actions/configure-aws-credentials@v2
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}

      - name: Add AWS CLI
        run: |
          apt update && apt install pip pbzip2 -y
          pip install awscli

      - name: Add Tag for Objects in S3
        env:
          BUCKET_NAME: ${{ inputs.bucket-name }}
          PREFIX: ${{ inputs.prefix }}
          TAGS: ${{ inputs.tags }}
        run: |
          aws s3api list-objects-v2 --bucket $BUCKET --prefix $PREFIX --query 'Contents[].Key' --output text |
            xargs -I {} aws s3api put-object-tagging --bucket $BUCKET --tagging 'TagSet=$TAGS' --key {}
```

##### Discard retention rule Github Action

The following GitHub Action discards retention rules from objects in an S3 bucket. Unlike the Apply action, this does not require tags as input:

```yaml
name: Discard retention rule

on:
  workflow_dispatch:
    inputs:
      bucket-name:
        description: "The name of the S3 bucket"
        required: true
      prefix:
        description: "The prefix (directory path) in the S3 bucket"
        required: true

jobs:
  discard-retention:
    runs-on: ubuntu-latest
    steps:
      - name: Configure AWS CLI
        uses: aws-actions/configure-aws-credentials@v2
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}

      - name: Add AWS CLI
        run: |
          apt update && apt install pip pbzip2 -y
          pip install awscli

      - name: Remove Tags from Objects in S3
        env:
          BUCKET_NAME: ${{ inputs.bucket-name }}
          PREFIX: ${{ inputs.prefix }}
        run: |
          aws s3api list-objects-v2 --bucket $BUCKET --prefix $PREFIX --query 'Contents[].Key' --output text |
            xargs -I {} aws s3api delete-object-tagging --bucket $BUCKET --key {}
```

## How to Create a New Action

To create a new GitHub Action in this repository, follow these steps.

### Create the directory structure:
   
Inside this repository, create a directory for your new action under `actions/` For example:

`actions/your-new-action`  

### Create the action metadata file:

In your new action's directory, create a file named `action.yaml`. This file defines your action. Here is an example template:

```yaml
name: Your New Action
description: A description of your new action
inputs:
  example_input:
    description: An example input
    required: true
runs:
  using: "composite"
  steps:
    - name: Print Example Input
      shell: bash
      run: echo  "Input: ${{ inputs.example_input }}"
```

### Test your action:

Create a workflow to test your action. Create a `.github/workflows/test-actions.yaml` file and add test action, e.g:

```yaml
name: Test Actions

on: [push]

jobs:
  test:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v2

      - name: Run Hello World Action
        uses: ./actions/hello-world-action
        with:
          message: "Hello form test pipeline"

      - name: Run Tree Command Action
        uses: ./actions/tree-action
    
      # Test of the new action
      - name: Run Your Action
        uses: ./actions/your-new-action
        with:
          example_input: "Example input"

```

### Document your action:

Update the README.md file to include documentation for your new action, similar to the documentation provided above for the Hello World and Tree Command actions.

By following these steps, you can create new reusable GitHub Actions to streamline your development process.
