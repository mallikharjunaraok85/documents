# How to add the Custom APT repository

`SDV Cloud Framework` provides the feature of setting up apt repositories hosted on an AWS S3 bucket.
Repositories are pre-configured with pipeline templates to build and push to apt repository deb packages with [aptly](https://www.aptly.info) tool.

It leverages the power and scalability of AWS S3 to store and serve Debian packages, making it easy to manage and distribute software packages.

## Key highlights of self-hosted APT repositories

### Easy Setup
`SDV Cloud Framework` streamlines the setup of Apt repositories on AWS S3 for reliable and scalable storage. Leverages S3's features for high availability, durability, and accessibility. Users can quickly configure APT repositories for hosting Debian packages.

### Pipeline Templates
`SDV Cloud Framework` provides pre-configured pipeline templates for GitHub Actions. These templates automate the build and push processes of Debian packages to the Apt repository hosted on AWS S3.

### Aptly Integration
APT repositories are set up in integration with the aptly tool, a robust and flexible solution for managing Debian repositories. `aptly` used for tasks like package management, repository creation, and publishing.

### Versioning and Tagging
Supports versioning and tagging of packages for easy tracking and rollback. Users can manage different versions of software and mark releases for stable, beta, or other channels.

### Access Control
Implements access control mechanisms to manage who can publish or consume packages from the repository. Leverages AWS S3 bucket policies and IAM roles for fine-grained control.


## Github Actions Workflow example

```yaml
# Optional - The name of the workflow as it will appear in the "Actions" tab of the GitHub repository. If this field is omitted, the name of the workflow file will be used instead.
name: Build

# Specifies the trigger for this workflow. This example uses the workflow_call event, this event used to define the inputs and outputs for a reusable workflow
# More information can be found here https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#on
on:
  workflow_call:

# Groups together all the jobs that run in the `Build` workflow.
jobs:

# Defines a job named `build`. The child keys will define properties of the job.
  build:
    name: Build

# Configures the job to run on the latest version of an Ubuntu Linux runner. This means that the job will execute on a fresh virtual machine hosted by GitHub.
    runs-on: ubuntu-latest

# Groups together all the steps that run in the `build` job. Each item nested under this section is a separate action or shell script.
    steps:

# The `uses` keyword specifies that this step will run `v3` of the `actions/checkout` action. This is an action that checks out your repository onto the runner, allowing you to run scripts or other actions against your code (such as build and test tools). You should use the checkout action any time your workflow will use the repository's code.
      - name: Checkout
        uses: actions/checkout@v3

# Configure your AWS credentials and region environment variables for use in other GitHub Actions.
#This action implements the AWS JavaScript SDK credential resolution chain and exports session environment variables for your other Actions to use. Environment variable exports are detected by both the AWS SDKs and the AWS CLI for AWS API calls.
      - name: Configure AWS Credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }} # AWS access key to use. Defined as AWS_ACCESS_KEY_ID Github Actions secret.
          aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }} # AWS secret key to use. Defined as AWS_SECRET_ACCESS_KEY Github Actions secret.
          aws-region: ${{ vars.AWS_REGION }} # Which AWS region to use. Defined as AWS_REGION Github Actions variable.

# FIX

# In this step Debian package directory structure is creating, downloading source files form AWS S3 bucket, unpacking and moving source files to the src directory in the Debian package directory.
      - name: Download files
        run: |
# Downloading source files form AWS S3 bucket
          aws s3 cp s3://${{ vars.APT_REPO_S3 }}/tools-src/github-honda-elite-hitachiastemo-astemo-variant.tar.gz .
# Creating Debian package directory structure
          mkdir -p ${{ vars.PACKAGE_NAME }}_${{ inputs.Version }}-${GITHUB_RUN_NUMBER}_${{ inputs.Architecture}}/opt/${{ vars.PACKAGE_DST }}
# Unpacking source files
          tar -xf github-honda-elite-hitachiastemo-astemo-variant.tar.gz -C ${{ vars.PACKAGE_NAME }}_${{ inputs.Version }}-${GITHUB_RUN_NUMBER}_${{ inputs.Architecture}}/opt/${{ vars.PACKAGE_DST }}
          cd ${{ vars.PACKAGE_NAME }}_${{ inputs.Version }}-${GITHUB_RUN_NUMBER}_${{ inputs.Architecture}}/opt/${{ vars.PACKAGE_DST }}
# Delete .git directory from source files
          find . -name ".git" -o -name ".git*" | xargs -I{} rm -rf {}
# Setup environment variable SIZE, which shows Debian package size.
          echo "SIZE=$(( $(du -sb . | awk '{print $1}') / 1024 ))" >> $GITHUB_ENV

# In this step Debain package control file is creating.
      - name: Create control file
        shell: bash
        run: |
          mkdir -p ${{ vars.PACKAGE_NAME }}_${{ inputs.Version }}-${GITHUB_RUN_NUMBER}_${{ inputs.Architecture}}/DEBIAN
          echo "Package: ${{ vars.PACKAGE_NAME }}
          Provides: ${{ vars.PACKAGE_NAME }} (= ${{ inputs.Version }})
          Version: ${{ inputs.Version }}
          Maintainer: ${{ github.actor }} <ha@dropmail.cc>
          Depends: ${{ inputs.Depends }}
          Section: utils
          Priority: optional
          Architecture: ${{ inputs.Architecture}}
          Homepage: https://www.hitachiastemo.com
          Installed-Size: ${{ env.SIZE }}
          Description: Customized Qualcomm QNX variant" > ${{ vars.PACKAGE_NAME }}_${{ inputs.Version }}-${GITHUB_RUN_NUMBER}_${{ inputs.Architecture}}/DEBIAN/control

# Building Debain package.
      - name: Build package
        run: |
          dpkg --build ${{ vars.PACKAGE_NAME }}_${{ inputs.Version }}-${GITHUB_RUN_NUMBER}_${{ inputs.Architecture}}

# Installing aptly tool to manage APT repositories (https://www.aptly.info).
      - name: Install aptly
        run: |
          curl -sL https://www.aptly.info/pubkey.txt | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/aptly.gpg >/dev/null \
          && echo "deb http://repo.aptly.info/ squeeze main" | sudo tee -a /etc/apt/sources.list
          sudo apt-get -q update \
          && sudo apt-get -y install aptly=1.5.0

# Send query to the AWS S3 bucket, if .lock file exists.
      - name: Check if repo used
        id: lockRepo
        run: |
          while [ $(aws s3api list-objects-v2 --bucket ${{ vars.APT_REPO_S3 }} --query "contains(Contents[].Key, 'db/aptly-db.lock')") == true ]; do echo "File .lock exists" && sleep 15 ; done

# In this step we add Debian package to the aptly repository and publish repository to the AWS S3 bucket
      - name: Add package to aptly repo
        if: steps.lockRepo.outcome == 'success'
        id: pushPackage
        run: |
# Creating .lock file and push it to the AWS S3 bucket, to be sure, APT repository structure will not change during package pushing.
          touch aptly-db.lock
          aws s3 cp aptly-db.lock s3://${{ vars.APT_REPO_S3 }}/db/aptly-db.lock
# Check if archive with aptly database exists
          if aws s3 ls ${{ vars.APT_REPO_S3 }}/db/aptly-db.tar
          then
# Copy archive with aptly database form AWS S3 bucket
            aws s3 cp s3://${{ vars.APT_REPO_S3 }}/db/aptly-db.tar /home/runner/
# Unpack to /home/runner directory
            tar -xzvf /home/runner/aptly-db.tar --directory /home/runner/
# Configure aptly
            APTLY_DIR='/home/runner/.aptly'
            jq --arg aptly_dir "$APTLY_DIR" '.rootDir = $aptly_dir' "/home/runner/.aptly.conf" > tmp.conf && mv tmp.conf "/home/runner/.aptly.conf"
# Add Debian package to the aptly repository
            aptly repo add apt-repo ${{ vars.PACKAGE_NAME }}_${{ inputs.Version }}-${GITHUB_RUN_NUMBER}_${{ inputs.Architecture}}.deb
# Publish package update to the repository
            aptly publish update --batch=true --gpg-key=${{ secrets.GPG_KEY_ID }} --passphrase=${{ secrets.GPG_KEY_PASS }} stable s3:${{ vars.APT_REPO_S3 }}:s
# Remove archive with aptly database
            rm /home/runner/aptly-db.tar
          else
# Create aptly repository
            aptly repo create apt-repo
# Add Debian package to the repository
            aptly repo add apt-repo ${{ vars.PACKAGE_NAME }}_${{ inputs.Version }}-${GITHUB_RUN_NUMBER}_${{ inputs.Architecture}}.deb
# Configure aptly
            S3_ENDPOINT='{${{ vars.APT_REPO_S3 }}"{"region": ${{ vars.AWS_REGION }},"bucket": ${{ vars.APT_REPO_S3 }},"acl": "public-read"}}'
            jq --argjson s3_endpoint "$S3_ENDPOINT" '.S3PublishEndpoints = $s3_endpoint' "/home/runner/.aptly.conf" > tmp.conf && mv tmp.conf "/home/runner/.aptly.conf"
# Create GPG key
            gpg --batch --passphrase '' --quick-gen-key USER_ID default default
# Publish package to the repository
            aptly publish repo --architectures=amd64,i386 --batch=true --gpg-key=${{ secrets.GPG_KEY_ID }} --passphrase=${{ secrets.GPG_KEY_PASS }} --component=main --distribution=stable apt-repo s3:${{ vars.APT_REPO_S3 }}:
          fi 

# Archive aptly database files and push to AWS S3 bucket.
      - name: Push package db to repo
        run: |
          tar -czvf /home/runner/aptly-db.tar --directory /home/runner/ .aptly/db .aptly.conf .gnupg
          aws s3 cp /home/runner/aptly-db.tar s3://${{ vars.APT_REPO_S3 }}/db/aptly-db.tar

# Remove .lock file from AWS S3 bucket.
      - name: Remove .lock
        if: success() || failure()
        run: |
          aws s3 rm s3://${{ vars.APT_REPO_S3 }}/db/aptly-db.lock
```

In this example, we are downloading the source code from the AWS S3 bucket stored as a tar.gz archive, but packages can be built from code stored in the current GIT repository.

As the build number for the Debian package we use the default variable for GitHub Actions workflow run [GITHUB_RUN_NUMBER](https://docs.github.com/en/actions/learn-github-actions/variables) environment variable.

For signing the APT repository, we generate a GPG key inside the pipeline, but you can use your own approach of GPG key management, i.e. store the GPG private key as GitHub Actions secret and import the key in the pipeline.

### Trigger build pipeline
To trigger the build stage, we create a main.yml pipeline template file.
```yaml
# Optional - The name of the workflow as it will appear in the "Actions" tab of the GitHub repository. If this field is omitted, the name of the workflow file will be used instead.
name: Main manual pipeline

# Specifies the trigger for this workflow. This example uses the workflow_dispatch event, you can optionally specify inputs that are passed to the workflow.
# More information can be found here https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#on
on:
  workflow_dispatch:
    inputs:
# This input defines Debian package version
      Version:
        description: 'Package version'
        required: true
        default: 1.0.0
        type: number
# This input defines architecture type of the Debian package
      Architecture:
        description: 'Architecture'
        required: true
        default: 'all'
        type: choice
        options:
        - all
        - arm64
        - amd64
# This input defines Debian package dependencies
      Depends:
        description: 'Dependencies'
        required: true
        default: 'libc6'
        type: string


# Groups together all the jobs that run in the workflow.
jobs:
# Defines a job named `build`. The child keys will define properties of the job.
  build:
    name: Build
# The uses option specifies the location and version of a reusable workflow file to run as a job.
    uses: ./.github/workflows/build.yaml
# Use the inherit keyword to pass all the calling workflow's secrets to the called workflow.
    secrets: inherit
```

Dependencies are passed to workflow as input separated with a comma, user can define a default value for the input variable in the main.yml file and change it when triggering the pipeline or use the default.

When the main.yml file is created, in GitHub Actions should appear **Run workflow** button. The user can press this button, fill options with his own values or use default and run workflow.

![Manual trigger](../images/sdvcf-cli_manual_trigger_pipeline.png)

### Install published package
APT repository is now hosted on S3. Users can use the S3 URL to access the repository. For example:

```bash
echo "deb [arch=<architecture> trusted=yes] https://<s3-bucket-name>.s3-website-<aws-region>.amazonaws.com/ <distibution> <component>" | sudo tee /etc/apt/sources.list.d/<repo-name>.list
sudo apt-get update
sudo apt-get install <package-name>
```

The value yes in the `trusted` option tells APT always to consider this source as trusted, even if it doesn't pass authentication checks.

For additional information, use [GitHub Actions Secrets](https://docs.github.com/en/actions/security-guides/using-secrets-in-github-actions) article.

For more information about variables, [GitHub Actions Variables](https://docs.github.com/en/actions/learn-github-actions/variables).


## Manual APT repository creation
Before starting, create an AWS S3 bucket.
1. **Install `aptly`**.
```bash
curl -sL https://www.aptly.info/pubkey.txt | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/aptly.gpg >/dev/null
echo "deb http://repo.aptly.info/ squeeze main" | sudo tee -a /etc/apt/sources.list

apt-get -q update
apt-get -y install aptly=1.5.0
```
2. **Create APT repository**
```bash
aptly repo add apt-repo
```
3. **Add AWS S3 bucket to `.aptly.conf` file**

Update .aptly.conf file with the created AWS S3 bucket endpoint.
```json
{
...
  "S3PublishEndpoints": {"<YOUR_AWS_S3_BUCKET_NAME>":{
         "region":"<YOUR_AWS_REGION>",
         "bucket":"<YOUR_AWS_S3_BUCKET_NAME>",
         "acl":"public-read"
      }},
...
}
```
4. **Add Debian package to `aptly` repository**

```bash
aptly repo add apt-repo <YOUR_PACKAGE_NAME>.deb
```
5. **Publish APT repository to AWS S3**
```bash
aptly publish repo --batch=true --gpg-key=<YOUR_GPG_KEY_ID> --passphrase=<YOUR_GPG_KEY_PASS> --component=main --distribution=stable s3:<YOUR_AWS_S3_BUCKET_NAME>:
```

APT repository is now hosted on S3 and you can install the published package, see [Install published package](#install-published-package).

## Important

Inside the tar.gz archive, the folder structure must use a relative path and contain only useful files and directories.

```bash
tar -czvf <archive_name>.tar.gz --directory <work_dir> ./file1 ./file2 ./dir1 ./dir2/file3
```
