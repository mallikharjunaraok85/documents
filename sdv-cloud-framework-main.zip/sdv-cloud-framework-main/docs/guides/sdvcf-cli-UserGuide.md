# SDVCF-CLI User Guide

This guide provides comprehensive information about installation, configuration, troubleshooting ```sdvcf-cli``` tool.

## SDVCF-CLI installation
<!--
TODO:
  Update this section for next OS:
    * Windows
    * Linux
    * Mac

  additional docs:
    * Docker image usage
-->
1. Open Terminal and navigate to the root directory of the repository.
2. Run the pip3 command to install the sdvcf-cli:
```sh
$> pip3 install --editable .
```
3. Verify the installation:
```sh
$> sdvcf-cli --version
0.0.3
```
4. Run ```sdvcf-cli --help``` command to show the available subcommands:
```sh
$> sdvcf-cli --help
usage: sdvcf-cli [-h] [--version] [--work-dir WORK_DIR] [--dry-run] [--skip-synth] [--verbose] [-y]
                 {init,common,project} ...
```

## Usage prerequisites

**sdvcf-cli** utilize multiple providers infrastructure configuration.
Before using this tool, you need to configure the providers.

## AWS cloud

AWS cloud provider has two options of authentification configuration.

* **Option 1**
AWS cloud authentification can be configured with AWS CLI.
The configuration instruction can be found below.
  * [AWS CLI configuration](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-configure.html)  

* **Option 2**
Setting environment variables is an alternative to configuring the AWS CLI directly.
However, keep in mind that storing sensitive information like access keys directly in
environment variables may pose security risks, especially in shared environments:
  1. AWS_ACCESS_KEY_ID
  2. AWS_SECRET_ACCESS_KEY

## Azure cloud

Azure cloud authentification can be configured using Azure CLI.
The configuration instruction can be found below.
  * [Azure CLI configuration](https://learn.microsoft.com/en-us/cli/azure/authenticate-azure-cli-interactively)

## GitHub

There are two options how to configure authentification for GitHub provider.
[GitHub Guide](GitHubGuide)

* **Option 1**
To authenticate using OAuth tokens, ensure that the GITHUB_TOKEN environment variable is set.

* **Option 2**
The GitHub provider taps into [GitHub CLI](https://cli.github.com/) authentication, where it picks up the token issued by [```gh auth login```](https://cli.github.com/manual/gh_auth_login) command.
It is possible to specify the path to the ```gh``` executable in the ```GH_PATH``` environment variable, which is useful for
when the GitHub provider can not properly determine its the path to GitHub CLI such as in the cygwin terminal.

## Business Unit Management

The **sdvcf-cli** tool seamlessly manages three essential business unit types:

### init
* Sets the stage by initializing crucial infrastructure to configure the business unit's cloud environment. (Note: Currently in development and not yet implemented.)
```sh
$> sdvcf-cli init --help
usage: sdvcf-cli init [-h]
```

### common
* Establishes shared resources efficiently, including common network configurations across the entire business unit.
```sh
$> sdvcf-cli common --help
usage: sdvcf-cli common [-h] [--config path/to/config.yaml] [--destroy]
```

### project
* Manages and maintains project-specific infrastructure, ensuring the streamlined deployment and ongoing maintenance of resources tailored to individual project needs.
```sh
$> sdvcf-cli project --help
usage: sdvcf-cli project [-h] [--config path/to/config.yaml] [--destroy]
```

With these capabilities, **sdvcf-cli** offers a flexible and efficient solution for coordinating various components within business units in a cloud environment.


## Use cases

### Interactive Infrastructure Deployment

Whether you're setting up a new environment or making adjustments to existing infrastructure, **sdvcf-cli** offers an interactive approach to streamline the deployment process. Walk through the steps with ease, configuring and initializing your cloud resources as needed.

### CI/CD Integration

Integrating with Continuous Integration and Continuous Deployment (CI/CD) pipelines is seamless with **sdvcf-cli**. Automate the deployment and management of your cloud infrastructure as part of your development workflows, ensuring efficiency and consistency.

### Infrastructure Configuration Validation

Before deployment, use the ```sdvcf-cli --dry-run init|common|project --config variables.yaml``` to perform a dry run, checking for any errors or misconfigurations. Ensure the accuracy of your infrastructure specifications before committing to deployment.
This pre-deployment validation, driven by Infrastructure as Code practices, guarantees the accuracy of specifications and minimizes the risk of unforeseen issues during deployment.

## Troubleshooting

### Logging 

Run **sdvcf-cli** in verbose mode using the ```--verbose``` option to display debug information on the standard output.
By default, this debug information is recorded in a file named **cdktf-logs-TIMESTAMP.txt** within the **WORKING_DIR/sdvcf.out/stacks/STACK_NAME** directory.

### Get Support

<!-- FIXME:
Missing ITEM
-->