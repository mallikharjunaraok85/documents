AWS Programmatic User Creation Guide for CI
===========================================

This guide provides detailed steps for creating an AWS user with programmatic access, generating access credentials, and attaching a policy to control permissions.

Prerequisites
-------------

- AWS Management Console access with permissions to manage IAM users and policies.
- The policy file that defines minimal user's permissions (docs/files/minimal_aws_iam_access.json).

Steps
-----

### 1\. Create a New IAM User

1. **Log into AWS Management Console**\
    Go to the [AWS Management Console](https://aws.amazon.com/console/).

2. **Navigate to IAM (Identity and Access Management)**\
    In the AWS Management Console, search for **IAM** in the search bar and select **IAM** from the results.
![AWS Management Console - IAM](images/aws_user_console_iam.png "IAM")

3. **Add a new user**

    - In the IAM dashboard, select **Users** from the left sidebar.
    - Click on the **Create user** button.

4. **Specify User Details**

    - **User Name:** Choose a meaningful username (e.g., `sdv-ci-user`).
    - You can left uncheked **Provide user access to the AWS Management Console** checkbox.

    ![AWS Management Console - User Creation](images/aws_user_console_user1.png "User")
5. **Set Permissions**

    - Press **Next** button, as we'll attach the policy later.
6. **Tagging (Optional)**

    - You can add key-value pairs to tag the user for tracking purposes, like:
        - `Key: Department`, `Value: DevOps`
        - `Key: Role`, `Value: CI`
7. **Review and Create User**

    - Review the details and click **Create user**.

### 2\. Generate Programmatic Access Credentials

1. **Open user Security credentials setting**
    - On Users screen, click on your new user.
    - Select **Security credentials** tab

    ![AWS Management Console - Security credentials](images/aws_user_console_user2.png "User2")

2. **Access Keys section**
    - Find Access Keys section
    - And click **Create access key**

    ![AWS Management Console - Access Key](images/aws_user_console_user3.png "User3")

3. **Access Keys creation**
    - On **Step 1** select **Other** and click **Next*
    - You can just press **Create access key** on **Step 2**
    - Now you can copy credentials from **Access key** section or download them as .csv file

    ![AWS Management Console - Access credentials](images/aws_user_console_user4.png "User4")

4. **Store credentials**
    - Store these credentials securely using a secret management tool provided by your IT or use service like AWS Secrets Manager

### 3\. Create a Policy from the Provided File

1. **Navigate to the Policies section**

    - From the IAM dashboard, click on **Policies** in the left sidebar.
    - Click **Create policy**.

    ![AWS Management Console - Policy](images/aws_user_console_user5.png "User5")
 
2. **Import the JSON Policy**

    - In the **Create Policy** screen, click on the **JSON** button.
    - Copy and paste the content from [docs/files/minimal_aws_iam_access.yaml](../files/minimal_aws_iam_access.yaml) file into the editor.

    ![AWS Management Console - Policy JSON](images/aws_user_console_user6.png "User6")

    - Once the policy is pasted, click **Next: Tags** (optional) and **Next: Review**.
3. **Review and Name the Policy**

    - **Policy Name:** Enter a meaningful name for the policy (e.g., `sdv-ci-policy`).
    - Review the policy details and click **Create policy**.

### 4\. Attach the Policy to the User

1. **Navigate back to IAM Users**

    - From the IAM dashboard, select **Users** from the left sidebar.
    - Click on the user you created earlier (e.g., `sdv-ci-user`).
2. **Attach the Policy**

    - In the user's details, go to the **Permissions** tab.
    - Click **Add permissions** and select **Attach policies directly**.

        ![AWS Management Console - User Permission](images/aws_user_console_user7.png "User7")

    - Search for the policy you created earlier (e.g., `sdv-ci-policy`), check the box, and click **Next: Review**.
    - Click **Add permissions** to attach the policy to the user.

        ![AWS Management Console - User Policy](images/aws_user_console_user8.png "User8")

### 5\. Verify Programmatic Access

1. **Install AWS CLI**\
    If not installed, [download and install AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html).

2. **Configure AWS CLI**

    - Run the following command and enter the **Access Key ID** and **Secret Access Key** from the earlier steps:

        ```console
        user@your-computer$ aws configure
        ```

    - You'll also need to specify your region and output format:
        - **Default region name:** Enter your preferred AWS region (e.g., `us-east-1`).
        - **Default output format:** You can specify `json`, `text`, or `table`. Typically, `json` is preferred for automation.
3. **Test Access**

    - Run a basic command to verify access, such as:

        ```console
        user@your-computer$ aws sts get-caller-identity
        ```

    - This should return information about the user and confirm programmatic access.
