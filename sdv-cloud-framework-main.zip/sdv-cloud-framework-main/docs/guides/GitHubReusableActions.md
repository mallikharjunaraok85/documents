# Reusable configurable build action

This github action takes JSON config file which contains list of tools to install, repositories to clone, commands to execute, and artifacts paths to yield, and performs necessary build actions.

## build_config_path

**required** Relative path to JSON config file in repo.

Schema of config file:

```json
{
    "tools": [
        {"name": "tool1", "version": "1.0.0"},
        {"name": "tool2", "version": "*"}
    ],
    "repositories": [
        {
            "url": "https://github.com/Organization/repo1.git",
            "path": "repo1",
            "branch": "main"
        },
        {
            "url": "https://github.com/Organization/repo2.git",
            "path": "repo2/subrepo2",
            "branch": "develop"
        }
    ],
    "commands": ["command1", "command2"],
    "upload_paths": [
        "output/bin/",
        "output/test-results",
        "!output/**/*.tmp"
    ]
}
```

Here is detailed vies on each field:

## tools

List of dictionaries with specified tools to install. Action can install any tool available in APT package manager:  

`name`: Name of the package.  
`version`: Version of the package. `"*"` can be specified to install latest version.

## repositories

List of dictionaries with configuration for repositories to clone:

`url`: URL of the repository. **NOTE** That only HTTPS can be used.  
`path`: name of folder or path where to clone the repository.  
`branch`: Branch of the repository to clone.

## commands

List of strings with `Bash` shell commands to execute.

## upload_paths

List of paths to upload as artifact of the GitHub workflow. You can specify path using `Wildcard Pattern`.

**NOTE** That every field in config is **required**

### GITHUB_TOKEN

**required** The GitHub token used for authentication to access the organization and repositories.


## Example workflow
Example of step:
```yaml
    steps:
      - name: Customizable Build
        uses: <organization>/<common-actions-repo>/actions/reusable-build-action@main
        with:
          build_config_path: build_config.json
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```
