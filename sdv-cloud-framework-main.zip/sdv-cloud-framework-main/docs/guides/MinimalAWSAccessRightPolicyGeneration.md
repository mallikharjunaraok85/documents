# Minimal AWS Access Rights Policy generation

This guide provides information about creating a minimal AWS IAM policy generation using the `iamlive` utility. This policy will ensure that only the necessary permissions will be used.

## Prerequisites

- [`iamlive`](https://github.com/iann0036/iamlive) utility installed.
- AWS credentials configured via environment variables or in AWS credentials file.

## Steps

### 1. Prepare sdvcf-cli configuration
To create policy that will cover all possible needed access, your project configuration should include all supported AWS resource creation.

### 2. Start `iamlive` to Capture AWS API Calls

  Run the `iamlive` utility to begin capturing the API calls that will be used to generate your minimal IAM policy. The output will be saved to a JSON file:

  ```bash
  iamlive --output-file /path/to/file.json
  ```
  You`ll need to enable AWS Client-Side Monitoring (CSM): 
- If .aws/config credential is expected to be used, provide additional `--set-ini` `iamlive` option. 
- If you are using environment variables configuruation, run `export AWS_CSM_ENABLED=true` before `sdvcf-cli` commands.

### 3. Run project creation and distruction
  While iamlive command is running, open another terminal window and run `sdvcf-cli` command for both project creation and destroy.
  `iamlive` utility will monitor API calls to generate minimal IAM policy.

### 4. Review and commit updated policy file
Once the `sdvcf` operations is completed, review the JSON file created by `iamlive`. This file contains the minimal set of AWS permissions needed for the actions performed during project deploy and destroy phases. Review contents and check difference with `docs/files/minimal_aws_iam_access.yaml` file and make sure that changes are expected.
