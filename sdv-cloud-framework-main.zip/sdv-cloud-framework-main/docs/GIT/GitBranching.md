# Git Branching Strategy

A well-defined branching strategy is essential for managing code changes, isolating features, and releasing software in a structured manner.
This document outlines a recommended Git branching strategy that aims to streamline development workflows and promote collaboration.

## Overview

The `sdvcf-cli` utilize Git branching strategy for GitHub and CodeCommit repositories.
Each repository has a pre-defined approval schema with restricted access to the default branch.
It prevent unauthorized access and modifications to the code, improving project management and reducing potential risks associated with unrestricted access.

**⚠️ NOTE:** For GitHub private repositories, branch protection is enabled only if GitHub Organization plan is Team or Enterprise.

Repositories are preconfigured with two branches:
  1. `main`
     * Represents initial state of repository.
     * Should always reflect the production-ready state.
     * Protected from direct push by policy.
  
  2. `dev`
     * Represents development line.
     * Derived from the `main` branch.
     * Protected from direct push by policy.
     * Merges with `main` only after passing tests and maintainer approval.

## Lifecycle management
Each new feature should reside in its own branch. But, instead of branching off of `main`, `feature` branches use `dev` as their parent branch. When a feature is complete, it gets merged back into `dev` branch after passing code review process. Features should never interact directly with `main`. Then, `dev` branch merges with `main` after passing tests and maintainer approval.

![SDV-Branching-Strategy](images/SDV-Branching-Strategy.png)

By following this branching strategy, the `main` branch stores only completed features. The `dev` branch acts as a staging area for integrating and testing new features, ensuring that the `main` branch only receives well-tested and approved changes. 
