# Environment Variables

## Introduction
This document serves as a comprehensive guide to the environment variables utilized within the project codebase.
SDVCF's environment variables wield influence over both the generated cloud resources and their associated properties
and configurations. Configuring these variables is crucial for the proper creation of the project's resources. This
documentation aims to provide clarity on the purpose, usage, and best practices associated with each environment
variable, ensuring seamless deployment and maintenance.

## `GITHUB_TOKEN`

The `GITHUB_TOKEN` environment variable is used for authenticating and authorizing interactions with the GitHub API.
This token is employed for various GitHub-related operations, such as repository access, pull requests, and other
automation tasks.

**⚠️ NOTE:** The default value for `GITHUB_TOKEN` is **not** specified, if there are Github-related resources to deploy
in `variables.yaml` this value must be set.

**Value Limitations and Constraints:**
- It should be a valid GitHub token obtained from your GitHub account with appropriate permissions to deploy desired
  resources.
- Keep the token confidential and avoid sharing it in public repositories or insecure environments.

**References:**
- https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens

## `WB_AUTO_STOP_MINUTES`

The `WB_AUTO_STOP_MINUTES` environment variable specifies the auto-stop duration in minutes for the Virtual Workbenches
across all providers.

**Default Value:**
The default value for `WB_AUTO_STOP_MINUTES` is `120` minutes.

## `WB_DEFAULT_OS`

The `WB_DEFAULT_OS` environment variable specifies the default operating system for the Virtual Workbenches across all
providers.

**Allowed Values:**
  - `Ubuntu18_04`: Represents Ubuntu 18.04 as the default operating system for the Virtual Workbench.
    Ubuntu 18.04 is a widely used Linux distribution known for its stability and long-term support (LTS).

**Default Value:**
The default value for `WB_DEFAULT_OS` is `"Ubuntu18_04"`.

## `WB_DISK_SIZE`

The `WB_DISK_SIZE` environment variable specifies the default disk size in gigabytes (GB) shared between Workbenches
across all providers.

**Default Value:**
The default value for `WB_DISK_SIZE` is `128` GB.


## `AWS_WB_DEFAULT_SUBNET_TYPE`

The `AWS_WB_DEFAULT_SUBNET_TYPE` environment variable represents the type of subnet within the Virtual Workbench
AWS Resource Group.

**Allowed Values:**
  - `Primary`: Represents the primary subnet.
  - `Secondary`: Represents a secondary subnet.
  - `EksPrimary`: Represents the primary subnet for Amazon EKS.
  - `EksSecondary`: Represents a secondary subnet for Amazon EKS.
  - `Public`: Represents a public subnet.
  - `NAT`: Represents a subnet used for NAT (Network Address Translation).

**Default Value:**
The default value for `AWS_WB_DEFAULT_SUBNET_TYPE` is `Primary`.

**References:**
- https://docs.aws.amazon.com/vpc/latest/userguide/configure-subnets.html#subnet-types

## `AWS_C9_CONNECTION_TYPE`

The `AWS_C9_CONNECTION_TYPE` environment variable defines the type of connection used for connecting to an Amazon Cloud9
(AWS Cloud9) environment.

**Allowed Values:**
  - `CONNECT_SSH`: Represents a connection using SSH (Secure Shell). Use this value when connecting to Cloud9 instances
    via SSH. SSH is commonly used for secure remote access and administration of Cloud9 instances.
  - `CONNECT_SSM`: Represents a connection using AWS Systems Manager (SSM). Use this value when connecting to Cloud9
    instances via SSH. SSH is commonly used for secure remote access and administration of Cloud9 instances.

**Default Value:**
The default value for `AWS_C9_CONNECTION_TYPE` is `CONNECT_SSM`.

**References:**
- https://docs.aws.amazon.com/cloud9/latest/APIReference/API_Environment.html#cloud9-Type-Environment-connectionType

## `AWS_C9_DEFAULT_SUBNET_TYPE`

The `AWS_C9_DEFAULT_SUBNET_TYPE` environment variable determines the default subnet type for an Amazon Cloud9
(AWS Cloud9) environment.

**Allowed Values:**
  - `Primary`: Represents the primary subnet.
  - `Secondary`: Represents a secondary subnet.
  - `EksPrimary`: Represents the primary subnet for Amazon EKS.
  - `EksSecondary`: Represents a secondary subnet for Amazon EKS.
  - `Public`: Represents a public subnet.
  - `NAT`: Represents a subnet used for NAT (Network Address Translation).

**Default Value:**
The default value for `AWS_C9_DEFAULT_SUBNET_TYPE` is `Primary`.

**References:**
- https://registry.terraform.io/providers/hashicorp/aws/5.27.0/docs/resources/cloud9_environment_ec2#subnet_id

## `AWS_EKS_CLUSTER_VERSION`

The `AWS_EKS_CLUSTER_VERSION` environment variable sets the version of the Amazon EKS (Elastic Kubernetes Service)
cluster.

**Default Value:**
The default value for `AWS_EKS_CLUSTER_VERSION` is `"1.28"`.

**Value Limitations and Constraints:**
- The value must be a valid Kubernetes version supported by Amazon EKS.
- Ensure the version specified is compatible with your application workloads and any dependencies.

**References:**
- https://docs.aws.amazon.com/eks/latest/userguide/kubernetes-versions.html#available-versions

## `AWS_EKS_CLUSTER_SCALING_DESIRED`

The `AWS_EKS_CLUSTER_SCALING_DESIRED` environment variable determines the desired number of worker nodes in one node
group within the AWS EKS Cluster.

**Default Value:**
The default value for `AWS_EKS_CLUSTER_SCALING_DESIRED` is `0`.

**Value Limitations and Constraints:**
- The value must be a non-negative integer.
- Adjust the desired scaling value based on your application's resource requirements.

**References:**
- https://docs.aws.amazon.com/eks/latest/APIReference/API_NodegroupScalingConfig.html#AmazonEKS-Type-NodegroupScalingConfig-desiredSize

## `AWS_EKS_CLUSTER_SCALING_MAX`

The `AWS_EKS_CLUSTER_SCALING_MAX` environment variable sets the maximum number of worker nodes in one node group within
the AWS EKS Cluster.

**Default Value:**
The default value for `AWS_EKS_CLUSTER_SCALING_MAX` is `5`.

**Value Limitations and Constraints:**
- The value must be a positive integer.
- Adjust the maximum scaling value based on your application's resource requirements and AWS account limitations.

**References:**
- https://docs.aws.amazon.com/eks/latest/APIReference/API_NodegroupScalingConfig.html#AmazonEKS-Type-NodegroupScalingConfig-maxSize

## `AWS_EKS_CLUSTER_NODE_DISK_SIZE`

The `AWS_EKS_CLUSTER_NODE_DISK_SIZE` environment variable sets the default disk size in gigabytes (GB) for the worker
nodes in one node group within the AWS EKS Cluster.

**Default Value:**
The default value for `AWS_EKS_CLUSTER_NODE_DISK_SIZE` is `20`.

**Value Limitations and Constraints:**
- The value must be a positive integer.
- Adjust the disk size based on your application's storage requirements and the EKS node instance types in use.

**References:**
- https://docs.aws.amazon.com/eks/latest/APIReference/API_CreateNodegroup.html#AmazonEKS-CreateNodegroup-request-diskSize

## `QNX_LICENCE_SERVER_USER_EMAIL`

The `QNX_LICENCE_SERVER_USER_EMAIL` environment variable specifies the email address associated with the user account
for accessing the QNX license server.

**⚠️ NOTE:** The default value for `QNX_LICENCE_SERVER_USER_EMAIL` is **not** specified, in case of QNX License Server
deployment in `variables.yaml` this value should be set.

**Value Limitations and Constraints:**
- Provide a valid and registered email address associated with your QNX license server user account.

## `QNX_LICENCE_SERVER_USER_PASSWORD`

The `QNX_LICENCE_SERVER_USER_PASSWORD` environment variable stores the password associated with the user account for
accessing the QNX license server.

**⚠️ NOTE:** The default value for `QNX_LICENCE_SERVER_USER_PASSWORD` is **not** specified, in case of QNX License Server
deployment in `variables.yaml` this value should be set.

**Value Limitations and Constraints:**
- Provide the correct and secure password associated with your QNX license server user account.
- Keep the password confidential and avoid sharing it in public configurations.

## `QNX_LICENCE_SERVER_LICENSE`

The `QNX_LICENCE_SERVER_LICENSE` environment variable holds the license key or information required to authenticate and
obtain licenses from the QNX license server.

**⚠️ NOTE:** The default value for `QNX_LICENCE_SERVER_LICENSE` is **not** specified, in case of QNX License Server
deployment in variables.yaml this value should be set.

**Value Limitations and Constraints:**
- Provide the correct and valid license information associated with your QNX development environment.
- Keep the license information confidential and avoid sharing it in public configurations.

**References:**
- https://www.qnx.com/developers/docs/qsc/index.html#com.qnx.doc.qsc.user_guide/topic/using_license_manager.html

## `QNX_LMGRD_LICENCE_SERVER_PORT`

The `QNX_LMGRD_LICENCE_SERVER_PORT` environment variable specifies the port number used by the QNX license manager
(`lmgrd`) for licensing operations.

**Default Value:**
The default value for `QNX_LMGRD_LICENCE_SERVER_PORT` is `27000`.

**Value Limitations and Constraints:**
- The value must be a valid port number.
- Ensure that the specified port is available and not in use by other services.

**References:**
- https://www.ibm.com/docs/en/common-licensing/9.0.0?topic=licensing-license-manager-daemon-lmgrd

## `QNX_QNXLM_LICENCE_SERVER_PORT`

The `QNX_QNXLM_LICENCE_SERVER_PORT` environment variable specifies the port number used by the QNX license manager
(`qnxlm`) for licensing operations.

**Default Value:**
The default value for `QNX_QNXLM_LICENCE_SERVER_PORT` is `51885`.

**Value Limitations and Constraints:**
- The value must be a valid port number.
- Ensure that the specified port is available and not in use by other services.

## `AWS_SSH_KEY_TYPE`

The `AWS_SSH_KEY_TYPE` environment variable specifies the type of SSH key to be used in the AWS environment.

**Allowed Values:**
  - `RSA4096`: Represents an RSA key with a key size of 4096 bits.

**Default Value:**
The default value for `AWS_SSH_KEY_TYPE` is `RSA4096`.

**References:**
- https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-keypair.html#cfn-ec2-keypair-keytype

## `AWS_EFS_DEFAULT_SUBNET_TYPE`

The `AWS_EFS_DEFAULT_SUBNET_TYPE` environment variable defines the default subnet type to be used for
Amazon Elastic File System (EFS) resources in the AWS environment.

**Allowed Values:**
  - `Primary`: Represents the primary subnet.
  - `Secondary`: Represents a secondary subnet.
  - `EksPrimary`: Represents the primary subnet for Amazon EKS.
  - `EksSecondary`: Represents a secondary subnet for Amazon EKS.
  - `Public`: Represents a public subnet.
  - `NAT`: Represents a subnet used for NAT (Network Address Translation).

**Default Value:**
The default value for `AWS_WB_DEFAULT_SUBNET_TYPE` is `Primary`.

**References:**
- https://registry.terraform.io/providers/hashicorp/tls/latest/docs/resources/private_key#algorithm

## `AWS_BGP_ASN`

The `AWS_BGP_ASN` environment variable specifies the default BGP (Border Gateway Protocol)
Autonomous System Number (ASN) to be used in the AWS environment.


**Default Value:**
The default value for `AWS_BGP_ASN` is `65000`.

**Value Limitations and Constraints:**
- The value must be a valid BGP ASN.
- Ensure that the specified ASN is not in use by other entities in your network.

**References:**
- https://docs.aws.amazon.com/directconnect/latest/APIReference/API_CreateDirectConnectGateway.html#DX-CreateDirectConnectGateway-request-amazonSideAsn

## `AWS_VPN_CONNECTION_TYPE`

The `AWS_VPN_CONNECTION_TYPE` environment variable specifies the default VPN (Virtual Private Network) connection type
to be used in the AWS environment.

**Allowed Values:**
  - `IPSec1`: Represents the VPN connection type using IPSec version 1.

**Default Value:**
The default value for `AWS_VPN_CONNECTION_TYPE` is `"IPSec1"`.

**References:**
- https://docs.aws.amazon.com/AWSEC2/latest/APIReference/API_CreateVpnConnection.html

## `AWS_VPN_EXTERNAL_GATEWAY`

The `AWS_VPN_EXTERNAL_GATEWAY` environment variable specifies the Transit Gateway resource ID in AWS to be used instead
of SDV-CF-managed one.

**Default Value:**
The default value for `AWS_VPN_EXTERNAL_GATEWAY` is `None`.

**Value Limitations and Constraints:**
- Provide the correct IP address or DNS hostname of the external VPN gateway.
- Ensure that the specified external gateway is reachable from your AWS environment.

**References:**
- https://registry.terraform.io/providers/hashicorp/aws/5.27.0/docs/data-sources/ec2_transit_gateway

## `AZURE_WB_DEFAULT_USER_NAME`

The `AZURE_WB_DEFAULT_USER_NAME` environment variable specifies the default username for the Virtual Workbench in the
Azure environment.

**Default Value:**
The default value for `AZURE_WB_DEFAULT_USER_NAME` is `"ubuntu"`.

**References:**
- https://registry.terraform.io/providers/hashicorp/azurerm/3.82.0/docs/resources/linux_virtual_machine#admin_username

## `AZURE_WB_DEFAULT_SUBNET_TYPE`

The `AZURE_WB_DEFAULT_SUBNET_TYPE` environment variable specifies the default subnet type from the Azure Resource Group.

**Allowed Values:**
  - `Primary`: Represents the primary subnet.

**Default Value:**
The default value for `AZURE_WB_DEFAULT_SUBNET_TYPE` is `Primary`.

**References:**
- https://registry.terraform.io/providers/hashicorp/azurerm/3.82.0/docs/resources/network_interface#subnet_id

## `AZURE_WB_STORAGE_CACHING_TYPE`

The `AZURE_WB_STORAGE_CACHING_TYPE` environment variable specifies the default storage caching type for the
Azure Virtual Workbench infrastructure.

**Allowed Values:**
  - `ReadWrite`: Represents the storage caching type with read and write caching. This caching type is suitable for
    scenarios where both read and write operations benefit from caching, providing improved disk performance.
  - `ReadOnly`: Represents the storage caching type with read-only caching. This caching type is suitable for scenarios
    where read operations benefit from caching, while write operations bypass the cache. This can be advantageous for
    read-heavy workloads.

**Default Value:**
The default value for `AZURE_WB_STORAGE_CACHING_TYPE` is `"ReadWrite"`.

**References:**
- https://learn.microsoft.com/en-us/powershell/module/servicemanagement/azure/set-azurevmimageosdiskconfig?view=azuresmps-4.0.0

## `AZURE_WB_STORAGE_ACCOUNT_TYPE`

The `AZURE_WB_STORAGE_ACCOUNT_TYPE` environment variable specifies the default storage account type for the
Azure Virtual Workbench infrastructure.

**Allowed Values:**
  - `StandardLRS`: Represents a standard storage account with Locally Redundant Storage (LRS), providing data redundancy
    within a single storage scale unit in a region.
  - `StandardGRS`: Represents a standard storage account with Geo-Redundant Storage (GRS), providing data redundancy
    across multiple regions.
  - `StandardRAGRS`: Represents a standard storage account with Read-Access Geo-Redundant Storage (RA-GRS), allowing
    read access to data in the secondary region.
  - `StandardZRS`: Represents a standard storage account with Zone-Redundant Storage (ZRS), providing data redundancy
    across availability zones in a region.
  - `StandardGZRS`: Represents a standard storage account with Geo-Zone-Redundant Storage (GZRS), providing data
    redundancy across availability zones in multiple regions.
  - `StandardRAGZRS`: Represents a standard storage account with Read-Access Geo-Zone-Redundant Storage (RA-GZRS),
    allowing read access to data in the secondary availability zone.
  - `PremiumLRS`: Represents a premium storage account with Locally Redundant Storage (LRS), offering high-performance
    storage optimized for I/O-intensive workloads.
  - `PremiumZRS`: Represents a premium storage account with Zone-Redundant Storage (ZRS), providing high-performance
    storage with redundancy across availability zones.

**Default Value:**
The default value for `AZURE_WB_STORAGE_ACCOUNT_TYPE` is `"StandardLRS"`.

**References:**
- https://learn.microsoft.com/en-us/rest/api/storagerp/srp_sku_types

## `AZURE_KEY_VAULT_SKU_NAME`

The `AZURE_KEY_VAULT_SKU_NAME` environment variable specifies the default SKU (Stock Keeping Unit) name for
Azure Key Vault.

**Allowed Values:**
  - `Standard`: Represents the standard SKU for Azure Key Vault.
  - `Premium`: Represents the premium SKU for Azure Key Vault.

**Default Value:**
The default value for `AZURE_KEY_VAULT_SKU_NAME` is `"Standard"`.

**References:**
- https://registry.terraform.io/providers/hashicorp/azurerm/3.70.0/docs/resources/key_vault#sku_name

## `AZURE_KEY_VAULT_RETENTION_DAYS`

The `AZURE_KEY_VAULT_RETENTION_DAYS` environment variable specifies the default retention period, in days. 

**Default Value:**
The default value for `AZURE_KEY_VAULT_RETENTION_DAYS` is `7`

**References:**
- https://registry.terraform.io/providers/hashicorp/azurerm/3.82.0/docs/resources/key_vault#soft_delete_retention_days

## `AZURE_USER_SSH_KEY_TYPE`

The `AZURE_USER_SSH_KEY_TYPE` environment variable specifies the default SSH key type for user authentication.

**Allowed Values:**
  - `RSA4096`: Represents an RSA key with a key size of 4096 bits.

**Default Value:**
The default value for `AZURE_USER_SSH_KEY_TYPE` `"RSA4096"`.

**References:**
- https://registry.terraform.io/providers/hashicorp/tls/latest/docs/resources/private_key#algorithm

## `AZURE_VNET_GATEWAY_TYPE`

The `AZURE_VNET_GATEWAY_TYPE` environment variable specifies the default type of virtual network gateway.

**Allowed Values:**
  - `Vpn`: This type of gateway facilitates secure and encrypted communication between on-premises networks and Azure
    virtual networks over the internet.
  - `ExpressRoute`: ExpressRoute provides a private, dedicated connection to Azure, bypassing the public internet and
    offering enhanced security and reliability, making it suitable for critical enterprise workloads.

**Default Value:**
The default value for `AZURE_VNET_GATEWAY_TYPE` is `"Vpn"`.

**References:**
- https://learn.microsoft.com/en-us/azure/expressroute/expressroute-about-virtual-network-gateways#gateway-types

## `AZURE_VPN_GATEWAY_TYPE`

The `AZURE_VPN_GATEWAY_TYPE` environment variable specifies the default type of VPN (Virtual Private Network) gateway.

**Allowed Values:**
  - `Basic`: Represents a Generation 1 (Gen1) Basic VPN gateway. This type of gateway is suitable for basic VPN
    connectivity and is often used for non-production or small-scale environments.
  - SKUs for Generation 1 (*Gen1*):
    - `Gen1Gw1`, `Gen1Gw2`, `Gen1Gw3`: Represent Generation 1 (Gen1) VPN gateways with varying performance specs.
      These SKUs provide different levels of capacity and throughput to meet specific workload requirements.
    - `Gen1Gw1AZ`, `Gen1Gw2AZ`, `Gen1Gw3AZ`: Represent Generation 1 (Gen1) VPN gateways with availability zone support.
      These SKUs provide increased availability by distributing gateway resources across multiple availability zones.
  - SKUs for Generation 2 (*Gen2*):
    - `Gen2Gw2`, `Gen2Gw3`, `Gen2Gw4`, `Gen2Gw5`: Represent Generation 2 (Gen2) VPN gateways with varying performance
      characteristics. These SKUs offer improved scalability and features compared to Generation 1.
    - `Gen2Gw2AZ`, `Gen2Gw3AZ`, `Gen2Gw4AZ`, `Gen2Gw5AZ`: Represent Generation 2 (Gen2) VPN gateways with availability
      zone support. These SKUs provide increased availability by distributing gateway resources across multiple
      availability zones.

**Default Value:**
The default value for `AZURE_VPN_GATEWAY_TYPE` is `"Basic"`.

**References:**
- https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-gateway-settings#gwsku

## `AZURE_VPN_TYPE`

The `AZURE_VPN_TYPE` environment variable specifies the default type of VPN (Virtual Private Network).

**Allowed Values:**
  - `PolicyBased`: Policy-based VPNs rely on specific policies and access control lists (ACLs) to determine the traffic that is allowed through the VPN tunnel. These are typically simpler but may have limitations on the types of networks that can be connected.
  - `RouteBased`: Route-based VPNs use the routing table to determine the traffic that is allowed through the VPN tunnel. They are often more flexible than policy-based VPNs and can support a wider range of network configurations.

**Default Value:**
The default value for `AZURE_VPN_TYPE` is `"RouteBased"`.

**References:**
- https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-gateway-settings#vpntype

## `AZURE_DPD_TIMEOUT`

The `AZURE_DPD_TIMEOUT` environment variable specifies the Dead Peer Detection (DPD) timeout duration in seconds for
VPN (Virtual Private Network).

**Default Value:**
The default value for `AZURE_DPD_TIMEOUT` is `45`.

**References:**
- https://registry.terraform.io/providers/hashicorp/azurerm/3.82.0/docs/resources/virtual_network_gateway_connection#dpd_timeout_seconds

## `AZURE_VNET_GATEWAY_CONNECTION_TYPE`

The `AZURE_VNET_GATEWAY_CONNECTION_TYPE` environment variable specifies the default type of connection for the virtual
network gateway.

**Allowed Values:**
  - `ExpressRoute`: ExpressRoute provides a private, dedicated connection to Azure, bypassing the public internet.
    This connection type is suitable for enterprises with specific networking requirements and demands higher
    reliability and security.
  - `IPsec`: IPsec (Internet Protocol Security) is a widely used protocol suite for securing Internet communications.
    This connection type is suitable for establishing secure VPN tunnels over the internet.
  - `Vnet2Vnet`: This connection type allows the connection of two virtual networks within Azure. It is useful for
    scenarios where resources in different virtual networks need to communicate with each other securely.

**Default Value:**
The default value for `AZURE_VNET_GATEWAY_CONNECTION_TYPE` is `"IPsec"`.

**References:**
- https://learn.microsoft.com/en-us/rest/api/network-gateway/virtual-network-gateway-connections/create-or-update#virtualnetworkgatewayconnectiontype

## `AZURE_VNET_GATEWAY_CONNECTION_PROTOCOL`

The `AZURE_VNET_GATEWAY_CONNECTION_PROTOCOL` environment variable specifies the default IKE (Internet Key Exchange)
protocol for the virtual network gateway connection.

**Allowed Values:**
  - `IKEv1`: IKEv1 is an older version of the IKE protocol and is still used in certain scenarios.
    It provides a mechanism for establishing security associations (SAs) and negotiating keys for
    IPsec (Internet Protocol Security) encryption.
  - `IKEv2`: IKEv2 is a more modern and secure version of the IKE protocol. It provides improved security features,
    supports mobility, and is generally preferred for establishing VPN connections in Azure.

**Default Value:**
The default value for `AZURE_VNET_GATEWAY_CONNECTION_PROTOCOL` is `"IKEv2"`.

**References:**
- https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-compliance-crypto#about-ikev1-and-ikev2-for-azure-vpn-connections

## `KUBERNETES_RBAC_AUTH_API_GROUP`

The `KUBERNETES_RBAC_AUTH_API_GROUP` environment variable specifies the default RBAC (Role-Based Access Control)
authentication API group used in the Kubernetes configuration.

**Default Value:**
The default value for `KUBERNETES_RBAC_AUTH_API_GROUP` is `"rbac.authorization.k8s.io"`.

**Value Limitations and Constraints:**
- The value must be a valid RBAC API group name.
- The default value is a commonly used RBAC API group for Kubernetes RBAC configurations.

**References:**
- https://registry.terraform.io/providers/hashicorp/kubernetes/latest/docs/resources/cluster_role_binding_v1#api_group
